import os
from ament_index_python.packages import get_package_share_directory
from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument, TimerAction
from launch.substitutions import LaunchConfiguration
from launch_ros.actions import Node


def generate_launch_description():

    pkg = get_package_share_directory('amr_pure_navigation')

    use_sim_time   = LaunchConfiguration('use_sim_time')
    map_yaml       = LaunchConfiguration('map')
    waypoints_file = LaunchConfiguration('waypoints_file')
    params_file    = LaunchConfiguration('params_file')

    return LaunchDescription([

        DeclareLaunchArgument('use_sim_time', default_value='false'),

        DeclareLaunchArgument(
            'map',
            default_value='/home/taikisha/ekf_ws/src/my_robot_description/rviz/taikisha.yaml'),

        DeclareLaunchArgument(
            'waypoints_file',
            default_value='/home/taikisha/ekf_ws/src/amr_pure_navigation/config/waypoints.yaml'),

        DeclareLaunchArgument(
            'params_file',
            default_value=os.path.join(pkg, 'config', 'amcl_map_params.yaml')),

        # ── 1. Map Server ──────────────────────────────────────────
        Node(
            package='nav2_map_server',
            executable='map_server',
            name='map_server',
            output='screen',
            parameters=[
                params_file,
                {'use_sim_time': use_sim_time},
                {'yaml_filename': map_yaml},
            ],
        ),

        # ── 2. AMCL ───────────────────────────────────────────────
        Node(
            package='nav2_amcl',
            executable='amcl',
            name='amcl',
            output='screen',
            parameters=[
                params_file,
                {'use_sim_time': use_sim_time},
            ],
        ),

        # ── 3. Lifecycle Manager ───────────────────────────────────
        Node(
            package='nav2_lifecycle_manager',
            executable='lifecycle_manager',
            name='lifecycle_manager_localization',
            output='screen',
            parameters=[
                {'use_sim_time': use_sim_time},
                {'autostart':    True},
                {'node_names':   ['map_server', 'amcl']},
                {'bond_timeout': 10.0},
            ],
        ),

        # ── 4. Your Navigation Node (starts 5 sec after AMCL) ─────
        TimerAction(period=5.0, actions=[
            Node(
                package='amr_pure_navigation',
                executable='waypoint_navigator',
                name='waypoint_navigator',
                output='screen',
                parameters=[{
                    'waypoints_file':    waypoints_file,
                    'amcl_topic':        '/amcl_pose',
                    # 'odom_topic':        '/diff_drive_controller/odom',
                    'odom_topic':        '/odometry/filtered',
                    'cmd_vel_topic':     '/cmd_vel',
                    'use_amcl':          True,
                    'linear_speed':      0.20,
                    'angular_speed':     0.40,
                    'drive_correction':  0.15,   # keeps RPM equal = straight line
                    'xy_tolerance':      0.10,
                    'yaw_tolerance':     0.08,
                    'heading_tolerance': 0.10,
                    'stop_on_obstacle':  True,
                    'obstacle_stop_dist':0.40,
                    'loop_waypoints':    False,
                    'use_sim_time':      use_sim_time,
                }],
            ),
        ]),
    ])






# # ================================================================
# #  navigation_launch.py
# #
# #  Starts:
# #    1. map_server        — serves your map
# #    2. amcl              — localizes robot on map (no drift!)
# #    3. lifecycle_manager — manages map_server + amcl
# #    4. waypoint_navigator— YOUR custom navigation node
# #
# #  After launching:
# #    → Open RViz
# #    → Click "2D Pose Estimate"
# #    → Click on map where robot actually is
# #    → Robot will start moving through waypoints automatically
# # ================================================================

# import os
# from ament_index_python.packages import get_package_share_directory
# from launch import LaunchDescription
# from launch.actions import DeclareLaunchArgument, TimerAction
# from launch.substitutions import LaunchConfiguration
# from launch_ros.actions import Node


# def generate_launch_description():

#     pkg = get_package_share_directory('amr_pure_navigation')

#     use_sim_time   = LaunchConfiguration('use_sim_time')
#     params_file    = LaunchConfiguration('params_file')
#     map_yaml       = LaunchConfiguration('map')
#     waypoints_file = LaunchConfiguration('waypoints_file')

#     # Only AMCL + map_server are lifecycle managed
#     lifecycle_nodes = ['map_server', 'amcl']

#     remappings = [('/tf', 'tf'), ('/tf_static', 'tf_static')]

#     return LaunchDescription([

#         # ── Arguments ─────────────────────────────────────────────
#         DeclareLaunchArgument(
#             'use_sim_time',
#             default_value='false'),

#         DeclareLaunchArgument(
#             'params_file',
#             default_value=os.path.join(pkg, 'config', 'amcl_map_params.yaml'),
#             description='AMCL + map_server params'),

#         DeclareLaunchArgument(
#             'map',
#             default_value='/home/shailesh/ekf_ws/src/my_robot_description/rviz/taikisha.yaml',
#             description='Path to map yaml'),

#         DeclareLaunchArgument(
#             'waypoints_file',
#             default_value='/home/shailesh/ekf_ws/src/amr_pure_navigation/config/waypoints.yaml',
#             description='Path to waypoints yaml'),

#         # ── 1. Map Server ──────────────────────────────────────────
#         Node(
#             package='nav2_map_server',
#             executable='map_server',
#             name='map_server',
#             output='screen',
#             parameters=[
#                 params_file,
#                 {'use_sim_time': use_sim_time},
#                 {'yaml_filename': map_yaml},
#             ],
#             remappings=remappings,
#         ),

#         # ── 2. AMCL ───────────────────────────────────────────────
#         Node(
#             package='nav2_amcl',
#             executable='amcl',
#             name='amcl',
#             output='screen',
#             parameters=[
#                 params_file,
#                 {'use_sim_time': use_sim_time},
#             ],
#             remappings=remappings,
#         ),

#         # ── 3. Lifecycle Manager — only map_server + amcl ──────────
#         Node(
#             package='nav2_lifecycle_manager',
#             executable='lifecycle_manager',
#             name='lifecycle_manager_localization',
#             output='screen',
#             parameters=[
#                 {'use_sim_time': use_sim_time},
#                 {'autostart':    True},
#                 {'node_names':   lifecycle_nodes},
#             ],
#         ),

#         # ── 4. Your Custom Navigator ───────────────────────────────
#         # Delayed 5 sec — lets AMCL + map fully initialize first
#         TimerAction(
#             period=5.0,
#             actions=[
#                 Node(
#                     package='amr_pure_navigation',
#                     executable='waypoint_navigator',
#                     name='waypoint_navigator',
#                     output='screen',
#                     parameters=[{
#                         'waypoints_file':    waypoints_file,

#                         # Topic names
#                         'amcl_topic':        '/amcl_pose',
#                         'odom_topic':        '/diff_drive_controller/odom',
#                         'cmd_vel_topic':     '/cmd_vel',

#                         # Speed
#                         'linear_speed':      0.20,
#                         'angular_speed':     0.40,

#                         # Tolerances
#                         'xy_tolerance':      0.10,
#                         'yaw_tolerance':     0.08,
#                         'heading_tolerance': 0.10,

#                         # Obstacle
#                         'stop_on_obstacle':  True,
#                         'obstacle_stop_dist':0.40,

#                         # Loop
#                         'loop_waypoints':    False,

#                         'use_sim_time':      use_sim_time,
#                     }],
#                 ),
#             ],
#         ),

#     ])
