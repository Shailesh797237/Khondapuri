#pragma once

#include <string>
#include <vector>
#include <cmath>
#include <algorithm>
#include <fstream>

#include "rclcpp/rclcpp.hpp"
#include "geometry_msgs/msg/twist.hpp"
#include "geometry_msgs/msg/pose_with_covariance_stamped.hpp"
#include "geometry_msgs/msg/quaternion.hpp"
#include "nav_msgs/msg/odometry.hpp"
#include "sensor_msgs/msg/laser_scan.hpp"
#include "std_msgs/msg/int32.hpp"
#include "std_msgs/msg/string.hpp"
#include <yaml-cpp/yaml.h>

namespace amr_pure_navigation
{

struct Waypoint {
  double      x        {0.0};
  double      y        {0.0};
  double      theta    {0.0};
  std::string type     {"waypoint"};
  std::string mission  {"forward"};
  std::string name     {""};        // used as station name for PLC
  std::string rotation {"auto"};    // "cw"=clockwise, "ccw"=anticlockwise, "auto"=shortest
};

enum class State {
  IDLE,
  ROTATE_TO_HEADING,
  DRIVE_STRAIGHT,
  DRIVE_REVERSE,
  ROTATE_TO_THETA,
  WAIT_PLC,          // ← NEW: robot stopped, waiting for /plc_done
  WAYPOINT_DONE,
  CYCLE_DONE,
  ALL_DONE
};

class WaypointNavigator : public rclcpp::Node
{
public:
  explicit WaypointNavigator(
    const rclcpp::NodeOptions & options = rclcpp::NodeOptions());

private:
  void amclCallback    (const geometry_msgs::msg::PoseWithCovarianceStamped::SharedPtr msg);
  void odomCallback    (const nav_msgs::msg::Odometry::SharedPtr msg);
  void scanCallback    (const sensor_msgs::msg::LaserScan::SharedPtr msg);
  void cyclesCallback  (const std_msgs::msg::Int32::SharedPtr msg);
  void plcDoneCallback (const std_msgs::msg::String::SharedPtr msg);
  void controlLoop     ();

  bool        loadWaypoints   (const std::string & path);
  void        stopRobot       ();
  void        publishStatus   (const std::string & msg);
  double      normalizeAngle  (double a);
  double      quaternionToYaw (const geometry_msgs::msg::Quaternion & q);
  bool        isOnlyRotation  (const Waypoint & prev, const Waypoint & curr);
  const char* stateStr        ();

  // ── ROS interfaces ────────────────────────────────────────────
  rclcpp::Publisher<geometry_msgs::msg::Twist>::SharedPtr                        cmd_vel_pub_;
  rclcpp::Publisher<std_msgs::msg::String>::SharedPtr                            status_pub_;
  rclcpp::Publisher<std_msgs::msg::String>::SharedPtr                            station_pub_;
  rclcpp::Subscription<geometry_msgs::msg::PoseWithCovarianceStamped>::SharedPtr amcl_sub_;
  rclcpp::Subscription<nav_msgs::msg::Odometry>::SharedPtr                       odom_sub_;
  rclcpp::Subscription<sensor_msgs::msg::LaserScan>::SharedPtr                   scan_sub_;
  rclcpp::Subscription<std_msgs::msg::Int32>::SharedPtr                          cycles_sub_;
  rclcpp::Subscription<std_msgs::msg::String>::SharedPtr                         plc_done_sub_;
  rclcpp::TimerBase::SharedPtr                                                   timer_;

  // ── Robot pose ────────────────────────────────────────────────
  double robot_x_          {0.0};
  double robot_y_          {0.0};
  double robot_yaw_        {0.0};
  bool   pose_received_    {false};
  bool   init_failed_      {false};

  // ── Obstacle detection ────────────────────────────────────────
  bool   obstacle_ahead_   {false};
  bool   obstacle_front_   {false};
  bool   obstacle_rear_    {false};

  // ── PLC bridge ────────────────────────────────────────────────
  bool   plc_enabled_      {false};  // enable PLC integration
  bool   waiting_for_plc_  {false};  // robot paused at station
  bool   plc_done_         {false};  // /plc_done received

  // ── Navigation state ──────────────────────────────────────────
  State                 state_       {State::IDLE};
  std::vector<Waypoint> waypoints_;
  size_t                wp_index_    {0};
  int                   log_counter_ {0};

  // ── Cycle control ─────────────────────────────────────────────
  int  max_cycles_     {0};
  int  cycles_done_    {0};
  bool loop_forever_   {false};

  // ── Parameters ────────────────────────────────────────────────
  std::string waypoints_file_;
  std::string odom_topic_         {"/odometry/filtered"};
  std::string cmd_vel_topic_      {"/diff_drive_controller/cmd_vel"};
  std::string amcl_topic_         {"/amcl_pose"};
  double      linear_speed_       {0.20};
  double      angular_speed_      {0.40};
  double      drive_correction_   {0.15};
  double      xy_tolerance_       {0.10};
  double      yaw_tolerance_      {0.08};
  double      heading_tolerance_  {0.10};
  double      obstacle_stop_dist_ {0.40};
  bool        stop_on_obstacle_   {true};
  bool        use_amcl_           {true};
};

}  // namespace amr_pure_navigation

// forword and reverse movement
// #pragma once

// #include <string>
// #include <vector>
// #include <cmath>
// #include <algorithm>
// #include <fstream>

// #include "rclcpp/rclcpp.hpp"
// #include "geometry_msgs/msg/twist.hpp"
// #include "geometry_msgs/msg/pose_with_covariance_stamped.hpp"
// #include "geometry_msgs/msg/quaternion.hpp"
// #include "nav_msgs/msg/odometry.hpp"
// #include "sensor_msgs/msg/laser_scan.hpp"
// #include "std_msgs/msg/int32.hpp"
// #include "std_msgs/msg/string.hpp"
// #include <yaml-cpp/yaml.h>

// namespace amr_pure_navigation
// {

// struct Waypoint {
//   double      x       {0.0};
//   double      y       {0.0};
//   double      theta   {0.0};
//   std::string type    {"waypoint"};
//   std::string mission {"forward"};   // "forward" or "reverse"
// };

// enum class State {
//   IDLE,
//   ROTATE_TO_HEADING,   // rotate to face goal (fwd) or back-to-goal (rev)
//   DRIVE_STRAIGHT,      // drive forward  linear.x = +speed
//   DRIVE_REVERSE,       // drive backward linear.x = -speed
//   ROTATE_TO_THETA,     // rotate to final theta of waypoint
//   WAYPOINT_DONE,
//   CYCLE_DONE,
//   ALL_DONE
// };

// class WaypointNavigator : public rclcpp::Node
// {
// public:
//   explicit WaypointNavigator(
//     const rclcpp::NodeOptions & options = rclcpp::NodeOptions());

// private:
//   void amclCallback   (const geometry_msgs::msg::PoseWithCovarianceStamped::SharedPtr msg);
//   void odomCallback   (const nav_msgs::msg::Odometry::SharedPtr msg);
//   void scanCallback   (const sensor_msgs::msg::LaserScan::SharedPtr msg);
//   void cyclesCallback (const std_msgs::msg::Int32::SharedPtr msg);
//   void controlLoop    ();

//   bool        loadWaypoints   (const std::string & path);
//   void        stopRobot       ();
//   void        publishStatus   (const std::string & msg);
//   double      normalizeAngle  (double a);
//   double      quaternionToYaw (const geometry_msgs::msg::Quaternion & q);
//   bool        isOnlyRotation  (const Waypoint & prev, const Waypoint & curr);
//   const char* stateStr        ();

//   // ── ROS interfaces ───────────────────────────────────────────
//   rclcpp::Publisher<geometry_msgs::msg::Twist>::SharedPtr                        cmd_vel_pub_;
//   rclcpp::Publisher<std_msgs::msg::String>::SharedPtr                            status_pub_;
//   rclcpp::Subscription<geometry_msgs::msg::PoseWithCovarianceStamped>::SharedPtr amcl_sub_;
//   rclcpp::Subscription<nav_msgs::msg::Odometry>::SharedPtr                       odom_sub_;
//   rclcpp::Subscription<sensor_msgs::msg::LaserScan>::SharedPtr                   scan_sub_;
//   rclcpp::Subscription<std_msgs::msg::Int32>::SharedPtr                          cycles_sub_;
//   rclcpp::TimerBase::SharedPtr                                                   timer_;

//   // ── Robot pose ───────────────────────────────────────────────
//   double robot_x_         {0.0};
//   double robot_y_         {0.0};
//   double robot_yaw_       {0.0};
//   bool   pose_received_   {false};
//   bool   init_failed_     {false};

//   // ── Obstacle detection (front + rear separate) ───────────────
//   bool   obstacle_ahead_  {false};   // legacy
//   bool   obstacle_front_  {false};   // blocks DRIVE_STRAIGHT
//   bool   obstacle_rear_   {false};   // blocks DRIVE_REVERSE

//   // ── Navigation state ─────────────────────────────────────────
//   State                 state_       {State::IDLE};
//   std::vector<Waypoint> waypoints_;
//   size_t                wp_index_    {0};
//   int                   log_counter_ {0};

//   // ── Cycle control ────────────────────────────────────────────
//   int  max_cycles_    {0};
//   int  cycles_done_   {0};
//   bool loop_forever_  {false};

//   // ── Parameters ───────────────────────────────────────────────
//   std::string waypoints_file_;
//   std::string odom_topic_         {"/odometry/filtered"};
//   std::string cmd_vel_topic_      {"/diff_drive_controller/cmd_vel"};
//   std::string amcl_topic_         {"/amcl_pose"};
//   double      linear_speed_       {0.20};
//   double      angular_speed_      {0.40};
//   double      drive_correction_   {0.15};
//   double      xy_tolerance_       {0.10};
//   double      yaw_tolerance_      {0.08};
//   double      heading_tolerance_  {0.10};
//   double      obstacle_stop_dist_ {0.40};
//   bool        stop_on_obstacle_   {true};
//   bool        use_amcl_           {true};
// };

// }  // namespace amr_pure_navigation



// //perfect (sometime rotate wrong direaction)

// #pragma once

// #include <string>
// #include <vector>
// #include <cmath>
// #include <algorithm>
// #include <fstream>

// #include "rclcpp/rclcpp.hpp"
// #include "geometry_msgs/msg/twist.hpp"
// #include "geometry_msgs/msg/pose_with_covariance_stamped.hpp"
// #include "geometry_msgs/msg/quaternion.hpp"
// #include "nav_msgs/msg/odometry.hpp"
// #include "sensor_msgs/msg/laser_scan.hpp"
// #include "std_msgs/msg/int32.hpp"       // for /set_cycles topic
// #include "std_msgs/msg/string.hpp"      // for /nav_status topic
// #include <yaml-cpp/yaml.h>

// namespace amr_pure_navigation
// {

// struct Waypoint {
//   double      x     {0.0};
//   double      y     {0.0};
//   double      theta {0.0};
//   std::string type  {"waypoint"};
// };

// enum class State {
//   IDLE,               // waiting for cycles command
//   ROTATE_TO_HEADING,
//   DRIVE_STRAIGHT,
//   ROTATE_TO_THETA,
//   WAYPOINT_DONE,
//   CYCLE_DONE,         // one full cycle complete — check if more needed
//   ALL_DONE            // all cycles complete
// };

// class WaypointNavigator : public rclcpp::Node
// {
// public:
//   explicit WaypointNavigator(
//     const rclcpp::NodeOptions & options = rclcpp::NodeOptions());

// private:
//   // Callbacks
//   void amclCallback   (const geometry_msgs::msg::PoseWithCovarianceStamped::SharedPtr msg);
//   void odomCallback   (const nav_msgs::msg::Odometry::SharedPtr msg);
//   void scanCallback   (const sensor_msgs::msg::LaserScan::SharedPtr msg);
//   void cyclesCallback (const std_msgs::msg::Int32::SharedPtr msg);  // /set_cycles
//   void controlLoop    ();

//   // Helpers
//   bool        loadWaypoints   (const std::string & path);
//   void        stopRobot       ();
//   void        publishStatus   (const std::string & msg);
//   double      normalizeAngle  (double a);
//   double      quaternionToYaw (const geometry_msgs::msg::Quaternion & q);
//   bool        isOnlyRotation  (const Waypoint & prev, const Waypoint & curr);
//   const char* stateStr        ();

//   // ── ROS interfaces ──────────────────────────────────────────────
//   rclcpp::Publisher<geometry_msgs::msg::Twist>::SharedPtr                        cmd_vel_pub_;
//   rclcpp::Publisher<std_msgs::msg::String>::SharedPtr                            status_pub_;
//   rclcpp::Subscription<geometry_msgs::msg::PoseWithCovarianceStamped>::SharedPtr amcl_sub_;
//   rclcpp::Subscription<nav_msgs::msg::Odometry>::SharedPtr                       odom_sub_;
//   rclcpp::Subscription<sensor_msgs::msg::LaserScan>::SharedPtr                   scan_sub_;
//   rclcpp::Subscription<std_msgs::msg::Int32>::SharedPtr                          cycles_sub_;
//   rclcpp::TimerBase::SharedPtr                                                   timer_;

//   // ── Robot pose ──────────────────────────────────────────────────
//   double robot_x_         {0.0};
//   double robot_y_         {0.0};
//   double robot_yaw_       {0.0};
//   bool   pose_received_   {false};
//   bool   obstacle_ahead_  {false};
//   bool   init_failed_     {false};

//   // ── Navigation state ────────────────────────────────────────────
//   State                 state_       {State::IDLE};
//   std::vector<Waypoint> waypoints_;
//   size_t                wp_index_    {0};
//   int                   log_counter_ {0};

//   // ── Cycle control ────────────────────────────────────────────────
//   int  max_cycles_    {0};     // 0 = waiting for user command
//   int  cycles_done_   {0};     // how many cycles completed
//   bool loop_forever_  {false}; // true when user sends -1

//   // ── Parameters ──────────────────────────────────────────────────
//   std::string waypoints_file_;
//   std::string odom_topic_         {"/diff_drive_controller/odom"};
//   std::string cmd_vel_topic_      {"/cmd_vel"};
//   std::string amcl_topic_         {"/amcl_pose"};
//   double      linear_speed_       {0.20};
//   double      angular_speed_      {0.40};
//   double      drive_correction_   {0.15};
//   double      xy_tolerance_       {0.10};
//   double      yaw_tolerance_      {0.08};
//   double      heading_tolerance_  {0.10};
//   double      obstacle_stop_dist_ {0.40};
//   bool        stop_on_obstacle_   {true};
//   bool        use_amcl_           {true};
// };

// }  // namespace amr_pure_navigation




//currect code 
// #pragma once

// #include <string>
// #include <vector>
// #include <cmath>
// #include <algorithm>
// #include <fstream>

// #include "rclcpp/rclcpp.hpp"
// #include "geometry_msgs/msg/twist.hpp"
// #include "geometry_msgs/msg/pose_with_covariance_stamped.hpp"
// #include "geometry_msgs/msg/quaternion.hpp"
// #include "nav_msgs/msg/odometry.hpp"
// #include "sensor_msgs/msg/laser_scan.hpp"
// #include <yaml-cpp/yaml.h>

// namespace amr_pure_navigation
// {

// struct Waypoint {
//   double      x     {0.0};
//   double      y     {0.0};
//   double      theta {0.0};
//   std::string type  {"waypoint"};
// };

// enum class State {
//   IDLE,
//   ROTATE_TO_HEADING,
//   DRIVE_STRAIGHT,
//   ROTATE_TO_THETA,
//   WAYPOINT_DONE,
//   ALL_DONE
// };

// class WaypointNavigator : public rclcpp::Node
// {
// public:
//   explicit WaypointNavigator(
//     const rclcpp::NodeOptions & options = rclcpp::NodeOptions());

// private:
//   void amclCallback (const geometry_msgs::msg::PoseWithCovarianceStamped::SharedPtr msg);
//   void odomCallback (const nav_msgs::msg::Odometry::SharedPtr msg);
//   void scanCallback (const sensor_msgs::msg::LaserScan::SharedPtr msg);
//   void controlLoop  ();

//   bool        loadWaypoints    (const std::string & path);
//   void        stopRobot        ();
//   double      normalizeAngle   (double a);
//   double      quaternionToYaw  (const geometry_msgs::msg::Quaternion & q);
//   bool        isOnlyRotation   (const Waypoint & prev, const Waypoint & curr);
//   const char* stateStr         ();

//   // ROS
//   rclcpp::Publisher<geometry_msgs::msg::Twist>::SharedPtr                        cmd_vel_pub_;
//   rclcpp::Subscription<geometry_msgs::msg::PoseWithCovarianceStamped>::SharedPtr amcl_sub_;
//   rclcpp::Subscription<nav_msgs::msg::Odometry>::SharedPtr                       odom_sub_;
//   rclcpp::Subscription<sensor_msgs::msg::LaserScan>::SharedPtr                   scan_sub_;
//   rclcpp::TimerBase::SharedPtr                                                   timer_;

//   // Robot state
//   double robot_x_         {0.0};
//   double robot_y_         {0.0};
//   double robot_yaw_       {0.0};
//   bool   pose_received_   {false};
//   bool   obstacle_ahead_  {false};
//   bool   init_failed_     {false};

//   // Navigation
//   State                 state_       {State::IDLE};
//   std::vector<Waypoint> waypoints_;
//   size_t                wp_index_    {0};
//   int                   log_counter_ {0};

//   // Parameters
//   std::string waypoints_file_;
//   std::string odom_topic_         {"/diff_drive_controller/odom"};
//   std::string cmd_vel_topic_      {"/diff_drive_controller/cmd_vel"};
//   std::string amcl_topic_         {"/amcl_pose"};
//   double      linear_speed_       {0.20};
//   double      angular_speed_      {0.40};
//   double      drive_correction_   {0.15};  // max angular.z while driving straight
//   double      xy_tolerance_       {0.10};
//   double      yaw_tolerance_      {0.08};
//   double      heading_tolerance_  {0.10};
//   double      obstacle_stop_dist_ {0.40};
//   bool        loop_waypoints_     {false};
//   bool        stop_on_obstacle_   {true};
//   bool        use_amcl_           {true};
// };

// }  // namespace amr_pure_navigation




// #pragma once

// // ================================================================
// //  waypoint_navigator.hpp
// //  Map-based AMR navigation using AMCL + Map Server
// //  Position source: /amcl_pose  (map frame — no drift!)
// //  Output:          /diff_drive_controller/cmd_vel
// // ================================================================

// #include <string>
// #include <vector>
// #include <cmath>
// #include <algorithm>
// #include <fstream>

// #include "rclcpp/rclcpp.hpp"
// #include "geometry_msgs/msg/twist.hpp"
// #include "geometry_msgs/msg/pose_with_covariance_stamped.hpp"
// #include "nav_msgs/msg/odometry.hpp"
// #include "sensor_msgs/msg/laser_scan.hpp"
// #include <yaml-cpp/yaml.h>

// namespace amr_navigation
// {

// // ── Waypoint in MAP frame ─────────────────────────────────────────
// struct Waypoint {
//   double      x     {0.0};
//   double      y     {0.0};
//   double      theta {0.0};   // radians
//   std::string type  {"waypoint"};
// };

// // ── State Machine ─────────────────────────────────────────────────
// enum class State {
//   IDLE,
//   ROTATE_TO_HEADING,   // rotate to face next x,y
//   DRIVE_STRAIGHT,      // drive to x,y
//   ROTATE_TO_THETA,     // rotate to final theta
//   WAYPOINT_DONE,       // load next waypoint
//   ALL_DONE             // finished
// };

// // ── Node ──────────────────────────────────────────────────────────
// class WaypointNavigator : public rclcpp::Node
// {
// public:
//   explicit WaypointNavigator(
//     const rclcpp::NodeOptions & options = rclcpp::NodeOptions());

// private:
//   // Callbacks
//   void amclCallback (const geometry_msgs::msg::PoseWithCovarianceStamped::SharedPtr msg);
//   void odomCallback (const nav_msgs::msg::Odometry::SharedPtr msg);
//   void scanCallback (const sensor_msgs::msg::LaserScan::SharedPtr msg);
//   void controlLoop  ();

//   // Helpers
//   bool        loadWaypoints  (const std::string & path);
//   void        stopRobot      ();
//   double      normalizeAngle (double a);
//   bool        isOnlyRotation (const Waypoint & prev, const Waypoint & curr);
//   const char* stateStr       ();

//   // ── ROS interfaces ────────────────────────────────────────────────
//   rclcpp::Publisher<geometry_msgs::msg::Twist>::SharedPtr                        cmd_vel_pub_;
//   rclcpp::Subscription<geometry_msgs::msg::PoseWithCovarianceStamped>::SharedPtr amcl_sub_;
//   rclcpp::Subscription<nav_msgs::msg::Odometry>::SharedPtr                       odom_sub_;
//   rclcpp::Subscription<sensor_msgs::msg::LaserScan>::SharedPtr                   scan_sub_;
//   rclcpp::TimerBase::SharedPtr                                                   timer_;

//   // ── Robot pose (MAP frame from AMCL) ──────────────────────────────
//   double robot_x_          {0.0};
//   double robot_y_          {0.0};
//   double robot_yaw_        {0.0};
//   bool   pose_received_    {false};   // true once AMCL publishes
//   bool   obstacle_ahead_   {false};
//   bool   init_failed_      {false};

//   // ── Navigation state ──────────────────────────────────────────────
//   State                 state_       {State::IDLE};
//   std::vector<Waypoint> waypoints_;
//   size_t                wp_index_    {0};
//   int                   log_counter_ {0};

//   // ── Parameters ────────────────────────────────────────────────────
//   std::string waypoints_file_;
//   std::string cmd_vel_topic_       {"/diff_drive_controller/cmd_vel"};
//   std::string amcl_topic_          {"/amcl_pose"};
//   std::string odom_topic_          {"/diff_drive_controller/odom"};
//   double      linear_speed_        {0.20};
//   double      angular_speed_       {0.40};
//   double      xy_tolerance_        {0.10};
//   double      yaw_tolerance_       {0.08};
//   double      heading_tolerance_   {0.10};
//   double      obstacle_stop_dist_  {0.40};
//   bool        loop_waypoints_      {false};
//   bool        stop_on_obstacle_    {true};
// };

// }  // namespace amr_navigation