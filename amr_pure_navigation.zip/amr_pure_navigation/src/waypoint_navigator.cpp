// ================================================================
//  waypoint_navigator.cpp  v6  —  Forward + Reverse Mission
//
//  mission: forward → rotate to face goal → drive forward → rotate to theta
//  mission: reverse → rotate BACK to goal → drive REVERSE → rotate to theta
//
//  WAYPOINTS YAML EXAMPLE:
//    waypoints:
//      - x: -10.0
//        y:  10.0
//        theta: 0.0
//        type: station
//        mission: reverse    ← robot drives backward to this point
//
//      - x:  20.0
//        y:  10.0
//        theta: 0.0
//        type: waypoint
//        mission: forward    ← robot drives forward to this point
//
//  CYCLE CONTROL via /set_cycles topic:
//    ros2 topic pub --once /set_cycles std_msgs/msg/Int32 "data: 1"
//    ros2 topic pub --once /set_cycles std_msgs/msg/Int32 "data: -1"  # forever
//    ros2 topic pub --once /set_cycles std_msgs/msg/Int32 "data: 0"   # stop
//
//  CHECK STATUS:
//    ros2 topic echo /nav_status
// ================================================================

#include "amr_pure_navigation/waypoint_navigator.hpp"

namespace amr_pure_navigation
{

// ─── Constructor ──────────────────────────────────────────────────
WaypointNavigator::WaypointNavigator(const rclcpp::NodeOptions & options)
: Node("waypoint_navigator", options)
{
  declare_parameter<std::string>("waypoints_file",     "");
  declare_parameter<std::string>("odom_topic",         "/odometry/filtered");
  declare_parameter<std::string>("cmd_vel_topic",      "/diff_drive_controller/cmd_vel");
  declare_parameter<std::string>("amcl_topic",         "/amcl_pose");
  declare_parameter<double>     ("linear_speed",       0.20);
  declare_parameter<double>     ("angular_speed",      0.40);
  declare_parameter<double>     ("drive_correction",   0.15);
  declare_parameter<double>     ("xy_tolerance",       0.10);
  declare_parameter<double>     ("yaw_tolerance",      0.08);
  declare_parameter<double>     ("heading_tolerance",  0.10);
  declare_parameter<double>     ("obstacle_stop_dist", 0.40);
  declare_parameter<bool>       ("stop_on_obstacle",   true);
  declare_parameter<bool>       ("use_amcl",           true);
  declare_parameter<bool>       ("plc_enabled",        false);

  get_parameter("waypoints_file",    waypoints_file_);
  get_parameter("odom_topic",        odom_topic_);
  get_parameter("cmd_vel_topic",     cmd_vel_topic_);
  get_parameter("amcl_topic",        amcl_topic_);
  get_parameter("linear_speed",      linear_speed_);
  get_parameter("angular_speed",     angular_speed_);
  get_parameter("drive_correction",  drive_correction_);
  get_parameter("xy_tolerance",      xy_tolerance_);
  get_parameter("yaw_tolerance",     yaw_tolerance_);
  get_parameter("heading_tolerance", heading_tolerance_);
  get_parameter("obstacle_stop_dist",obstacle_stop_dist_);
  get_parameter("stop_on_obstacle",  stop_on_obstacle_);
  get_parameter("use_amcl",          use_amcl_);
  get_parameter("plc_enabled",       plc_enabled_);

  if (!loadWaypoints(waypoints_file_)) {
    RCLCPP_FATAL(get_logger(), "Cannot load waypoints: %s", waypoints_file_.c_str());
    init_failed_ = true;
    return;
  }

  RCLCPP_INFO(get_logger(), "=============================================");
  RCLCPP_INFO(get_logger(), "  AMR Navigation v6 - Forward + Reverse");
  RCLCPP_INFO(get_logger(), "  Waypoints    : %zu",    waypoints_.size());
  RCLCPP_INFO(get_logger(), "  Odom topic   : %s",     odom_topic_.c_str());
  RCLCPP_INFO(get_logger(), "  Mode         : %s",     use_amcl_ ? "AMCL map frame" : "Odom only");
  RCLCPP_INFO(get_logger(), "  Linear speed : %.2f m/s",   linear_speed_);
  RCLCPP_INFO(get_logger(), "  Angular speed: %.2f rad/s", angular_speed_);
  RCLCPP_INFO(get_logger(), "=============================================");
  RCLCPP_INFO(get_logger(), "  Waiting for /set_cycles command...");
  RCLCPP_INFO(get_logger(), "  ros2 topic pub --once /set_cycles std_msgs/msg/Int32 \"data: 1\"");
  RCLCPP_INFO(get_logger(), "=============================================");

  cmd_vel_pub_ = create_publisher<geometry_msgs::msg::Twist>(cmd_vel_topic_, 10);
  status_pub_   = create_publisher<std_msgs::msg::String>("/nav_status",       10);
  station_pub_  = create_publisher<std_msgs::msg::String>("/station_reached", 10);

  // Subscribe to /plc_done (plc_bridge tells us when action is complete)
  plc_done_sub_ = create_subscription<std_msgs::msg::String>(
    "/plc_done", 10,
    std::bind(&WaypointNavigator::plcDoneCallback, this, std::placeholders::_1));

  cycles_sub_ = create_subscription<std_msgs::msg::Int32>(
    "/set_cycles", 10,
    std::bind(&WaypointNavigator::cyclesCallback, this, std::placeholders::_1));

  if (use_amcl_) {
    amcl_sub_ = create_subscription<geometry_msgs::msg::PoseWithCovarianceStamped>(
      amcl_topic_, 10,
      std::bind(&WaypointNavigator::amclCallback, this, std::placeholders::_1));
  }

  odom_sub_ = create_subscription<nav_msgs::msg::Odometry>(
    odom_topic_, 10,
    std::bind(&WaypointNavigator::odomCallback, this, std::placeholders::_1));

  scan_sub_ = create_subscription<sensor_msgs::msg::LaserScan>(
    "/scan", 10,
    std::bind(&WaypointNavigator::scanCallback, this, std::placeholders::_1));

  timer_ = create_wall_timer(
    std::chrono::milliseconds(50),
    std::bind(&WaypointNavigator::controlLoop, this));
}

// ─── PLC Done Callback ───────────────────────────────────────────
// Called when plc_bridge finishes station action → robot continues
void WaypointNavigator::plcDoneCallback(const std_msgs::msg::String::SharedPtr msg)
{
  RCLCPP_INFO(get_logger(), "✅ /plc_done received for station: [%s] → resuming", msg->data.c_str());
  plc_done_      = true;
  waiting_for_plc_ = false;
}

// ─── Cycles Callback ──────────────────────────────────────────────
void WaypointNavigator::cyclesCallback(const std_msgs::msg::Int32::SharedPtr msg)
{
  int requested = msg->data;

  if (requested == 0) {
    stopRobot();
    state_ = State::ALL_DONE;
    max_cycles_ = 0; loop_forever_ = false;
    RCLCPP_WARN(get_logger(), "🛑 STOP command! Robot halted.");
    publishStatus("STOPPED by user");
    return;
  }

  if (requested == -1) {
    loop_forever_ = true; max_cycles_ = -1;
    cycles_done_ = 0; wp_index_ = 0;
    if (pose_received_) {
      state_ = State::ROTATE_TO_HEADING;
      RCLCPP_INFO(get_logger(), "🔁 LOOP FOREVER started!");
    }
    publishStatus("RUNNING - loop forever");
    return;
  }

  if (requested > 0) {
    // ── Robot is currently running — add more cycles on top ───
    if (state_ != State::IDLE && state_ != State::ALL_DONE) {
      max_cycles_ = cycles_done_ + requested;
      loop_forever_ = false;
      RCLCPP_INFO(get_logger(), "🔄 %d more cycle(s) added. Total=%d", requested, max_cycles_);
      char buf[64]; snprintf(buf, sizeof(buf), "RUNNING - %d more added", requested);
      publishStatus(buf);
      return;
    }

    // ── Fresh start (IDLE or ALL_DONE — both reset fully) ─────
    loop_forever_ = false;
    max_cycles_   = requested;
    cycles_done_  = 0;       // ← CRITICAL: reset cycle counter
    wp_index_     = 0;       // ← CRITICAL: reset waypoint index

    if (pose_received_) {
      state_ = State::ROTATE_TO_HEADING;
      RCLCPP_INFO(get_logger(), "🚀 Starting %d cycle(s)! (fresh start)", requested);
    } else {
      state_ = State::IDLE;  // stay IDLE until pose arrives
      RCLCPP_INFO(get_logger(), "✅ %d cycle(s) queued. Waiting for pose...", requested);
    }
    char buf[64]; snprintf(buf, sizeof(buf), "STARTING %d cycles", requested);
    publishStatus(buf);
  }
}

// ─── AMCL Callback ────────────────────────────────────────────────
void WaypointNavigator::amclCallback(
  const geometry_msgs::msg::PoseWithCovarianceStamped::SharedPtr msg)
{
  if (init_failed_) return;
  robot_x_   = msg->pose.pose.position.x;
  robot_y_   = msg->pose.pose.position.y;
  robot_yaw_ = quaternionToYaw(msg->pose.pose.orientation);

  if (!pose_received_) {
    pose_received_ = true;
    RCLCPP_INFO(get_logger(), "✅ AMCL active! x=%.2f y=%.2f yaw=%.1f°",
      robot_x_, robot_y_, robot_yaw_ * 180.0 / M_PI);
    if (max_cycles_ != 0 && state_ == State::IDLE) {
      state_ = State::ROTATE_TO_HEADING;
      RCLCPP_INFO(get_logger(), "🚀 Pose received — starting!");
    }
  }
}

// ─── Odom Callback ────────────────────────────────────────────────
void WaypointNavigator::odomCallback(const nav_msgs::msg::Odometry::SharedPtr msg)
{
  if (init_failed_) return;
  if (use_amcl_ && pose_received_) return;

  robot_x_   = msg->pose.pose.position.x;
  robot_y_   = msg->pose.pose.position.y;
  robot_yaw_ = quaternionToYaw(msg->pose.pose.orientation);

  if (!pose_received_) {
    pose_received_ = true;
    RCLCPP_INFO(get_logger(), "✅ Odom active! x=%.2f y=%.2f", robot_x_, robot_y_);
    if (max_cycles_ != 0 && state_ == State::IDLE)
      state_ = State::ROTATE_TO_HEADING;
  }
}

// ─── Scan Callback ────────────────────────────────────────────────
void WaypointNavigator::scanCallback(const sensor_msgs::msg::LaserScan::SharedPtr msg)
{
  if (!stop_on_obstacle_) return;
  obstacle_ahead_ = false;

  // For REVERSE: check rear sector (±30° from back)
  // For FORWARD: check front sector (±30° from front)
  // We store both
  obstacle_front_ = false;
  obstacle_rear_  = false;

  int n = static_cast<int>(msg->ranges.size());
  for (int i = 0; i < n; ++i) {
    float angle = msg->angle_min + i * msg->angle_increment;
    float r     = msg->ranges[i];
    if (!std::isfinite(r) || r < 0.01f || r >= static_cast<float>(obstacle_stop_dist_)) continue;

    // Front sector ±30°
    if (angle >= -0.524f && angle <= 0.524f)
      obstacle_front_ = true;

    // Rear sector ±30° (around ±PI)
    if (std::abs(std::abs(angle) - M_PI) < 0.524f)
      obstacle_rear_ = true;
  }
}

// ─── Helpers ──────────────────────────────────────────────────────
double WaypointNavigator::quaternionToYaw(const geometry_msgs::msg::Quaternion & q)
{
  return std::atan2(
    2.0 * (q.w * q.z + q.x * q.y),
    1.0 - 2.0 * (q.y * q.y + q.z * q.z));
}

double WaypointNavigator::normalizeAngle(double a)
{
  while (a >  M_PI) a -= 2.0 * M_PI;
  while (a < -M_PI) a += 2.0 * M_PI;
  return a;
}

void WaypointNavigator::stopRobot()
{
  cmd_vel_pub_->publish(geometry_msgs::msg::Twist());
}

void WaypointNavigator::publishStatus(const std::string & text)
{
  std_msgs::msg::String msg;
  msg.data = text;
  status_pub_->publish(msg);
}

bool WaypointNavigator::isOnlyRotation(const Waypoint & prev, const Waypoint & curr)
{
  return (std::abs(curr.x - prev.x) < xy_tolerance_ &&
          std::abs(curr.y - prev.y) < xy_tolerance_);
}

const char * WaypointNavigator::stateStr()
{
  switch (state_) {
    case State::IDLE:              return "IDLE";
    case State::ROTATE_TO_HEADING: return "ROT_HEADING";
    case State::DRIVE_STRAIGHT:    return "DRIVE_FWD";
    case State::DRIVE_REVERSE:     return "DRIVE_REV";
    case State::ROTATE_TO_THETA:   return "ROT_THETA";
    case State::WAIT_PLC:          return "WAIT_PLC";
    case State::WAYPOINT_DONE:     return "WP_DONE";
    case State::CYCLE_DONE:        return "CYCLE_DONE";
    case State::ALL_DONE:          return "ALL_DONE";
    default:                       return "UNKNOWN";
  }
}

// ─── Load Waypoints ───────────────────────────────────────────────
bool WaypointNavigator::loadWaypoints(const std::string & path)
{
  if (path.empty()) { RCLCPP_ERROR(get_logger(), "waypoints_file is empty!"); return false; }
  std::ifstream f(path);
  if (!f.good()) { RCLCPP_ERROR(get_logger(), "Cannot open: %s", path.c_str()); return false; }
  f.seekg(0, std::ios::end);
  if (f.tellg() == 0) { RCLCPP_ERROR(get_logger(), "File empty: %s", path.c_str()); return false; }
  f.close();

  try {
    YAML::Node root = YAML::LoadFile(path);
    YAML::Node wps  = root["waypoints"];
    if (!wps || !wps.IsSequence()) {
      RCLCPP_ERROR(get_logger(), "No 'waypoints' list in YAML"); return false;
    }
    for (size_t i = 0; i < wps.size(); ++i) {
      Waypoint w;
      w.x       = wps[i]["x"].as<double>();
      w.y       = wps[i]["y"].as<double>();
      w.theta   = wps[i]["theta"].as<double>();
      w.type     = wps[i]["type"]     ? wps[i]["type"].as<std::string>()     : "waypoint";
      w.mission  = wps[i]["mission"]  ? wps[i]["mission"].as<std::string>()  : "forward";
      w.rotation = wps[i]["rotation"] ? wps[i]["rotation"].as<std::string>() : "auto";
      waypoints_.push_back(w);

      RCLCPP_INFO(get_logger(),
        "  WP[%02zu] %-10s %-8s rot=%-5s x=%.2f y=%.2f theta=%.1f°",
        i, w.type.c_str(), w.mission.c_str(), w.rotation.c_str(),
        w.x, w.y, w.theta * 180.0 / M_PI);
    }
  } catch (const std::exception & e) {
    RCLCPP_ERROR(get_logger(), "YAML error: %s", e.what()); return false;
  }
  return !waypoints_.empty();
}

// ─── Main Control Loop  20 Hz ─────────────────────────────────────
void WaypointNavigator::controlLoop()
{
  if (init_failed_ || !pose_received_) return;
  if (state_ == State::IDLE)     { stopRobot(); return; }
  if (state_ == State::ALL_DONE) {
    stopRobot();
    // Stay here — cyclesCallback will reset state when user sends new command
    return;
  }

  if (wp_index_ >= waypoints_.size()) {
    state_ = State::CYCLE_DONE; return;
  }

  // ── CYCLE DONE ───────────────────────────────────────────────
  if (state_ == State::CYCLE_DONE) {
    cycles_done_++;
    if (loop_forever_ || cycles_done_ < max_cycles_) {
      wp_index_ = 0;
      state_    = State::ROTATE_TO_HEADING;
      RCLCPP_INFO(get_logger(), loop_forever_ ?
        "🔁 Cycle %d done — looping!" : "🔄 Cycle %d/%d done — next cycle!",
        cycles_done_, max_cycles_);
    } else {
      state_ = State::ALL_DONE; stopRobot();
      RCLCPP_INFO(get_logger(), "✅ ALL %d CYCLE(S) DONE!", cycles_done_);
    }
    return;
  }

  const Waypoint & wp = waypoints_[wp_index_];
  const bool is_reverse = (wp.mission == "reverse");

  double dx            = wp.x - robot_x_;
  double dy            = wp.y - robot_y_;
  double distance      = std::hypot(dx, dy);
  double angle_to_goal = std::atan2(dy, dx);

  // For reverse: robot needs its BACK to face goal
  // So target heading = angle_to_goal + PI
  double heading_target = is_reverse
    ? normalizeAngle(angle_to_goal + M_PI)
    : angle_to_goal;

  double heading_error = normalizeAngle(heading_target - robot_yaw_);
  double yaw_error     = normalizeAngle(wp.theta - robot_yaw_);

  geometry_msgs::msg::Twist cmd;

  // 1 second log
  if (++log_counter_ >= 20) {
    log_counter_ = 0;
    RCLCPP_INFO(get_logger(),
      "[%s | %s | WP%zu] pos(%.2f,%.2f,%.1f°)→(%.2f,%.2f,%.1f°) dist=%.2fm",
      stateStr(), is_reverse ? "REV" : "FWD", wp_index_,
      robot_x_, robot_y_, robot_yaw_ * 180.0 / M_PI,
      wp.x, wp.y, wp.theta * 180.0 / M_PI, distance);
  }

  switch (state_)
  {
    // ════════════════════════════════════════════════════════════
    // ROTATE_TO_HEADING
    // Forward:  rotate until robot FACES the goal
    // Reverse:  rotate until robot BACK is toward the goal
    // ════════════════════════════════════════════════════════════
    case State::ROTATE_TO_HEADING:
    {
      Waypoint prev = (wp_index_ > 0) ?
        waypoints_[wp_index_ - 1] :
        Waypoint{robot_x_, robot_y_, robot_yaw_};

      if (isOnlyRotation(prev, wp)) {
        state_ = State::ROTATE_TO_THETA;
        RCLCPP_INFO(get_logger(), "[WP%zu] Pure rotation → %.1f°",
          wp_index_, wp.theta * 180.0 / M_PI);
        break;
      }

      if (distance < xy_tolerance_) {
        stopRobot(); state_ = State::ROTATE_TO_THETA;
        break;
      }

      if (std::abs(heading_error) < heading_tolerance_) {
        stopRobot();
        // Go to correct drive state based on mission
        state_ = is_reverse ? State::DRIVE_REVERSE : State::DRIVE_STRAIGHT;
        RCLCPP_INFO(get_logger(),
          "[WP%zu] ✓ Heading aligned (%.1f°). %s → dist=%.2fm",
          wp_index_, heading_error * 180.0 / M_PI,
          is_reverse ? "REVERSING" : "DRIVING FORWARD", distance);
        break;
      }

      // Rotate in place
      cmd.linear.x  = 0.0;
      cmd.angular.z = std::clamp(2.0 * heading_error, -angular_speed_, angular_speed_);
      cmd_vel_pub_->publish(cmd);

      RCLCPP_INFO_THROTTLE(get_logger(), *get_clock(), 500,
        "[WP%zu] %s Rotating  err=%.1f°  cmd.z=%.3f",
        wp_index_, is_reverse ? "⬅" : "➡",
        heading_error * 180.0 / M_PI, cmd.angular.z);
      break;
    }

    // ════════════════════════════════════════════════════════════
    // DRIVE_STRAIGHT — Forward mission
    // linear.x = +speed  (forward)
    // angular.z = gentle correction
    // ════════════════════════════════════════════════════════════
    case State::DRIVE_STRAIGHT:
    {
      if (distance < xy_tolerance_) {
        stopRobot(); state_ = State::ROTATE_TO_THETA;
        RCLCPP_INFO(get_logger(), "[WP%zu] ✓ Forward goal reached!", wp_index_);
        break;
      }

      if (obstacle_front_) {
        stopRobot();
        RCLCPP_WARN_THROTTLE(get_logger(), *get_clock(), 1000,
          "[WP%zu] ⚠ Obstacle FRONT! Waiting...", wp_index_);
        break;
      }

      if (std::abs(heading_error) > 1.05) {
        stopRobot(); state_ = State::ROTATE_TO_HEADING;
        RCLCPP_WARN(get_logger(), "[WP%zu] Off course %.1f° — re-rotating",
          wp_index_, heading_error * 180.0 / M_PI);
        break;
      }

      double speed = linear_speed_;
      if (distance < 0.30)
        speed = std::max(0.05, linear_speed_ * (distance / 0.30));

      cmd.linear.x  = speed;   // POSITIVE = forward
      cmd.angular.z = std::clamp(0.5 * heading_error, -drive_correction_, drive_correction_);
      cmd_vel_pub_->publish(cmd);

      RCLCPP_INFO_THROTTLE(get_logger(), *get_clock(), 500,
        "[WP%zu] ▲ FORWARD  dist=%.2fm  spd=%.2f  err=%.1f°",
        wp_index_, distance, speed, heading_error * 180.0 / M_PI);
      break;
    }

    // ════════════════════════════════════════════════════════════
    // DRIVE_REVERSE — Reverse mission
    //
    // KEY FIX for straight-line reverse:
    //   During reversing, we track angle_to_goal directly.
    //   The robot's back needs to stay pointed at the goal.
    //   back_error = angle_to_goal - (robot_yaw + PI)
    //              = angle_to_goal - robot_yaw - PI
    //   Correction = +back_error  (same sign as forward)
    //   because diff drive angular.z turns left/right the same
    //   regardless of whether robot moves forward or backward.
    // ════════════════════════════════════════════════════════════
    case State::DRIVE_REVERSE:
    {
      if (distance < xy_tolerance_) {
        stopRobot(); state_ = State::ROTATE_TO_THETA;
        RCLCPP_INFO(get_logger(), "[WP%zu] ✓ Reverse goal reached!", wp_index_);
        break;
      }

      if (obstacle_rear_) {
        stopRobot();
        RCLCPP_WARN_THROTTLE(get_logger(), *get_clock(), 1000,
          "[WP%zu] ⚠ Obstacle REAR! Waiting...", wp_index_);
        break;
      }

      // Compute how much robot's BACK has drifted from goal direction
      // back_facing = robot_yaw + PI  (direction robot's back points)
      // back_error  = angle_to_goal - back_facing
      double back_facing = normalizeAngle(robot_yaw_ + M_PI);
      double back_error  = normalizeAngle(angle_to_goal - back_facing);

      // Re-rotate if back drifted too much from goal
      if (std::abs(back_error) > 1.05) {
        stopRobot(); state_ = State::ROTATE_TO_HEADING;
        RCLCPP_WARN(get_logger(),
          "[WP%zu] Reverse off course %.1f° — re-rotating",
          wp_index_, back_error * 180.0 / M_PI);
        break;
      }

      double speed = linear_speed_;
      if (distance < 0.30)
        speed = std::max(0.05, linear_speed_ * (distance / 0.30));

      // linear.x  = NEGATIVE  (reverse direction)
      // angular.z = +back_error correction  (same sign as forward!)
      //             When back drifts left  → back_error > 0 → turn left → corrects
      //             When back drifts right → back_error < 0 → turn right → corrects
      cmd.linear.x  = -speed;
      cmd.angular.z = std::clamp(0.5 * back_error, -drive_correction_, drive_correction_);
      cmd_vel_pub_->publish(cmd);

      RCLCPP_INFO_THROTTLE(get_logger(), *get_clock(), 500,
        "[WP%zu] ▼ REVERSE  dist=%.2fm  spd=%.2f  back_err=%.1f°",
        wp_index_, distance, speed, back_error * 180.0 / M_PI);
      break;
    }

    // ════════════════════════════════════════════════════════════
    // ROTATE_TO_THETA — rotate to final heading of waypoint
    //
    // rotation field in waypoints.yaml:
    //   "auto" = shortest path (default)
    //   "cw"   = clockwise       (angular.z always NEGATIVE)
    //   "ccw"  = anticlockwise   (angular.z always POSITIVE)
    // ════════════════════════════════════════════════════════════
    case State::ROTATE_TO_THETA:
    {
      if (std::abs(yaw_error) < yaw_tolerance_) {
        stopRobot(); state_ = State::WAYPOINT_DONE;
        RCLCPP_INFO(get_logger(),
          "[WP%zu] ✅ COMPLETE  x=%.2f y=%.2f theta=%.1f° [%s/%s/rot=%s]",
          wp_index_, wp.x, wp.y, wp.theta * 180.0 / M_PI,
          wp.type.c_str(), wp.mission.c_str(), wp.rotation.c_str());
        break;
      }

      // ── Determine angular.z sign based on rotation field ─────
      double rot_cmd = 0.0;

      if (wp.rotation == "cw") {
        // Clockwise = always negative angular.z
        // Force yaw_error negative so robot always turns CW
        // If yaw_error > 0 (CCW is shorter), override and go CW anyway
        double cw_error = (yaw_error > 0)
          ? (yaw_error - 2.0 * M_PI)   // convert CCW error → CW (full circle)
          : yaw_error;
        rot_cmd = std::clamp(2.0 * cw_error, -angular_speed_, -0.05);

        RCLCPP_INFO_THROTTLE(get_logger(), *get_clock(), 500,
          "[WP%zu] ↻ CW  theta=%.1f°  remaining=%.1f°  cmd=%.3f",
          wp_index_, wp.theta * 180.0 / M_PI,
          cw_error * 180.0 / M_PI, rot_cmd);

      } else if (wp.rotation == "ccw") {
        // Anticlockwise = always positive angular.z
        // If yaw_error < 0 (CW is shorter), override and go CCW anyway
        double ccw_error = (yaw_error < 0)
          ? (yaw_error + 2.0 * M_PI)   // convert CW error → CCW (full circle)
          : yaw_error;
        rot_cmd = std::clamp(2.0 * ccw_error, 0.05, angular_speed_);

        RCLCPP_INFO_THROTTLE(get_logger(), *get_clock(), 500,
          "[WP%zu] ↺ CCW  theta=%.1f°  remaining=%.1f°  cmd=%.3f",
          wp_index_, wp.theta * 180.0 / M_PI,
          ccw_error * 180.0 / M_PI, rot_cmd);

      } else {
        // "auto" = shortest path (standard behavior)
        rot_cmd = std::clamp(2.0 * yaw_error, -angular_speed_, angular_speed_);

        RCLCPP_INFO_THROTTLE(get_logger(), *get_clock(), 500,
          "[WP%zu] ↔ AUTO  theta=%.1f°  remaining=%.1f°  cmd=%.3f",
          wp_index_, wp.theta * 180.0 / M_PI,
          yaw_error * 180.0 / M_PI, rot_cmd);
      }

      cmd.linear.x  = 0.0;
      cmd.angular.z = rot_cmd;
      cmd_vel_pub_->publish(cmd);
      break;
    }

    // ════════════════════════════════════════════════════════════
    // WAYPOINT_DONE — check if station type, trigger PLC if needed
    // ════════════════════════════════════════════════════════════
    case State::WAYPOINT_DONE:
    {
      // If this is a "station" type AND plc_enabled → notify PLC bridge
      if (plc_enabled_ && wp.type == "station") {
        std::string station_name = wp.name.empty()
          ? ("station_" + std::to_string(wp_index_))
          : wp.name;

        RCLCPP_INFO(get_logger(),
          "[WP%zu] 🏭 STATION reached: [%s] → publishing /station_reached",
          wp_index_, station_name.c_str());

        std_msgs::msg::String smsg;
        smsg.data = station_name;
        station_pub_->publish(smsg);

        // Enter WAIT_PLC state — robot stays stopped until /plc_done
        plc_done_        = false;
        waiting_for_plc_ = true;
        state_           = State::WAIT_PLC;
        stopRobot();
        break;
      }

      // No PLC — advance to next waypoint immediately
      wp_index_++;
      if (wp_index_ < waypoints_.size()) {
        state_ = State::ROTATE_TO_HEADING;
        const Waypoint & nwp = waypoints_[wp_index_];
        RCLCPP_INFO(get_logger(), "─────────────────────────────────────────");
        RCLCPP_INFO(get_logger(),
          "→ WP[%zu/%zu] [%s/%s]  x=%.2f y=%.2f theta=%.1f°",
          wp_index_, waypoints_.size() - 1,
          nwp.type.c_str(), nwp.mission.c_str(),
          nwp.x, nwp.y, nwp.theta * 180.0 / M_PI);
      } else {
        state_ = State::CYCLE_DONE;
      }
      break;
    }

    // ════════════════════════════════════════════════════════════
    // WAIT_PLC — robot stopped at station, waiting for /plc_done
    // ════════════════════════════════════════════════════════════
    case State::WAIT_PLC:
    {
      stopRobot();

      if (plc_done_) {
        // PLC action complete — advance to next waypoint
        plc_done_        = false;
        waiting_for_plc_ = false;

        wp_index_++;
        if (wp_index_ < waypoints_.size()) {
          state_ = State::ROTATE_TO_HEADING;
          const Waypoint & nwp = waypoints_[wp_index_];
          RCLCPP_INFO(get_logger(), "─────────────────────────────────────────");
          RCLCPP_INFO(get_logger(),
            "→ WP[%zu/%zu] [%s/%s]  x=%.2f y=%.2f theta=%.1f°",
            wp_index_, waypoints_.size() - 1,
            nwp.type.c_str(), nwp.mission.c_str(),
            nwp.x, nwp.y, nwp.theta * 180.0 / M_PI);
        } else {
          state_ = State::CYCLE_DONE;
        }
      } else {
        // Still waiting — log every second
        RCLCPP_INFO_THROTTLE(get_logger(), *get_clock(), 2000,
          "[WP%zu] ⏳ Waiting for PLC to complete station action...", wp_index_);
      }
      break;
    }

    case State::IDLE:
    case State::ALL_DONE:
    case State::CYCLE_DONE:
    default:
      break;
  }
}

}  // namespace amr_pure_navigation

// ─── Global node pointer for signal handler ───────────────────────
static std::shared_ptr<amr_pure_navigation::WaypointNavigator> g_node;

static void signalHandler(int /*sig*/)
{
  // Publish zero velocity immediately on Ctrl+C
  if (g_node) {
    try {
      auto pub = g_node->create_publisher<geometry_msgs::msg::Twist>(
        "/diff_drive_controller/cmd_vel", 1);
      geometry_msgs::msg::Twist stop;
      pub->publish(stop);
      RCLCPP_WARN(g_node->get_logger(), "🛑 Ctrl+C — Robot STOPPED.");
    } catch (...) {}
  }
  rclcpp::shutdown();
}

int main(int argc, char ** argv)
{
  rclcpp::init(argc, argv);
  g_node = std::make_shared<amr_pure_navigation::WaypointNavigator>();

  // Register signal handlers so Ctrl+C stops the robot
  signal(SIGINT,  signalHandler);
  signal(SIGTERM, signalHandler);

  rclcpp::spin(g_node);

  // Extra safety stop after spin exits
  if (g_node) {
    try {
      auto pub = g_node->create_publisher<geometry_msgs::msg::Twist>(
        "/diff_drive_controller/cmd_vel", 1);
      geometry_msgs::msg::Twist stop;
      pub->publish(stop);
    } catch (...) {}
  }

  g_node.reset();
  rclcpp::shutdown();
  return 0;
}



// // ================================================================
// //  waypoint_navigator.cpp  v6  —  Forward + Reverse Mission
// //
// //  mission: forward → rotate to face goal → drive forward → rotate to theta
// //  mission: reverse → rotate BACK to goal → drive REVERSE → rotate to theta
// //
// //  WAYPOINTS YAML EXAMPLE:
// //    waypoints:
// //      - x: -10.0
// //        y:  10.0
// //        theta: 0.0
// //        type: station
// //        mission: reverse    ← robot drives backward to this point
// //
// //      - x:  20.0
// //        y:  10.0
// //        theta: 0.0
// //        type: waypoint
// //        mission: forward    ← robot drives forward to this point
// //
// //  CYCLE CONTROL via /set_cycles topic:
// //    ros2 topic pub --once /set_cycles std_msgs/msg/Int32 "data: 1"
// //    ros2 topic pub --once /set_cycles std_msgs/msg/Int32 "data: -1"  # forever
// //    ros2 topic pub --once /set_cycles std_msgs/msg/Int32 "data: 0"   # stop
// //
// //  CHECK STATUS:
// //    ros2 topic echo /nav_status
// // ================================================================

// #include "amr_pure_navigation/waypoint_navigator.hpp"

// namespace amr_pure_navigation
// {

// // ─── Constructor ──────────────────────────────────────────────────
// WaypointNavigator::WaypointNavigator(const rclcpp::NodeOptions & options)
// : Node("waypoint_navigator", options)
// {
//   declare_parameter<std::string>("waypoints_file",     "");
//   declare_parameter<std::string>("odom_topic",         "/odometry/filtered");
//   declare_parameter<std::string>("cmd_vel_topic",      "/diff_drive_controller/cmd_vel");
//   declare_parameter<std::string>("amcl_topic",         "/amcl_pose");
//   declare_parameter<double>     ("linear_speed",       0.20);
//   declare_parameter<double>     ("angular_speed",      0.40);
//   declare_parameter<double>     ("drive_correction",   0.15);
//   declare_parameter<double>     ("xy_tolerance",       0.10);
//   declare_parameter<double>     ("yaw_tolerance",      0.08);
//   declare_parameter<double>     ("heading_tolerance",  0.10);
//   declare_parameter<double>     ("obstacle_stop_dist", 0.40);
//   declare_parameter<bool>       ("stop_on_obstacle",   true);
//   declare_parameter<bool>       ("use_amcl",           true);

//   get_parameter("waypoints_file",    waypoints_file_);
//   get_parameter("odom_topic",        odom_topic_);
//   get_parameter("cmd_vel_topic",     cmd_vel_topic_);
//   get_parameter("amcl_topic",        amcl_topic_);
//   get_parameter("linear_speed",      linear_speed_);
//   get_parameter("angular_speed",     angular_speed_);
//   get_parameter("drive_correction",  drive_correction_);
//   get_parameter("xy_tolerance",      xy_tolerance_);
//   get_parameter("yaw_tolerance",     yaw_tolerance_);
//   get_parameter("heading_tolerance", heading_tolerance_);
//   get_parameter("obstacle_stop_dist",obstacle_stop_dist_);
//   get_parameter("stop_on_obstacle",  stop_on_obstacle_);
//   get_parameter("use_amcl",          use_amcl_);

//   if (!loadWaypoints(waypoints_file_)) {
//     RCLCPP_FATAL(get_logger(), "Cannot load waypoints: %s", waypoints_file_.c_str());
//     init_failed_ = true;
//     return;
//   }

//   RCLCPP_INFO(get_logger(), "=============================================");
//   RCLCPP_INFO(get_logger(), "  AMR Navigation v6 - Forward + Reverse");
//   RCLCPP_INFO(get_logger(), "  Waypoints    : %zu",    waypoints_.size());
//   RCLCPP_INFO(get_logger(), "  Odom topic   : %s",     odom_topic_.c_str());
//   RCLCPP_INFO(get_logger(), "  Mode         : %s",     use_amcl_ ? "AMCL map frame" : "Odom only");
//   RCLCPP_INFO(get_logger(), "  Linear speed : %.2f m/s",   linear_speed_);
//   RCLCPP_INFO(get_logger(), "  Angular speed: %.2f rad/s", angular_speed_);
//   RCLCPP_INFO(get_logger(), "=============================================");
//   RCLCPP_INFO(get_logger(), "  Waiting for /set_cycles command...");
//   RCLCPP_INFO(get_logger(), "  ros2 topic pub --once /set_cycles std_msgs/msg/Int32 \"data: 1\"");
//   RCLCPP_INFO(get_logger(), "=============================================");

//   cmd_vel_pub_ = create_publisher<geometry_msgs::msg::Twist>(cmd_vel_topic_, 10);
//   status_pub_  = create_publisher<std_msgs::msg::String>("/nav_status", 10);

//   cycles_sub_ = create_subscription<std_msgs::msg::Int32>(
//     "/set_cycles", 10,
//     std::bind(&WaypointNavigator::cyclesCallback, this, std::placeholders::_1));

//   if (use_amcl_) {
//     amcl_sub_ = create_subscription<geometry_msgs::msg::PoseWithCovarianceStamped>(
//       amcl_topic_, 10,
//       std::bind(&WaypointNavigator::amclCallback, this, std::placeholders::_1));
//   }

//   odom_sub_ = create_subscription<nav_msgs::msg::Odometry>(
//     odom_topic_, 10,
//     std::bind(&WaypointNavigator::odomCallback, this, std::placeholders::_1));

//   scan_sub_ = create_subscription<sensor_msgs::msg::LaserScan>(
//     "/scan", 10,
//     std::bind(&WaypointNavigator::scanCallback, this, std::placeholders::_1));

//   timer_ = create_wall_timer(
//     std::chrono::milliseconds(50),
//     std::bind(&WaypointNavigator::controlLoop, this));
// }

// // ─── Cycles Callback ──────────────────────────────────────────────
// void WaypointNavigator::cyclesCallback(const std_msgs::msg::Int32::SharedPtr msg)
// {
//   int requested = msg->data;

//   if (requested == 0) {
//     stopRobot();
//     state_ = State::ALL_DONE;
//     max_cycles_ = 0; loop_forever_ = false;
//     RCLCPP_WARN(get_logger(), "🛑 STOP command! Robot halted.");
//     publishStatus("STOPPED by user");
//     return;
//   }

//   if (requested == -1) {
//     loop_forever_ = true; max_cycles_ = -1;
//     cycles_done_ = 0; wp_index_ = 0;
//     if (pose_received_) {
//       state_ = State::ROTATE_TO_HEADING;
//       RCLCPP_INFO(get_logger(), "🔁 LOOP FOREVER started!");
//     }
//     publishStatus("RUNNING - loop forever");
//     return;
//   }

//   if (requested > 0) {
//     // ── Robot is currently running — add more cycles on top ───
//     if (state_ != State::IDLE && state_ != State::ALL_DONE) {
//       max_cycles_ = cycles_done_ + requested;
//       loop_forever_ = false;
//       RCLCPP_INFO(get_logger(), "🔄 %d more cycle(s) added. Total=%d", requested, max_cycles_);
//       char buf[64]; snprintf(buf, sizeof(buf), "RUNNING - %d more added", requested);
//       publishStatus(buf);
//       return;
//     }

//     // ── Fresh start (IDLE or ALL_DONE — both reset fully) ─────
//     loop_forever_ = false;
//     max_cycles_   = requested;
//     cycles_done_  = 0;       // ← CRITICAL: reset cycle counter
//     wp_index_     = 0;       // ← CRITICAL: reset waypoint index

//     if (pose_received_) {
//       state_ = State::ROTATE_TO_HEADING;
//       RCLCPP_INFO(get_logger(), "🚀 Starting %d cycle(s)! (fresh start)", requested);
//     } else {
//       state_ = State::IDLE;  // stay IDLE until pose arrives
//       RCLCPP_INFO(get_logger(), "✅ %d cycle(s) queued. Waiting for pose...", requested);
//     }
//     char buf[64]; snprintf(buf, sizeof(buf), "STARTING %d cycles", requested);
//     publishStatus(buf);
//   }
// }

// // ─── AMCL Callback ────────────────────────────────────────────────
// void WaypointNavigator::amclCallback(
//   const geometry_msgs::msg::PoseWithCovarianceStamped::SharedPtr msg)
// {
//   if (init_failed_) return;
//   robot_x_   = msg->pose.pose.position.x;
//   robot_y_   = msg->pose.pose.position.y;
//   robot_yaw_ = quaternionToYaw(msg->pose.pose.orientation);

//   if (!pose_received_) {
//     pose_received_ = true;
//     RCLCPP_INFO(get_logger(), "✅ AMCL active! x=%.2f y=%.2f yaw=%.1f°",
//       robot_x_, robot_y_, robot_yaw_ * 180.0 / M_PI);
//     if (max_cycles_ != 0 && state_ == State::IDLE) {
//       state_ = State::ROTATE_TO_HEADING;
//       RCLCPP_INFO(get_logger(), "🚀 Pose received — starting!");
//     }
//   }
// }

// // ─── Odom Callback ────────────────────────────────────────────────
// void WaypointNavigator::odomCallback(const nav_msgs::msg::Odometry::SharedPtr msg)
// {
//   if (init_failed_) return;
//   if (use_amcl_ && pose_received_) return;

//   robot_x_   = msg->pose.pose.position.x;
//   robot_y_   = msg->pose.pose.position.y;
//   robot_yaw_ = quaternionToYaw(msg->pose.pose.orientation);

//   if (!pose_received_) {
//     pose_received_ = true;
//     RCLCPP_INFO(get_logger(), "✅ Odom active! x=%.2f y=%.2f", robot_x_, robot_y_);
//     if (max_cycles_ != 0 && state_ == State::IDLE)
//       state_ = State::ROTATE_TO_HEADING;
//   }
// }

// // ─── Scan Callback ────────────────────────────────────────────────
// void WaypointNavigator::scanCallback(const sensor_msgs::msg::LaserScan::SharedPtr msg)
// {
//   if (!stop_on_obstacle_) return;
//   obstacle_ahead_ = false;

//   // For REVERSE: check rear sector (±30° from back)
//   // For FORWARD: check front sector (±30° from front)
//   // We store both
//   obstacle_front_ = false;
//   obstacle_rear_  = false;

//   int n = static_cast<int>(msg->ranges.size());
//   for (int i = 0; i < n; ++i) {
//     float angle = msg->angle_min + i * msg->angle_increment;
//     float r     = msg->ranges[i];
//     if (!std::isfinite(r) || r < 0.01f || r >= static_cast<float>(obstacle_stop_dist_)) continue;

//     // Front sector ±30°
//     if (angle >= -0.524f && angle <= 0.524f)
//       obstacle_front_ = true;

//     // Rear sector ±30° (around ±PI)
//     if (std::abs(std::abs(angle) - M_PI) < 0.524f)
//       obstacle_rear_ = true;
//   }
// }

// // ─── Helpers ──────────────────────────────────────────────────────
// double WaypointNavigator::quaternionToYaw(const geometry_msgs::msg::Quaternion & q)
// {
//   return std::atan2(
//     2.0 * (q.w * q.z + q.x * q.y),
//     1.0 - 2.0 * (q.y * q.y + q.z * q.z));
// }

// double WaypointNavigator::normalizeAngle(double a)
// {
//   while (a >  M_PI) a -= 2.0 * M_PI;
//   while (a < -M_PI) a += 2.0 * M_PI;
//   return a;
// }

// void WaypointNavigator::stopRobot()
// {
//   cmd_vel_pub_->publish(geometry_msgs::msg::Twist());
// }

// void WaypointNavigator::publishStatus(const std::string & text)
// {
//   std_msgs::msg::String msg;
//   msg.data = text;
//   status_pub_->publish(msg);
// }

// bool WaypointNavigator::isOnlyRotation(const Waypoint & prev, const Waypoint & curr)
// {
//   return (std::abs(curr.x - prev.x) < xy_tolerance_ &&
//           std::abs(curr.y - prev.y) < xy_tolerance_);
// }

// const char * WaypointNavigator::stateStr()
// {
//   switch (state_) {
//     case State::IDLE:              return "IDLE";
//     case State::ROTATE_TO_HEADING: return "ROT_HEADING";
//     case State::DRIVE_STRAIGHT:    return "DRIVE_FWD";
//     case State::DRIVE_REVERSE:     return "DRIVE_REV";
//     case State::ROTATE_TO_THETA:   return "ROT_THETA";
//     case State::WAYPOINT_DONE:     return "WP_DONE";
//     case State::CYCLE_DONE:        return "CYCLE_DONE";
//     case State::ALL_DONE:          return "ALL_DONE";
//     default:                       return "UNKNOWN";
//   }
// }

// // ─── Load Waypoints ───────────────────────────────────────────────
// bool WaypointNavigator::loadWaypoints(const std::string & path)
// {
//   if (path.empty()) { RCLCPP_ERROR(get_logger(), "waypoints_file is empty!"); return false; }
//   std::ifstream f(path);
//   if (!f.good()) { RCLCPP_ERROR(get_logger(), "Cannot open: %s", path.c_str()); return false; }
//   f.seekg(0, std::ios::end);
//   if (f.tellg() == 0) { RCLCPP_ERROR(get_logger(), "File empty: %s", path.c_str()); return false; }
//   f.close();

//   try {
//     YAML::Node root = YAML::LoadFile(path);
//     YAML::Node wps  = root["waypoints"];
//     if (!wps || !wps.IsSequence()) {
//       RCLCPP_ERROR(get_logger(), "No 'waypoints' list in YAML"); return false;
//     }
//     for (size_t i = 0; i < wps.size(); ++i) {
//       Waypoint w;
//       w.x       = wps[i]["x"].as<double>();
//       w.y       = wps[i]["y"].as<double>();
//       w.theta   = wps[i]["theta"].as<double>();
//       w.type    = wps[i]["type"]    ? wps[i]["type"].as<std::string>()    : "waypoint";
//       w.mission = wps[i]["mission"] ? wps[i]["mission"].as<std::string>() : "forward";
//       waypoints_.push_back(w);

//       RCLCPP_INFO(get_logger(),
//         "  WP[%02zu] %-10s %-8s x=%.2f y=%.2f theta=%.1f°",
//         i, w.type.c_str(), w.mission.c_str(),
//         w.x, w.y, w.theta * 180.0 / M_PI);
//     }
//   } catch (const std::exception & e) {
//     RCLCPP_ERROR(get_logger(), "YAML error: %s", e.what()); return false;
//   }
//   return !waypoints_.empty();
// }

// // ─── Main Control Loop  20 Hz ─────────────────────────────────────
// void WaypointNavigator::controlLoop()
// {
//   if (init_failed_ || !pose_received_) return;
//   if (state_ == State::IDLE)     { stopRobot(); return; }
//   if (state_ == State::ALL_DONE) {
//     stopRobot();
//     // Stay here — cyclesCallback will reset state when user sends new command
//     return;
//   }

//   if (wp_index_ >= waypoints_.size()) {
//     state_ = State::CYCLE_DONE; return;
//   }

//   // ── CYCLE DONE ───────────────────────────────────────────────
//   if (state_ == State::CYCLE_DONE) {
//     cycles_done_++;
//     if (loop_forever_ || cycles_done_ < max_cycles_) {
//       wp_index_ = 0;
//       state_    = State::ROTATE_TO_HEADING;
//       RCLCPP_INFO(get_logger(), loop_forever_ ?
//         "🔁 Cycle %d done — looping!" : "🔄 Cycle %d/%d done — next cycle!",
//         cycles_done_, max_cycles_);
//     } else {
//       state_ = State::ALL_DONE; stopRobot();
//       RCLCPP_INFO(get_logger(), "✅ ALL %d CYCLE(S) DONE!", cycles_done_);
//     }
//     return;
//   }

//   const Waypoint & wp = waypoints_[wp_index_];
//   const bool is_reverse = (wp.mission == "reverse");

//   double dx            = wp.x - robot_x_;
//   double dy            = wp.y - robot_y_;
//   double distance      = std::hypot(dx, dy);
//   double angle_to_goal = std::atan2(dy, dx);

//   // For reverse: robot needs its BACK to face goal
//   // So target heading = angle_to_goal + PI
//   double heading_target = is_reverse
//     ? normalizeAngle(angle_to_goal + M_PI)
//     : angle_to_goal;

//   double heading_error = normalizeAngle(heading_target - robot_yaw_);
//   double yaw_error     = normalizeAngle(wp.theta - robot_yaw_);

//   geometry_msgs::msg::Twist cmd;

//   // 1 second log
//   if (++log_counter_ >= 20) {
//     log_counter_ = 0;
//     RCLCPP_INFO(get_logger(),
//       "[%s | %s | WP%zu] pos(%.2f,%.2f,%.1f°)→(%.2f,%.2f,%.1f°) dist=%.2fm",
//       stateStr(), is_reverse ? "REV" : "FWD", wp_index_,
//       robot_x_, robot_y_, robot_yaw_ * 180.0 / M_PI,
//       wp.x, wp.y, wp.theta * 180.0 / M_PI, distance);
//   }

//   switch (state_)
//   {
//     // ════════════════════════════════════════════════════════════
//     // ROTATE_TO_HEADING
//     // Forward:  rotate until robot FACES the goal
//     // Reverse:  rotate until robot BACK is toward the goal
//     // ════════════════════════════════════════════════════════════
//     case State::ROTATE_TO_HEADING:
//     {
//       Waypoint prev = (wp_index_ > 0) ?
//         waypoints_[wp_index_ - 1] :
//         Waypoint{robot_x_, robot_y_, robot_yaw_};

//       if (isOnlyRotation(prev, wp)) {
//         state_ = State::ROTATE_TO_THETA;
//         RCLCPP_INFO(get_logger(), "[WP%zu] Pure rotation → %.1f°",
//           wp_index_, wp.theta * 180.0 / M_PI);
//         break;
//       }

//       if (distance < xy_tolerance_) {
//         stopRobot(); state_ = State::ROTATE_TO_THETA;
//         break;
//       }

//       if (std::abs(heading_error) < heading_tolerance_) {
//         stopRobot();
//         // Go to correct drive state based on mission
//         state_ = is_reverse ? State::DRIVE_REVERSE : State::DRIVE_STRAIGHT;
//         RCLCPP_INFO(get_logger(),
//           "[WP%zu] ✓ Heading aligned (%.1f°). %s → dist=%.2fm",
//           wp_index_, heading_error * 180.0 / M_PI,
//           is_reverse ? "REVERSING" : "DRIVING FORWARD", distance);
//         break;
//       }

//       // Rotate in place
//       cmd.linear.x  = 0.0;
//       cmd.angular.z = std::clamp(2.0 * heading_error, -angular_speed_, angular_speed_);
//       cmd_vel_pub_->publish(cmd);

//       RCLCPP_INFO_THROTTLE(get_logger(), *get_clock(), 500,
//         "[WP%zu] %s Rotating  err=%.1f°  cmd.z=%.3f",
//         wp_index_, is_reverse ? "⬅" : "➡",
//         heading_error * 180.0 / M_PI, cmd.angular.z);
//       break;
//     }

//     // ════════════════════════════════════════════════════════════
//     // DRIVE_STRAIGHT — Forward mission
//     // linear.x = +speed  (forward)
//     // angular.z = gentle correction
//     // ════════════════════════════════════════════════════════════
//     case State::DRIVE_STRAIGHT:
//     {
//       if (distance < xy_tolerance_) {
//         stopRobot(); state_ = State::ROTATE_TO_THETA;
//         RCLCPP_INFO(get_logger(), "[WP%zu] ✓ Forward goal reached!", wp_index_);
//         break;
//       }

//       if (obstacle_front_) {
//         stopRobot();
//         RCLCPP_WARN_THROTTLE(get_logger(), *get_clock(), 1000,
//           "[WP%zu] ⚠ Obstacle FRONT! Waiting...", wp_index_);
//         break;
//       }

//       if (std::abs(heading_error) > 1.05) {
//         stopRobot(); state_ = State::ROTATE_TO_HEADING;
//         RCLCPP_WARN(get_logger(), "[WP%zu] Off course %.1f° — re-rotating",
//           wp_index_, heading_error * 180.0 / M_PI);
//         break;
//       }

//       double speed = linear_speed_;
//       if (distance < 0.30)
//         speed = std::max(0.05, linear_speed_ * (distance / 0.30));

//       cmd.linear.x  = speed;   // POSITIVE = forward
//       cmd.angular.z = std::clamp(0.5 * heading_error, -drive_correction_, drive_correction_);
//       cmd_vel_pub_->publish(cmd);

//       RCLCPP_INFO_THROTTLE(get_logger(), *get_clock(), 500,
//         "[WP%zu] ▲ FORWARD  dist=%.2fm  spd=%.2f  err=%.1f°",
//         wp_index_, distance, speed, heading_error * 180.0 / M_PI);
//       break;
//     }

//     // ════════════════════════════════════════════════════════════
//     // DRIVE_REVERSE — Reverse mission
//     //
//     // KEY FIX for straight-line reverse:
//     //   During reversing, we track angle_to_goal directly.
//     //   The robot's back needs to stay pointed at the goal.
//     //   back_error = angle_to_goal - (robot_yaw + PI)
//     //              = angle_to_goal - robot_yaw - PI
//     //   Correction = +back_error  (same sign as forward)
//     //   because diff drive angular.z turns left/right the same
//     //   regardless of whether robot moves forward or backward.
//     // ════════════════════════════════════════════════════════════
//     case State::DRIVE_REVERSE:
//     {
//       if (distance < xy_tolerance_) {
//         stopRobot(); state_ = State::ROTATE_TO_THETA;
//         RCLCPP_INFO(get_logger(), "[WP%zu] ✓ Reverse goal reached!", wp_index_);
//         break;
//       }

//       if (obstacle_rear_) {
//         stopRobot();
//         RCLCPP_WARN_THROTTLE(get_logger(), *get_clock(), 1000,
//           "[WP%zu] ⚠ Obstacle REAR! Waiting...", wp_index_);
//         break;
//       }

//       // Compute how much robot's BACK has drifted from goal direction
//       // back_facing = robot_yaw + PI  (direction robot's back points)
//       // back_error  = angle_to_goal - back_facing
//       double back_facing = normalizeAngle(robot_yaw_ + M_PI);
//       double back_error  = normalizeAngle(angle_to_goal - back_facing);

//       // Re-rotate if back drifted too much from goal
//       if (std::abs(back_error) > 1.05) {
//         stopRobot(); state_ = State::ROTATE_TO_HEADING;
//         RCLCPP_WARN(get_logger(),
//           "[WP%zu] Reverse off course %.1f° — re-rotating",
//           wp_index_, back_error * 180.0 / M_PI);
//         break;
//       }

//       double speed = linear_speed_;
//       if (distance < 0.30)
//         speed = std::max(0.05, linear_speed_ * (distance / 0.30));

//       // linear.x  = NEGATIVE  (reverse direction)
//       // angular.z = +back_error correction  (same sign as forward!)
//       //             When back drifts left  → back_error > 0 → turn left → corrects
//       //             When back drifts right → back_error < 0 → turn right → corrects
//       cmd.linear.x  = -speed;
//       cmd.angular.z = std::clamp(0.5 * back_error, -drive_correction_, drive_correction_);
//       cmd_vel_pub_->publish(cmd);

//       RCLCPP_INFO_THROTTLE(get_logger(), *get_clock(), 500,
//         "[WP%zu] ▼ REVERSE  dist=%.2fm  spd=%.2f  back_err=%.1f°",
//         wp_index_, distance, speed, back_error * 180.0 / M_PI);
//       break;
//     }

//     // ════════════════════════════════════════════════════════════
//     // ROTATE_TO_THETA — rotate to final heading of waypoint
//     // ════════════════════════════════════════════════════════════
//     case State::ROTATE_TO_THETA:
//     {
//       if (std::abs(yaw_error) < yaw_tolerance_) {
//         stopRobot(); state_ = State::WAYPOINT_DONE;
//         RCLCPP_INFO(get_logger(),
//           "[WP%zu] ✅ COMPLETE  x=%.2f y=%.2f theta=%.1f° [%s/%s]",
//           wp_index_, wp.x, wp.y, wp.theta * 180.0 / M_PI,
//           wp.type.c_str(), wp.mission.c_str());
//         break;
//       }

//       cmd.linear.x  = 0.0;
//       cmd.angular.z = std::clamp(2.0 * yaw_error, -angular_speed_, angular_speed_);
//       cmd_vel_pub_->publish(cmd);

//       RCLCPP_INFO_THROTTLE(get_logger(), *get_clock(), 500,
//         "[WP%zu] Rotating to final theta=%.1f°  remaining=%.1f°",
//         wp_index_, wp.theta * 180.0 / M_PI, yaw_error * 180.0 / M_PI);
//       break;
//     }

//     // ════════════════════════════════════════════════════════════
//     // WAYPOINT_DONE — advance to next
//     // ════════════════════════════════════════════════════════════
//     case State::WAYPOINT_DONE:
//     {
//       wp_index_++;
//       if (wp_index_ < waypoints_.size()) {
//         state_ = State::ROTATE_TO_HEADING;
//         const Waypoint & nwp = waypoints_[wp_index_];
//         RCLCPP_INFO(get_logger(), "─────────────────────────────────────────");
//         RCLCPP_INFO(get_logger(),
//           "→ WP[%zu/%zu] [%s/%s]  x=%.2f y=%.2f theta=%.1f°",
//           wp_index_, waypoints_.size() - 1,
//           nwp.type.c_str(), nwp.mission.c_str(),
//           nwp.x, nwp.y, nwp.theta * 180.0 / M_PI);
//       } else {
//         state_ = State::CYCLE_DONE;
//       }
//       break;
//     }

//     case State::IDLE:
//     case State::ALL_DONE:
//     case State::CYCLE_DONE:
//     default:
//       break;
//   }
// }

// }  // namespace amr_pure_navigation

// int main(int argc, char ** argv)
// {
//   rclcpp::init(argc, argv);
//   auto node = std::make_shared<amr_pure_navigation::WaypointNavigator>();
//   rclcpp::spin(node);
//   rclcpp::shutdown();
//   return 0;
// }




// //Perfect (some time rotact wrong direaction)

// // ================================================================
// //  waypoint_navigator.cpp  v5  —  Cycle Control via ROS2 Topic
// //
// //  HOW CYCLES WORK:
// //    Robot starts in IDLE — waits for your command
// //    You send a number to /set_cycles topic:
// //      1  = run once
// //      3  = run 3 times then stop
// //      -1 = loop forever
// //      0  = stop immediately
// //
// //  SEND COMMAND EXAMPLE:
// //    ros2 topic pub --once /set_cycles std_msgs/msg/Int32 "data: 3"
// //    ros2 topic pub --once /set_cycles std_msgs/msg/Int32 "data: -1"
// //    ros2 topic pub --once /set_cycles std_msgs/msg/Int32 "data: 0"
// //
// //  CHECK STATUS:
// //    ros2 topic echo /nav_status
// //
// //  TOPICS:
// //    Subscribes: /amcl_pose                     (robot position on map)
// //    Subscribes: /diff_drive_controller/odom    (fallback position)
// //    Subscribes: /scan                          (obstacle detection)
// //    Subscribes: /set_cycles  std_msgs/Int32    (your cycle command)
// //    Publishes:  /diff_drive_controller/cmd_vel (move robot)
// //    Publishes:  /nav_status  std_msgs/String   (current status)
// // ================================================================

// #include "amr_pure_navigation/waypoint_navigator.hpp"

// namespace amr_pure_navigation
// {

// // ─── Constructor ──────────────────────────────────────────────────
// WaypointNavigator::WaypointNavigator(const rclcpp::NodeOptions & options)
// : Node("waypoint_navigator", options)
// {
//   // ── Parameters ────────────────────────────────────────────────
//   declare_parameter<std::string>("waypoints_file",     "");
//   declare_parameter<std::string>("odom_topic",         "/diff_drive_controller/odom");
//   declare_parameter<std::string>("cmd_vel_topic",      "/diff_drive_controller/cmd_vel");
//   declare_parameter<std::string>("amcl_topic",         "/amcl_pose");
//   declare_parameter<double>     ("linear_speed",       0.20);
//   declare_parameter<double>     ("angular_speed",      0.40);
//   declare_parameter<double>     ("drive_correction",   0.15);
//   declare_parameter<double>     ("xy_tolerance",       0.10);
//   declare_parameter<double>     ("yaw_tolerance",      0.08);
//   declare_parameter<double>     ("heading_tolerance",  0.10);
//   declare_parameter<double>     ("obstacle_stop_dist", 0.40);
//   declare_parameter<bool>       ("stop_on_obstacle",   true);
//   declare_parameter<bool>       ("use_amcl",           true);

//   get_parameter("waypoints_file",    waypoints_file_);
//   get_parameter("odom_topic",        odom_topic_);
//   get_parameter("cmd_vel_topic",     cmd_vel_topic_);
//   get_parameter("amcl_topic",        amcl_topic_);
//   get_parameter("linear_speed",      linear_speed_);
//   get_parameter("angular_speed",     angular_speed_);
//   get_parameter("drive_correction",  drive_correction_);
//   get_parameter("xy_tolerance",      xy_tolerance_);
//   get_parameter("yaw_tolerance",     yaw_tolerance_);
//   get_parameter("heading_tolerance", heading_tolerance_);
//   get_parameter("obstacle_stop_dist",obstacle_stop_dist_);
//   get_parameter("stop_on_obstacle",  stop_on_obstacle_);
//   get_parameter("use_amcl",          use_amcl_);

//   // ── Load waypoints ────────────────────────────────────────────
//   if (!loadWaypoints(waypoints_file_)) {
//     RCLCPP_FATAL(get_logger(), "Cannot load waypoints: %s", waypoints_file_.c_str());
//     init_failed_ = true;
//     return;
//   }

//   // ── Startup info ──────────────────────────────────────────────
//   RCLCPP_INFO(get_logger(), "=============================================");
//   RCLCPP_INFO(get_logger(), "  AMR Navigation v5 - Cycle Control");
//   RCLCPP_INFO(get_logger(), "  Waypoints    : %zu",    waypoints_.size());
//   RCLCPP_INFO(get_logger(), "  Mode         : %s",     use_amcl_ ? "AMCL map frame" : "Odom only");
//   RCLCPP_INFO(get_logger(), "  Linear speed : %.2f m/s",   linear_speed_);
//   RCLCPP_INFO(get_logger(), "  Angular speed: %.2f rad/s", angular_speed_);
//   RCLCPP_INFO(get_logger(), "=============================================");
//   RCLCPP_INFO(get_logger(), "  ⏳ WAITING FOR CYCLE COMMAND...");
//   RCLCPP_INFO(get_logger(), "");
//   RCLCPP_INFO(get_logger(), "  Send command to start:");
//   RCLCPP_INFO(get_logger(), "  ros2 topic pub --once /set_cycles std_msgs/msg/Int32 \"data: 1\"");
//   RCLCPP_INFO(get_logger(), "  ros2 topic pub --once /set_cycles std_msgs/msg/Int32 \"data: 3\"");
//   RCLCPP_INFO(get_logger(), "  ros2 topic pub --once /set_cycles std_msgs/msg/Int32 \"data: -1\"  # forever");
//   RCLCPP_INFO(get_logger(), "  ros2 topic pub --once /set_cycles std_msgs/msg/Int32 \"data: 0\"   # stop");
//   RCLCPP_INFO(get_logger(), "=============================================");

//   // ── Publishers ────────────────────────────────────────────────
//   cmd_vel_pub_ = create_publisher<geometry_msgs::msg::Twist>(cmd_vel_topic_, 10);
//   status_pub_  = create_publisher<std_msgs::msg::String>("/nav_status", 10);

//   // ── Subscribers ───────────────────────────────────────────────
//   // Cycle command from user
//   cycles_sub_ = create_subscription<std_msgs::msg::Int32>(
//     "/set_cycles", 10,
//     std::bind(&WaypointNavigator::cyclesCallback, this, std::placeholders::_1));

//   // Position source
//   if (use_amcl_) {
//     amcl_sub_ = create_subscription<geometry_msgs::msg::PoseWithCovarianceStamped>(
//       amcl_topic_, 10,
//       std::bind(&WaypointNavigator::amclCallback, this, std::placeholders::_1));
//   }

//   odom_sub_ = create_subscription<nav_msgs::msg::Odometry>(
//     odom_topic_, 10,
//     std::bind(&WaypointNavigator::odomCallback, this, std::placeholders::_1));

//   scan_sub_ = create_subscription<sensor_msgs::msg::LaserScan>(
//     "/scan", 10,
//     std::bind(&WaypointNavigator::scanCallback, this, std::placeholders::_1));

//   // 20 Hz control loop
//   timer_ = create_wall_timer(
//     std::chrono::milliseconds(50),
//     std::bind(&WaypointNavigator::controlLoop, this));
// }

// // ─── Cycle Command Callback ───────────────────────────────────────
// // User sends: ros2 topic pub --once /set_cycles std_msgs/msg/Int32 "data: N"
// //   N > 0  : run N cycles then stop
// //   N = -1 : loop forever
// //   N = 0  : stop immediately
// void WaypointNavigator::cyclesCallback(const std_msgs::msg::Int32::SharedPtr msg)
// {
//   int requested = msg->data;

//   // ── STOP command ──────────────────────────────────────────────
//   if (requested == 0) {
//     stopRobot();
//     state_        = State::ALL_DONE;
//     max_cycles_   = 0;
//     loop_forever_ = false;
//     RCLCPP_WARN(get_logger(), "🛑 STOP command received! Robot stopped.");
//     publishStatus("STOPPED by user command");
//     return;
//   }

//   // ── LOOP FOREVER command ──────────────────────────────────────
//   if (requested == -1) {
//     loop_forever_ = true;
//     max_cycles_   = -1;
//     cycles_done_  = 0;
//     wp_index_     = 0;

//     if (pose_received_) {
//       state_ = State::ROTATE_TO_HEADING;
//       RCLCPP_INFO(get_logger(), "🔁 LOOP FOREVER started!");
//       publishStatus("RUNNING - loop forever");
//     } else {
//       RCLCPP_INFO(get_logger(), "🔁 Loop forever set. Waiting for pose...");
//       publishStatus("WAITING for pose - loop forever queued");
//     }
//     return;
//   }

//   // ── RUN N CYCLES command ──────────────────────────────────────
//   if (requested > 0) {
//     // If already running, update remaining cycles
//     if (state_ != State::IDLE && state_ != State::ALL_DONE) {
//       int remaining = requested;
//       max_cycles_   = cycles_done_ + remaining;
//       loop_forever_ = false;
//       RCLCPP_INFO(get_logger(),
//         "🔄 Cycles updated! Will complete %d more cycle(s) (total=%d)",
//         remaining, max_cycles_);
//       char buf[128];
//       snprintf(buf, sizeof(buf), "RUNNING - %d more cycles requested", remaining);
//       publishStatus(buf);
//       return;
//     }

//     // Fresh start
//     loop_forever_ = false;
//     max_cycles_   = requested;
//     cycles_done_  = 0;
//     wp_index_     = 0;

//     if (pose_received_) {
//       state_ = State::ROTATE_TO_HEADING;
//       RCLCPP_INFO(get_logger(),
//         "🚀 Starting %d cycle(s)!", requested);
//       char buf[128];
//       snprintf(buf, sizeof(buf), "RUNNING - %d cycle(s) requested", requested);
//       publishStatus(buf);
//     } else {
//       RCLCPP_INFO(get_logger(),
//         "✅ %d cycle(s) queued. Waiting for pose (set 2D Pose in RViz)...",
//         requested);
//       char buf[128];
//       snprintf(buf, sizeof(buf), "WAITING for pose - %d cycle(s) queued", requested);
//       publishStatus(buf);
//     }
//   }
// }

// // ─── AMCL Callback ───────────────────────────────────────────────
// void WaypointNavigator::amclCallback(
//   const geometry_msgs::msg::PoseWithCovarianceStamped::SharedPtr msg)
// {
//   if (init_failed_) return;

//   robot_x_   = msg->pose.pose.position.x;
//   robot_y_   = msg->pose.pose.position.y;
//   robot_yaw_ = quaternionToYaw(msg->pose.pose.orientation);

//   if (!pose_received_) {
//     pose_received_ = true;
//     RCLCPP_INFO(get_logger(), "✅ AMCL active! pos: x=%.2f y=%.2f yaw=%.1f°",
//       robot_x_, robot_y_, robot_yaw_ * 180.0 / M_PI);

//     // If user already sent cycles command — start now
//     if (max_cycles_ != 0 && state_ == State::IDLE) {
//       state_ = State::ROTATE_TO_HEADING;
//       RCLCPP_INFO(get_logger(), "🚀 Pose received — starting queued cycles!");
//     }
//   }
// }

// // ─── Odom Callback ───────────────────────────────────────────────
// void WaypointNavigator::odomCallback(const nav_msgs::msg::Odometry::SharedPtr msg)
// {
//   if (init_failed_) return;
//   if (use_amcl_ && pose_received_) return;

//   robot_x_   = msg->pose.pose.position.x;
//   robot_y_   = msg->pose.pose.position.y;
//   robot_yaw_ = quaternionToYaw(msg->pose.pose.orientation);

//   if (!pose_received_) {
//     pose_received_ = true;
//     RCLCPP_INFO(get_logger(),
//       use_amcl_ ?
//       "⚠ Using ODOM fallback. Set 2D Pose Estimate in RViz for AMCL!" :
//       "✅ Odom active! x=%.2f y=%.2f — ready for cycle command.",
//       robot_x_, robot_y_);

//     if (max_cycles_ != 0 && state_ == State::IDLE) {
//       state_ = State::ROTATE_TO_HEADING;
//     }
//   }
// }

// // ─── Scan Callback ───────────────────────────────────────────────
// void WaypointNavigator::scanCallback(const sensor_msgs::msg::LaserScan::SharedPtr msg)
// {
//   if (!stop_on_obstacle_) return;
//   obstacle_ahead_ = false;
//   for (int i = 0; i < static_cast<int>(msg->ranges.size()); ++i) {
//     float angle = msg->angle_min + i * msg->angle_increment;
//     if (angle < -0.524f || angle > 0.524f) continue;
//     float r = msg->ranges[i];
//     if (std::isfinite(r) && r > 0.01f && r < static_cast<float>(obstacle_stop_dist_)) {
//       obstacle_ahead_ = true;
//       return;
//     }
//   }
// }

// // ─── Helpers ──────────────────────────────────────────────────────
// double WaypointNavigator::quaternionToYaw(const geometry_msgs::msg::Quaternion & q)
// {
//   return std::atan2(
//     2.0 * (q.w * q.z + q.x * q.y),
//     1.0 - 2.0 * (q.y * q.y + q.z * q.z));
// }

// double WaypointNavigator::normalizeAngle(double a)
// {
//   while (a >  M_PI) a -= 2.0 * M_PI;
//   while (a < -M_PI) a += 2.0 * M_PI;
//   return a;
// }

// void WaypointNavigator::stopRobot()
// {
//   cmd_vel_pub_->publish(geometry_msgs::msg::Twist());
// }

// void WaypointNavigator::publishStatus(const std::string & text)
// {
//   std_msgs::msg::String msg;
//   msg.data = text;
//   status_pub_->publish(msg);
// }

// bool WaypointNavigator::isOnlyRotation(const Waypoint & prev, const Waypoint & curr)
// {
//   return (std::abs(curr.x - prev.x) < xy_tolerance_ &&
//           std::abs(curr.y - prev.y) < xy_tolerance_);
// }

// const char * WaypointNavigator::stateStr()
// {
//   switch (state_) {
//     case State::IDLE:              return "IDLE";
//     case State::ROTATE_TO_HEADING: return "ROTATING_TO_GOAL";
//     case State::DRIVE_STRAIGHT:    return "DRIVING";
//     case State::ROTATE_TO_THETA:   return "ROTATING_TO_THETA";
//     case State::WAYPOINT_DONE:     return "WP_DONE";
//     case State::CYCLE_DONE:        return "CYCLE_DONE";
//     case State::ALL_DONE:          return "ALL_DONE";
//     default:                       return "UNKNOWN";
//   }
// }

// // ─── Load Waypoints ───────────────────────────────────────────────
// bool WaypointNavigator::loadWaypoints(const std::string & path)
// {
//   if (path.empty()) {
//     RCLCPP_ERROR(get_logger(), "waypoints_file param is empty!");
//     return false;
//   }
//   std::ifstream f(path);
//   if (!f.good()) {
//     RCLCPP_ERROR(get_logger(), "Cannot open: %s", path.c_str());
//     return false;
//   }
//   f.seekg(0, std::ios::end);
//   if (f.tellg() == 0) {
//     RCLCPP_ERROR(get_logger(), "File empty: %s", path.c_str());
//     return false;
//   }
//   f.close();

//   try {
//     YAML::Node root = YAML::LoadFile(path);
//     YAML::Node wps  = root["waypoints"];
//     if (!wps || !wps.IsSequence()) {
//       RCLCPP_ERROR(get_logger(), "No 'waypoints' list in YAML");
//       return false;
//     }
//     for (size_t i = 0; i < wps.size(); ++i) {
//       Waypoint w;
//       w.x     = wps[i]["x"].as<double>();
//       w.y     = wps[i]["y"].as<double>();
//       w.theta = wps[i]["theta"].as<double>();
//       w.type  = wps[i]["type"] ? wps[i]["type"].as<std::string>() : "waypoint";
//       waypoints_.push_back(w);
//       RCLCPP_INFO(get_logger(), "  WP[%02zu] %-10s x=%.2f y=%.2f theta=%.1f°",
//         i, w.type.c_str(), w.x, w.y, w.theta * 180.0 / M_PI);
//     }
//   } catch (const std::exception & e) {
//     RCLCPP_ERROR(get_logger(), "YAML error: %s", e.what());
//     return false;
//   }
//   return !waypoints_.empty();
// }

// // ─── Main Control Loop  20 Hz ─────────────────────────────────────
// void WaypointNavigator::controlLoop()
// {
//   if (init_failed_) return;

//   // ── IDLE — waiting for /set_cycles command ───────────────────
//   if (state_ == State::IDLE) {
//     stopRobot();
//     return;
//   }

//   // ── ALL DONE — all cycles finished ───────────────────────────
//   if (state_ == State::ALL_DONE) {
//     stopRobot();
//     RCLCPP_INFO_ONCE(get_logger(),
//       "✅ All %d cycle(s) completed! Robot stopped. Send /set_cycles to run again.",
//       cycles_done_);
//     return;
//   }

//   // ── Wait for pose ─────────────────────────────────────────────
//   if (!pose_received_) return;

//   // ── CYCLE DONE — check if more cycles needed ──────────────────
//   if (state_ == State::CYCLE_DONE) {
//     cycles_done_++;

//     if (loop_forever_) {
//       // Loop forever — reset and go again
//       wp_index_ = 0;
//       state_    = State::ROTATE_TO_HEADING;
//       RCLCPP_INFO(get_logger(),
//         "🔁 Cycle %d done. Looping forever — starting again!", cycles_done_);
//       char buf[64];
//       snprintf(buf, sizeof(buf), "RUNNING - cycle %d done, looping", cycles_done_);
//       publishStatus(buf);

//     } else if (cycles_done_ < max_cycles_) {
//       // More cycles remaining
//       int remaining = max_cycles_ - cycles_done_;
//       wp_index_ = 0;
//       state_    = State::ROTATE_TO_HEADING;
//       RCLCPP_INFO(get_logger(),
//         "🔄 Cycle %d/%d done. %d more remaining — starting next cycle!",
//         cycles_done_, max_cycles_, remaining);
//       char buf[128];
//       snprintf(buf, sizeof(buf),
//         "RUNNING - cycle %d/%d done", cycles_done_, max_cycles_);
//       publishStatus(buf);

//     } else {
//       // All cycles done
//       state_ = State::ALL_DONE;
//       stopRobot();
//       RCLCPP_INFO(get_logger(),
//         "✅ ALL %d CYCLE(S) COMPLETE! Robot stopped.", cycles_done_);
//       RCLCPP_INFO(get_logger(),
//         "   Send /set_cycles again to run more cycles.");
//       char buf[128];
//       snprintf(buf, sizeof(buf),
//         "DONE - %d cycle(s) completed. Send /set_cycles to run again.", cycles_done_);
//       publishStatus(buf);
//     }
//     return;
//   }

//   // ── Current target waypoint ───────────────────────────────────
//   const Waypoint & wp = waypoints_[wp_index_];

//   double dx            = wp.x - robot_x_;
//   double dy            = wp.y - robot_y_;
//   double distance      = std::hypot(dx, dy);
//   double angle_to_goal = std::atan2(dy, dx);
//   double heading_error = normalizeAngle(angle_to_goal - robot_yaw_);
//   double yaw_error     = normalizeAngle(wp.theta - robot_yaw_);

//   geometry_msgs::msg::Twist cmd;

//   // 1 second status log
//   if (++log_counter_ >= 20) {
//     log_counter_ = 0;
//     RCLCPP_INFO(get_logger(),
//       "[Cycle %d/%s | %s | WP%zu/%zu] pos(%.2f,%.2f,%.1f°)→(%.2f,%.2f,%.1f°) dist=%.2fm",
//       cycles_done_ + 1,
//       loop_forever_ ? "∞" : std::to_string(max_cycles_).c_str(),
//       stateStr(),
//       wp_index_, waypoints_.size() - 1,
//       robot_x_, robot_y_, robot_yaw_ * 180.0 / M_PI,
//       wp.x, wp.y, wp.theta * 180.0 / M_PI,
//       distance);
//   }

//   switch (state_)
//   {
//     // ── STEP 1: Rotate to face goal ───────────────────────────────
//     case State::ROTATE_TO_HEADING:
//     {
//       Waypoint prev = (wp_index_ > 0) ?
//         waypoints_[wp_index_ - 1] :
//         Waypoint{robot_x_, robot_y_, robot_yaw_};

//       if (isOnlyRotation(prev, wp)) {
//         state_ = State::ROTATE_TO_THETA;
//         RCLCPP_INFO(get_logger(), "[WP%zu] Pure rotation → %.1f°",
//           wp_index_, wp.theta * 180.0 / M_PI);
//         break;
//       }

//       if (distance < xy_tolerance_) {
//         stopRobot();
//         state_ = State::ROTATE_TO_THETA;
//         break;
//       }

//       if (std::abs(heading_error) < heading_tolerance_) {
//         stopRobot();
//         state_ = State::DRIVE_STRAIGHT;
//         RCLCPP_INFO(get_logger(), "[WP%zu] ✓ Heading OK → DRIVING dist=%.2fm",
//           wp_index_, distance);
//         break;
//       }

//       cmd.linear.x  = 0.0;
//       cmd.angular.z = std::clamp(2.0 * heading_error, -angular_speed_, angular_speed_);
//       cmd_vel_pub_->publish(cmd);
//       break;
//     }

//     // ── STEP 2: Drive straight ────────────────────────────────────
//     case State::DRIVE_STRAIGHT:
//     {
//       if (distance < xy_tolerance_) {
//         stopRobot();
//         state_ = State::ROTATE_TO_THETA;
//         RCLCPP_INFO(get_logger(), "[WP%zu] ✓ Reached. Rotating to theta=%.1f°",
//           wp_index_, wp.theta * 180.0 / M_PI);
//         break;
//       }

//       if (obstacle_ahead_) {
//         stopRobot();
//         RCLCPP_WARN_THROTTLE(get_logger(), *get_clock(), 1000,
//           "[WP%zu] ⚠ Obstacle! Waiting...", wp_index_);
//         break;
//       }

//       if (std::abs(heading_error) > 1.05) {
//         stopRobot();
//         state_ = State::ROTATE_TO_HEADING;
//         break;
//       }

//       double speed = linear_speed_;
//       if (distance < 0.30) {
//         speed = std::max(0.05, linear_speed_ * (distance / 0.30));
//       }

//       cmd.linear.x  = speed;
//       cmd.angular.z = std::clamp(0.5 * heading_error, -drive_correction_, drive_correction_);
//       cmd_vel_pub_->publish(cmd);
//       break;
//     }

//     // ── STEP 3: Rotate to final theta ─────────────────────────────
//     case State::ROTATE_TO_THETA:
//     {
//       if (std::abs(yaw_error) < yaw_tolerance_) {
//         stopRobot();
//         state_ = State::WAYPOINT_DONE;
//         RCLCPP_INFO(get_logger(), "[WP%zu] ✅ Done  type=%s",
//           wp_index_, wp.type.c_str());
//         break;
//       }

//       cmd.linear.x  = 0.0;
//       cmd.angular.z = std::clamp(2.0 * yaw_error, -angular_speed_, angular_speed_);
//       cmd_vel_pub_->publish(cmd);
//       break;
//     }

//     // ── STEP 4: Next waypoint or end of cycle ─────────────────────
//     case State::WAYPOINT_DONE:
//     {
//       wp_index_++;

//       if (wp_index_ < waypoints_.size()) {
//         // More waypoints in this cycle
//         state_ = State::ROTATE_TO_HEADING;
//         RCLCPP_INFO(get_logger(), "→ WP[%zu/%zu]  x=%.2f y=%.2f theta=%.1f°",
//           wp_index_, waypoints_.size() - 1,
//           waypoints_[wp_index_].x,
//           waypoints_[wp_index_].y,
//           waypoints_[wp_index_].theta * 180.0 / M_PI);
//       } else {
//         // End of waypoint list = one full cycle complete
//         state_ = State::CYCLE_DONE;
//       }
//       break;
//     }

//     case State::IDLE:
//     case State::ALL_DONE:
//     case State::CYCLE_DONE:
//     default:
//       break;
//   }
// }

// }  // namespace amr_pure_navigation

// int main(int argc, char ** argv)
// {
//   rclcpp::init(argc, argv);
//   auto node = std::make_shared<amr_pure_navigation::WaypointNavigator>();
//   rclcpp::spin(node);
//   rclcpp::shutdown();
//   return 0;
// }


//currect code 

// // ================================================================
// //  waypoint_navigator.cpp  v4
// //
// //  HOW IT WORKS:
// //    1. AMCL tells us where robot is on the MAP (no drift)
// //    2. We calculate direction to next waypoint
// //    3. We send cmd_vel to move the robot
// //
// //  STRAIGHT LINE FIX:
// //    drive_correction = 0.15  (very gentle steering while driving)
// //    This keeps left/right RPM nearly equal = straight line
// //
// //  TOPICS:
// //    Reads  : /amcl_pose                      (robot position on map)
// //    Reads  : /diff_drive_controller/odom     (fallback if AMCL not ready)
// //    Reads  : /scan                           (obstacle detection)
// //    Writes : /diff_drive_controller/cmd_vel  (move robot)
// // ================================================================

// #include "amr_pure_navigation/waypoint_navigator.hpp"

// namespace amr_pure_navigation
// {

// // ─── Constructor ──────────────────────────────────────────────────
// WaypointNavigator::WaypointNavigator(const rclcpp::NodeOptions & options)
// : Node("waypoint_navigator", options)
// {
//   // ── Declare all parameters with default values ─────────────
//   declare_parameter<std::string>("waypoints_file",     "");
//   declare_parameter<std::string>("odom_topic",         "/diff_drive_controller/odom");
//   declare_parameter<std::string>("cmd_vel_topic",      "/diff_drive_controller/cmd_vel");
//   declare_parameter<std::string>("amcl_topic",         "/amcl_pose");
//   declare_parameter<double>     ("linear_speed",       0.20);
//   declare_parameter<double>     ("angular_speed",      0.40);
//   declare_parameter<double>     ("drive_correction",   0.15);
//   declare_parameter<double>     ("xy_tolerance",       0.10);
//   declare_parameter<double>     ("yaw_tolerance",      0.08);
//   declare_parameter<double>     ("heading_tolerance",  0.10);
//   declare_parameter<double>     ("obstacle_stop_dist", 0.40);
//   declare_parameter<bool>       ("loop_waypoints",     false);
//   declare_parameter<bool>       ("stop_on_obstacle",   true);
//   declare_parameter<bool>       ("use_amcl",           true);

//   // ── Read all parameters ────────────────────────────────────
//   get_parameter("waypoints_file",    waypoints_file_);
//   get_parameter("odom_topic",        odom_topic_);
//   get_parameter("cmd_vel_topic",     cmd_vel_topic_);
//   get_parameter("amcl_topic",        amcl_topic_);
//   get_parameter("linear_speed",      linear_speed_);
//   get_parameter("angular_speed",     angular_speed_);
//   get_parameter("drive_correction",  drive_correction_);
//   get_parameter("xy_tolerance",      xy_tolerance_);
//   get_parameter("yaw_tolerance",     yaw_tolerance_);
//   get_parameter("heading_tolerance", heading_tolerance_);
//   get_parameter("obstacle_stop_dist",obstacle_stop_dist_);
//   get_parameter("loop_waypoints",    loop_waypoints_);
//   get_parameter("stop_on_obstacle",  stop_on_obstacle_);
//   get_parameter("use_amcl",          use_amcl_);

//   // ── Load waypoints from YAML file ─────────────────────────
//   if (!loadWaypoints(waypoints_file_)) {
//     RCLCPP_FATAL(get_logger(), "Cannot load waypoints: %s", waypoints_file_.c_str());
//     init_failed_ = true;
//     return;
//   }

//   // ── Print startup info ────────────────────────────────────
//   RCLCPP_INFO(get_logger(), "=============================================");
//   RCLCPP_INFO(get_logger(), "  AMR Navigation v4 - Ready");
//   RCLCPP_INFO(get_logger(), "  Waypoints      : %zu",    waypoints_.size());
//   RCLCPP_INFO(get_logger(), "  Mode           : %s",     use_amcl_ ? "AMCL map frame" : "Odom only");
//   RCLCPP_INFO(get_logger(), "  Linear speed   : %.2f m/s",   linear_speed_);
//   RCLCPP_INFO(get_logger(), "  Angular speed  : %.2f rad/s", angular_speed_);
//   RCLCPP_INFO(get_logger(), "  Drive correct  : %.2f rad/s (keeps straight line)", drive_correction_);
//   RCLCPP_INFO(get_logger(), "  XY tolerance   : %.2f m",     xy_tolerance_);
//   RCLCPP_INFO(get_logger(), "  Yaw tolerance  : %.2f rad",   yaw_tolerance_);
//   RCLCPP_INFO(get_logger(), "=============================================");
//   if (use_amcl_) {
//     RCLCPP_INFO(get_logger(), "  Waiting for AMCL...");
//     RCLCPP_INFO(get_logger(), "  ➡ Open RViz → click '2D Pose Estimate'");
//     RCLCPP_INFO(get_logger(), "  ➡ Click on map where robot is located");
//   }
//   RCLCPP_INFO(get_logger(), "=============================================");

//   // ── Create publisher ──────────────────────────────────────
//   cmd_vel_pub_ = create_publisher<geometry_msgs::msg::Twist>(cmd_vel_topic_, 10);

//   // ── Create subscribers ────────────────────────────────────
//   if (use_amcl_) {
//     amcl_sub_ = create_subscription<geometry_msgs::msg::PoseWithCovarianceStamped>(
//       amcl_topic_, 10,
//       std::bind(&WaypointNavigator::amclCallback, this, std::placeholders::_1));
//   }

//   odom_sub_ = create_subscription<nav_msgs::msg::Odometry>(
//     odom_topic_, 10,
//     std::bind(&WaypointNavigator::odomCallback, this, std::placeholders::_1));

//   scan_sub_ = create_subscription<sensor_msgs::msg::LaserScan>(
//     "/scan", 10,
//     std::bind(&WaypointNavigator::scanCallback, this, std::placeholders::_1));

//   // ── 20 Hz timer ───────────────────────────────────────────
//   timer_ = create_wall_timer(
//     std::chrono::milliseconds(50),
//     std::bind(&WaypointNavigator::controlLoop, this));
// }

// // ─── AMCL Callback ───────────────────────────────────────────────
// // Called every time AMCL publishes robot position on the map
// // This is the main position source — no drift!
// void WaypointNavigator::amclCallback(
//   const geometry_msgs::msg::PoseWithCovarianceStamped::SharedPtr msg)
// {
//   if (init_failed_) return;

//   robot_x_   = msg->pose.pose.position.x;
//   robot_y_   = msg->pose.pose.position.y;
//   robot_yaw_ = quaternionToYaw(msg->pose.pose.orientation);

//   if (!pose_received_) {
//     pose_received_ = true;
//     state_ = State::ROTATE_TO_HEADING;
//     RCLCPP_INFO(get_logger(), "✅ AMCL active! Robot at x=%.2f y=%.2f yaw=%.1f°",
//       robot_x_, robot_y_, robot_yaw_ * 180.0 / M_PI);
//     RCLCPP_INFO(get_logger(), "   Target WP[0]: x=%.2f y=%.2f theta=%.1f°",
//       waypoints_[0].x, waypoints_[0].y, waypoints_[0].theta * 180.0 / M_PI);
//     RCLCPP_INFO(get_logger(), "   🚀 Starting navigation!");
//   }
// }

// // ─── Odom Callback ───────────────────────────────────────────────
// // Used as fallback before AMCL is ready
// // In use_amcl=false mode this is the only position source
// void WaypointNavigator::odomCallback(const nav_msgs::msg::Odometry::SharedPtr msg)
// {
//   if (init_failed_) return;
//   if (use_amcl_ && pose_received_) return;  // AMCL already active, ignore odom

//   robot_x_   = msg->pose.pose.position.x;
//   robot_y_   = msg->pose.pose.position.y;
//   robot_yaw_ = quaternionToYaw(msg->pose.pose.orientation);

//   if (!pose_received_) {
//     pose_received_ = true;
//     state_ = State::ROTATE_TO_HEADING;
//     if (use_amcl_) {
//       RCLCPP_WARN(get_logger(),
//         "⚠ AMCL not ready — using odom. Set 2D Pose Estimate in RViz!");
//     } else {
//       RCLCPP_INFO(get_logger(),
//         "✅ Odom active! Robot at x=%.2f y=%.2f — Starting!",
//         robot_x_, robot_y_);
//     }
//   }
// }

// // ─── Scan Callback ───────────────────────────────────────────────
// // Checks if obstacle is within stop distance in front of robot
// void WaypointNavigator::scanCallback(const sensor_msgs::msg::LaserScan::SharedPtr msg)
// {
//   if (!stop_on_obstacle_) return;
//   obstacle_ahead_ = false;
//   for (int i = 0; i < static_cast<int>(msg->ranges.size()); ++i) {
//     float angle = msg->angle_min + i * msg->angle_increment;
//     if (angle < -0.524f || angle > 0.524f) continue;  // only check ±30° front
//     float r = msg->ranges[i];
//     if (std::isfinite(r) && r > 0.01f && r < static_cast<float>(obstacle_stop_dist_)) {
//       obstacle_ahead_ = true;
//       return;
//     }
//   }
// }

// // ─── Helper: quaternion → yaw angle ──────────────────────────────
// double WaypointNavigator::quaternionToYaw(const geometry_msgs::msg::Quaternion & q)
// {
//   return std::atan2(
//     2.0 * (q.w * q.z + q.x * q.y),
//     1.0 - 2.0 * (q.y * q.y + q.z * q.z));
// }

// // ─── Helper: normalize angle to [-pi, pi] ────────────────────────
// double WaypointNavigator::normalizeAngle(double a)
// {
//   while (a >  M_PI) a -= 2.0 * M_PI;
//   while (a < -M_PI) a += 2.0 * M_PI;
//   return a;
// }

// // ─── Helper: stop robot ───────────────────────────────────────────
// void WaypointNavigator::stopRobot()
// {
//   cmd_vel_pub_->publish(geometry_msgs::msg::Twist());
// }

// // ─── Helper: is this waypoint same x,y as previous? ──────────────
// bool WaypointNavigator::isOnlyRotation(const Waypoint & prev, const Waypoint & curr)
// {
//   return (std::abs(curr.x - prev.x) < xy_tolerance_ &&
//           std::abs(curr.y - prev.y) < xy_tolerance_);
// }

// // ─── Helper: state name for logging ──────────────────────────────
// const char * WaypointNavigator::stateStr()
// {
//   switch (state_) {
//     case State::IDLE:              return "IDLE";
//     case State::ROTATE_TO_HEADING: return "ROTATING_TO_GOAL";
//     case State::DRIVE_STRAIGHT:    return "DRIVING";
//     case State::ROTATE_TO_THETA:   return "ROTATING_TO_THETA";
//     case State::WAYPOINT_DONE:     return "WP_DONE";
//     case State::ALL_DONE:          return "ALL_DONE";
//     default:                       return "UNKNOWN";
//   }
// }

// // ─── Load waypoints from YAML ─────────────────────────────────────
// bool WaypointNavigator::loadWaypoints(const std::string & path)
// {
//   if (path.empty()) {
//     RCLCPP_ERROR(get_logger(), "waypoints_file param is empty!");
//     return false;
//   }

//   std::ifstream f(path);
//   if (!f.good()) {
//     RCLCPP_ERROR(get_logger(), "Cannot open file: %s", path.c_str());
//     return false;
//   }
//   f.seekg(0, std::ios::end);
//   if (f.tellg() == 0) {
//     RCLCPP_ERROR(get_logger(), "File is empty: %s", path.c_str());
//     return false;
//   }
//   f.close();

//   try {
//     YAML::Node root = YAML::LoadFile(path);
//     YAML::Node wps  = root["waypoints"];
//     if (!wps || !wps.IsSequence()) {
//       RCLCPP_ERROR(get_logger(), "No 'waypoints' list in YAML");
//       return false;
//     }
//     for (size_t i = 0; i < wps.size(); ++i) {
//       Waypoint w;
//       w.x     = wps[i]["x"].as<double>();
//       w.y     = wps[i]["y"].as<double>();
//       w.theta = wps[i]["theta"].as<double>();
//       w.type  = wps[i]["type"] ? wps[i]["type"].as<std::string>() : "waypoint";
//       waypoints_.push_back(w);
//       RCLCPP_INFO(get_logger(), "  WP[%02zu] %-10s x=%.2f  y=%.2f  theta=%.1f°",
//         i, w.type.c_str(), w.x, w.y, w.theta * 180.0 / M_PI);
//     }
//   } catch (const std::exception & e) {
//     RCLCPP_ERROR(get_logger(), "YAML error: %s", e.what());
//     return false;
//   }
//   return !waypoints_.empty();
// }

// // ─── Main Control Loop  (called 20 times per second) ──────────────
// void WaypointNavigator::controlLoop()
// {
//   if (init_failed_ || !pose_received_) return;

//   // ── Finished all waypoints ───────────────────────────────────
//   if (state_ == State::ALL_DONE) {
//     stopRobot();
//     RCLCPP_INFO_ONCE(get_logger(), "✅ All waypoints done! Robot stopped.");
//     return;
//   }

//   // ── Safety check ─────────────────────────────────────────────
//   if (wp_index_ >= waypoints_.size()) {
//     if (loop_waypoints_) {
//       wp_index_ = 0;
//       state_    = State::ROTATE_TO_HEADING;
//       RCLCPP_INFO(get_logger(), "🔁 Looping back to start.");
//     } else {
//       state_ = State::ALL_DONE;
//     }
//     return;
//   }

//   // ── Current target waypoint ───────────────────────────────────
//   const Waypoint & wp = waypoints_[wp_index_];

//   // ── Calculate distance and angle errors ──────────────────────
//   double dx            = wp.x - robot_x_;
//   double dy            = wp.y - robot_y_;
//   double distance      = std::hypot(dx, dy);
//   double angle_to_goal = std::atan2(dy, dx);
//   double heading_error = normalizeAngle(angle_to_goal - robot_yaw_);
//   double yaw_error     = normalizeAngle(wp.theta - robot_yaw_);

//   geometry_msgs::msg::Twist cmd;

//   // ── Print status every 1 second ──────────────────────────────
//   if (++log_counter_ >= 20) {
//     log_counter_ = 0;
//     RCLCPP_INFO(get_logger(),
//       "[%s WP%zu/%zu] robot(%.2f, %.2f, %.1f°) → target(%.2f, %.2f, %.1f°) dist=%.2fm",
//       stateStr(), wp_index_, waypoints_.size() - 1,
//       robot_x_, robot_y_, robot_yaw_ * 180.0 / M_PI,
//       wp.x, wp.y, wp.theta * 180.0 / M_PI, distance);
//   }

//   switch (state_)
//   {
//     // ════════════════════════════════════════════════
//     // STEP 1: Rotate in place to face the goal x,y
//     //   left RPM  = +speed
//     //   right RPM = -speed  (opposite = rotate)
//     // ════════════════════════════════════════════════
//     case State::ROTATE_TO_HEADING:
//     {
//       Waypoint prev = (wp_index_ > 0) ?
//         waypoints_[wp_index_ - 1] :
//         Waypoint{robot_x_, robot_y_, robot_yaw_};

//       // Same x,y as previous — skip to final rotation
//       if (isOnlyRotation(prev, wp)) {
//         state_ = State::ROTATE_TO_THETA;
//         RCLCPP_INFO(get_logger(), "[WP%zu] Pure rotation → %.1f°",
//           wp_index_, wp.theta * 180.0 / M_PI);
//         break;
//       }

//       // Already at goal position
//       if (distance < xy_tolerance_) {
//         stopRobot();
//         state_ = State::ROTATE_TO_THETA;
//         RCLCPP_INFO(get_logger(), "[WP%zu] Already at position → rotating", wp_index_);
//         break;
//       }

//       // Heading is aligned — start driving
//       if (std::abs(heading_error) < heading_tolerance_) {
//         stopRobot();
//         state_ = State::DRIVE_STRAIGHT;
//         RCLCPP_INFO(get_logger(), "[WP%zu] ✓ Heading OK (%.1f°). DRIVING dist=%.2fm",
//           wp_index_, heading_error * 180.0 / M_PI, distance);
//         break;
//       }

//       // Rotate in place
//       cmd.linear.x  = 0.0;
//       cmd.angular.z = std::clamp(2.0 * heading_error, -angular_speed_, angular_speed_);
//       cmd_vel_pub_->publish(cmd);

//       RCLCPP_INFO_THROTTLE(get_logger(), *get_clock(), 500,
//         "[WP%zu] Rotating to face goal  err=%.1f°  cmd.z=%.3f",
//         wp_index_, heading_error * 180.0 / M_PI, cmd.angular.z);
//       break;
//     }

//     // ════════════════════════════════════════════════
//     // STEP 2: Drive straight to goal x,y
//     //   left RPM  = +speed
//     //   right RPM = +speed  (same = straight)
//     //
//     //   KEY FIX: angular.z is capped at drive_correction_
//     //   (0.15 rad/s) so RPM difference is tiny — robot
//     //   drives in a nearly perfect straight line
//     // ════════════════════════════════════════════════
//     case State::DRIVE_STRAIGHT:
//     {
//       // Reached goal
//       if (distance < xy_tolerance_) {
//         stopRobot();
//         state_ = State::ROTATE_TO_THETA;
//         RCLCPP_INFO(get_logger(), "[WP%zu] ✓ Reached goal (%.3fm). Rotating to theta",
//           wp_index_, distance);
//         break;
//       }

//       // Obstacle — stop and wait
//       if (obstacle_ahead_) {
//         stopRobot();
//         RCLCPP_WARN_THROTTLE(get_logger(), *get_clock(), 1000,
//           "[WP%zu] ⚠ Obstacle! Waiting...", wp_index_);
//         break;
//       }

//       // Too far off course — re-rotate
//       if (std::abs(heading_error) > 1.05) {
//         stopRobot();
//         state_ = State::ROTATE_TO_HEADING;
//         RCLCPP_WARN(get_logger(), "[WP%zu] Off course %.1f° — re-rotating",
//           wp_index_, heading_error * 180.0 / M_PI);
//         break;
//       }

//       // Slow down near goal
//       double speed = linear_speed_;
//       if (distance < 0.30) {
//         speed = std::max(0.05, linear_speed_ * (distance / 0.30));
//       }

//       // Drive straight with GENTLE correction
//       // drive_correction_ = 0.15  →  tiny angular.z
//       // → left and right RPM stay nearly equal
//       // → robot drives in straight line
//       cmd.linear.x  = speed;
//       cmd.angular.z = std::clamp(
//         0.5 * heading_error,   // gain 0.5 (gentle)
//         -drive_correction_,    // max -0.15 rad/s
//          drive_correction_);   // max +0.15 rad/s
//       cmd_vel_pub_->publish(cmd);

//       RCLCPP_INFO_THROTTLE(get_logger(), *get_clock(), 500,
//         "[WP%zu] Driving  dist=%.2fm  speed=%.2f  heading_err=%.1f°",
//         wp_index_, distance, speed, heading_error * 180.0 / M_PI);
//       break;
//     }

//     // ════════════════════════════════════════════════
//     // STEP 3: Rotate in place to final theta
//     //   + error = anticlockwise (left turn)
//     //   - error = clockwise     (right turn)
//     // ════════════════════════════════════════════════
//     case State::ROTATE_TO_THETA:
//     {
//       if (std::abs(yaw_error) < yaw_tolerance_) {
//         stopRobot();
//         state_ = State::WAYPOINT_DONE;
//         RCLCPP_INFO(get_logger(),
//           "[WP%zu] ✅ DONE  x=%.2f y=%.2f theta=%.1f°  type=%s",
//           wp_index_, wp.x, wp.y,
//           wp.theta * 180.0 / M_PI, wp.type.c_str());
//         break;
//       }

//       cmd.linear.x  = 0.0;
//       cmd.angular.z = std::clamp(2.0 * yaw_error, -angular_speed_, angular_speed_);
//       cmd_vel_pub_->publish(cmd);

//       RCLCPP_INFO_THROTTLE(get_logger(), *get_clock(), 500,
//         "[WP%zu] Rotating to theta=%.1f°  remaining=%.1f°",
//         wp_index_, wp.theta * 180.0 / M_PI,
//         yaw_error * 180.0 / M_PI);
//       break;
//     }

//     // ════════════════════════════════════════════════
//     // STEP 4: Load next waypoint
//     // ════════════════════════════════════════════════
//     case State::WAYPOINT_DONE:
//     {
//       wp_index_++;
//       if (wp_index_ < waypoints_.size()) {
//         state_ = State::ROTATE_TO_HEADING;
//         RCLCPP_INFO(get_logger(), "─────────────────────────────────────");
//         RCLCPP_INFO(get_logger(), "→ Next WP[%zu/%zu]  x=%.2f y=%.2f theta=%.1f°",
//           wp_index_, waypoints_.size() - 1,
//           waypoints_[wp_index_].x,
//           waypoints_[wp_index_].y,
//           waypoints_[wp_index_].theta * 180.0 / M_PI);
//       }
//       break;
//     }

//     case State::IDLE:
//     case State::ALL_DONE:
//     default:
//       break;
//   }
// }

// }  // namespace amr_pure_navigation

// int main(int argc, char ** argv)
// {
//   rclcpp::init(argc, argv);
//   auto node = std::make_shared<amr_pure_navigation::WaypointNavigator>();
//   rclcpp::spin(node);
//   rclcpp::shutdown();
//   return 0;
// }








//linenot stright 


// // ================================================================
// //  waypoint_navigator.cpp  —  Map-based AMR Navigation
// //
// //  Position source : /amcl_pose  (map frame, no drift)
// //  Fallback        : /diff_drive_controller/odom (until AMCL ready)
// //  Output          : /diff_drive_controller/cmd_vel
// //
// //  Flow per waypoint:
// //    1. ROTATE_TO_HEADING — rotate to face goal x,y
// //    2. DRIVE_STRAIGHT    — drive to goal x,y
// //    3. ROTATE_TO_THETA   — rotate to final theta
// //    4. WAYPOINT_DONE     — next waypoint
// //
// //  Key difference from odom-only version:
// //    Robot position comes from AMCL (map frame) so:
// //    - No drift over long distances
// //    - Waypoints are real map coordinates
// //    - Works even if robot is moved/repositioned
// // ================================================================

// #include "amr_pure_navigation/waypoint_navigator.hpp"

// namespace amr_navigation
// {

// // ─── Constructor ──────────────────────────────────────────────────
// WaypointNavigator::WaypointNavigator(const rclcpp::NodeOptions & options)
// : Node("waypoint_navigator", options)
// {
//   // ── Parameters ────────────────────────────────────────────────
//   declare_parameter<std::string>("waypoints_file",     "");
//   declare_parameter<std::string>("cmd_vel_topic",      "/diff_drive_controller/cmd_vel");
//   declare_parameter<std::string>("amcl_topic",         "/amcl_pose");
//   declare_parameter<std::string>("odom_topic",         "/diff_drive_controller/odom");
//   declare_parameter<double>     ("linear_speed",       0.20);
//   declare_parameter<double>     ("angular_speed",      0.40);
//   declare_parameter<double>     ("xy_tolerance",       0.10);
//   declare_parameter<double>     ("yaw_tolerance",      0.08);
//   declare_parameter<double>     ("heading_tolerance",  0.10);
//   declare_parameter<double>     ("obstacle_stop_dist", 0.40);
//   declare_parameter<bool>       ("loop_waypoints",     false);
//   declare_parameter<bool>       ("stop_on_obstacle",   true);

//   get_parameter("waypoints_file",    waypoints_file_);
//   get_parameter("cmd_vel_topic",     cmd_vel_topic_);
//   get_parameter("amcl_topic",        amcl_topic_);
//   get_parameter("odom_topic",        odom_topic_);
//   get_parameter("linear_speed",      linear_speed_);
//   get_parameter("angular_speed",     angular_speed_);
//   get_parameter("xy_tolerance",      xy_tolerance_);
//   get_parameter("yaw_tolerance",     yaw_tolerance_);
//   get_parameter("heading_tolerance", heading_tolerance_);
//   get_parameter("obstacle_stop_dist",obstacle_stop_dist_);
//   get_parameter("loop_waypoints",    loop_waypoints_);
//   get_parameter("stop_on_obstacle",  stop_on_obstacle_);

//   // ── Load waypoints ────────────────────────────────────────────
//   if (!loadWaypoints(waypoints_file_)) {
//     RCLCPP_FATAL(get_logger(), "Failed to load waypoints: %s", waypoints_file_.c_str());
//     init_failed_ = true;
//     return;
//   }

//   RCLCPP_INFO(get_logger(), "==============================================");
//   RCLCPP_INFO(get_logger(), "  AMR Map-Based Navigation");
//   RCLCPP_INFO(get_logger(), "  Waypoints    : %zu",    waypoints_.size());
//   RCLCPP_INFO(get_logger(), "  AMCL topic   : %s",     amcl_topic_.c_str());
//   RCLCPP_INFO(get_logger(), "  Odom topic   : %s",     odom_topic_.c_str());
//   RCLCPP_INFO(get_logger(), "  Cmd_vel      : %s",     cmd_vel_topic_.c_str());
//   RCLCPP_INFO(get_logger(), "  Lin speed    : %.2f m/s",   linear_speed_);
//   RCLCPP_INFO(get_logger(), "  Ang speed    : %.2f rad/s",  angular_speed_);
//   RCLCPP_INFO(get_logger(), "  XY tolerance : %.3f m",     xy_tolerance_);
//   RCLCPP_INFO(get_logger(), "  Yaw tolerance: %.3f rad",   yaw_tolerance_);
//   RCLCPP_INFO(get_logger(), "==============================================");
//   RCLCPP_INFO(get_logger(), "  Waiting for AMCL pose on: %s", amcl_topic_.c_str());
//   RCLCPP_INFO(get_logger(), "  ⚠ Set initial pose in RViz first!");
//   RCLCPP_INFO(get_logger(), "==============================================");

//   // ── Publishers / Subscribers ──────────────────────────────────
//   cmd_vel_pub_ = create_publisher<geometry_msgs::msg::Twist>(cmd_vel_topic_, 10);

//   // Primary: AMCL pose in MAP frame (no drift)
//   amcl_sub_ = create_subscription<geometry_msgs::msg::PoseWithCovarianceStamped>(
//     amcl_topic_, 10,
//     std::bind(&WaypointNavigator::amclCallback, this, std::placeholders::_1));

//   // Fallback: odom (used only until AMCL publishes first pose)
//   odom_sub_ = create_subscription<nav_msgs::msg::Odometry>(
//     odom_topic_, 10,
//     std::bind(&WaypointNavigator::odomCallback, this, std::placeholders::_1));

//   // Obstacle detection
//   scan_sub_ = create_subscription<sensor_msgs::msg::LaserScan>(
//     "/scan", 10,
//     std::bind(&WaypointNavigator::scanCallback, this, std::placeholders::_1));

//   // 20 Hz control loop
//   timer_ = create_wall_timer(
//     std::chrono::milliseconds(50),
//     std::bind(&WaypointNavigator::controlLoop, this));
// }

// // ─── AMCL Callback — PRIMARY pose source (map frame) ─────────────
// void WaypointNavigator::amclCallback(
//   const geometry_msgs::msg::PoseWithCovarianceStamped::SharedPtr msg)
// {
//   if (init_failed_) return;

//   robot_x_ = msg->pose.pose.position.x;
//   robot_y_ = msg->pose.pose.position.y;

//   const auto & q = msg->pose.pose.orientation;
//   robot_yaw_ = std::atan2(
//     2.0 * (q.w * q.z + q.x * q.y),
//     1.0 - 2.0 * (q.y * q.y + q.z * q.z));

//   if (!pose_received_) {
//     pose_received_ = true;
//     state_ = State::ROTATE_TO_HEADING;
//     RCLCPP_INFO(get_logger(),
//       "✅ AMCL pose received! MAP position: x=%.3f y=%.3f yaw=%.3f",
//       robot_x_, robot_y_, robot_yaw_);
//     RCLCPP_INFO(get_logger(),
//       "   First target: x=%.3f y=%.3f theta=%.3f",
//       waypoints_[0].x, waypoints_[0].y, waypoints_[0].theta);
//     RCLCPP_INFO(get_logger(), "   🚀 Navigation starting!");
//   }
// }

// // ─── Odom Callback — FALLBACK only (used until AMCL ready) ────────
// void WaypointNavigator::odomCallback(const nav_msgs::msg::Odometry::SharedPtr msg)
// {
//   if (init_failed_ || pose_received_) return;  // ignore once AMCL is active

//   // Use odom only as fallback before AMCL initializes
//   robot_x_ = msg->pose.pose.position.x;
//   robot_y_ = msg->pose.pose.position.y;
//   const auto & q = msg->pose.pose.orientation;
//   robot_yaw_ = std::atan2(
//     2.0 * (q.w * q.z + q.x * q.y),
//     1.0 - 2.0 * (q.y * q.y + q.z * q.z));

//   RCLCPP_WARN_THROTTLE(get_logger(), *get_clock(), 3000,
//     "⚠ Using ODOM (not map frame) — set initial pose in RViz to activate AMCL!");
// }

// // ─── Scan Callback — Obstacle Detection ──────────────────────────
// void WaypointNavigator::scanCallback(const sensor_msgs::msg::LaserScan::SharedPtr msg)
// {
//   if (!stop_on_obstacle_) return;
//   obstacle_ahead_ = false;
//   int n = static_cast<int>(msg->ranges.size());
//   for (int i = 0; i < n; ++i) {
//     float angle = msg->angle_min + i * msg->angle_increment;
//     if (angle < -0.524f || angle > 0.524f) continue;  // ±30° front
//     float r = msg->ranges[i];
//     if (std::isfinite(r) && r > 0.01f && r < static_cast<float>(obstacle_stop_dist_)) {
//       obstacle_ahead_ = true;
//       return;
//     }
//   }
// }

// // ─── Helpers ──────────────────────────────────────────────────────
// double WaypointNavigator::normalizeAngle(double a)
// {
//   while (a >  M_PI) a -= 2.0 * M_PI;
//   while (a < -M_PI) a += 2.0 * M_PI;
//   return a;
// }

// void WaypointNavigator::stopRobot()
// {
//   geometry_msgs::msg::Twist cmd;
//   cmd_vel_pub_->publish(cmd);
// }

// bool WaypointNavigator::isOnlyRotation(const Waypoint & prev, const Waypoint & curr)
// {
//   return (std::abs(curr.x - prev.x) < xy_tolerance_ &&
//           std::abs(curr.y - prev.y) < xy_tolerance_);
// }

// const char * WaypointNavigator::stateStr()
// {
//   switch (state_) {
//     case State::IDLE:              return "IDLE";
//     case State::ROTATE_TO_HEADING: return "ROT_HEADING";
//     case State::DRIVE_STRAIGHT:    return "DRIVE";
//     case State::ROTATE_TO_THETA:   return "ROT_THETA";
//     case State::WAYPOINT_DONE:     return "WP_DONE";
//     case State::ALL_DONE:          return "ALL_DONE";
//     default:                       return "UNKNOWN";
//   }
// }

// // ─── Load Waypoints ───────────────────────────────────────────────
// bool WaypointNavigator::loadWaypoints(const std::string & path)
// {
//   if (path.empty()) {
//     RCLCPP_ERROR(get_logger(), "waypoints_file param is empty!");
//     return false;
//   }
//   std::ifstream f(path);
//   if (!f.good()) {
//     RCLCPP_ERROR(get_logger(), "Cannot open: %s", path.c_str());
//     return false;
//   }
//   f.seekg(0, std::ios::end);
//   if (f.tellg() == 0) {
//     RCLCPP_ERROR(get_logger(), "File is empty: %s", path.c_str());
//     return false;
//   }
//   f.close();

//   try {
//     YAML::Node root = YAML::LoadFile(path);
//     YAML::Node wps  = root["waypoints"];
//     if (!wps || !wps.IsSequence()) {
//       RCLCPP_ERROR(get_logger(), "No 'waypoints' list found in YAML");
//       return false;
//     }
//     for (size_t i = 0; i < wps.size(); ++i) {
//       Waypoint w;
//       w.x     = wps[i]["x"].as<double>();
//       w.y     = wps[i]["y"].as<double>();
//       w.theta = wps[i]["theta"].as<double>();
//       w.type  = wps[i]["type"] ? wps[i]["type"].as<std::string>() : "waypoint";
//       waypoints_.push_back(w);
//       RCLCPP_INFO(get_logger(),
//         "  WP[%02zu] %-10s  x=%.3f  y=%.3f  theta=%.3f",
//         i, w.type.c_str(), w.x, w.y, w.theta);
//     }
//   } catch (const std::exception & e) {
//     RCLCPP_ERROR(get_logger(), "YAML parse error: %s", e.what());
//     return false;
//   }
//   return !waypoints_.empty();
// }

// // ─── Main Control Loop  20 Hz ─────────────────────────────────────
// void WaypointNavigator::controlLoop()
// {
//   if (init_failed_ || !pose_received_) return;

//   if (state_ == State::ALL_DONE) {
//     stopRobot();
//     RCLCPP_INFO_ONCE(get_logger(), "✅ All waypoints done! Robot stopped.");
//     return;
//   }

//   if (wp_index_ >= waypoints_.size()) {
//     state_ = loop_waypoints_ ? State::ROTATE_TO_HEADING : State::ALL_DONE;
//     if (loop_waypoints_) {
//       wp_index_ = 0;
//       RCLCPP_INFO(get_logger(), "🔁 Looping back to start.");
//     }
//     return;
//   }

//   const Waypoint & wp = waypoints_[wp_index_];

//   double dx            = wp.x - robot_x_;
//   double dy            = wp.y - robot_y_;
//   double distance      = std::hypot(dx, dy);
//   double angle_to_goal = std::atan2(dy, dx);
//   double heading_error = normalizeAngle(angle_to_goal - robot_yaw_);
//   double yaw_error     = normalizeAngle(wp.theta - robot_yaw_);

//   geometry_msgs::msg::Twist cmd;

//   // ── 1 second status log ───────────────────────────────────────
//   if (++log_counter_ >= 20) {
//     log_counter_ = 0;
//     RCLCPP_INFO(get_logger(),
//       "[%s WP%zu/%zu] pos(%.2f,%.2f,%.2f°) → (%.2f,%.2f,%.2f°) dist=%.2fm",
//       stateStr(), wp_index_, waypoints_.size() - 1,
//       robot_x_, robot_y_, robot_yaw_ * 180.0 / M_PI,
//       wp.x, wp.y, wp.theta * 180.0 / M_PI,
//       distance);
//   }

//   switch (state_)
//   {
//     // ── STATE 1: Rotate to face goal x,y ─────────────────────────
//     case State::ROTATE_TO_HEADING:
//     {
//       Waypoint prev = (wp_index_ > 0) ?
//         waypoints_[wp_index_ - 1] :
//         Waypoint{robot_x_, robot_y_, robot_yaw_};

//       // Same x,y as previous → pure rotation only
//       if (isOnlyRotation(prev, wp)) {
//         state_ = State::ROTATE_TO_THETA;
//         RCLCPP_INFO(get_logger(),
//           "[WP%zu] Same position → rotating to theta=%.2f°",
//           wp_index_, wp.theta * 180.0 / M_PI);
//         break;
//       }

//       // Already close enough
//       if (distance < xy_tolerance_) {
//         stopRobot();
//         state_ = State::ROTATE_TO_THETA;
//         RCLCPP_INFO(get_logger(),
//           "[WP%zu] Already at position → rotating to theta", wp_index_);
//         break;
//       }

//       // Heading aligned → start driving
//       if (std::abs(heading_error) < heading_tolerance_) {
//         stopRobot();
//         state_ = State::DRIVE_STRAIGHT;
//         RCLCPP_INFO(get_logger(),
//           "[WP%zu] ✓ Heading aligned (%.2f°). Driving → dist=%.3fm",
//           wp_index_, heading_error * 180.0 / M_PI, distance);
//         break;
//       }

//       // Rotate — positive = anticlockwise, negative = clockwise
//       cmd.linear.x  = 0.0;
//       cmd.angular.z = std::clamp(2.0 * heading_error, -angular_speed_, angular_speed_);
//       cmd_vel_pub_->publish(cmd);

//       RCLCPP_INFO_THROTTLE(get_logger(), *get_clock(), 500,
//         "[WP%zu] Rotating to face goal  err=%.2f°  cmd.z=%.3f",
//         wp_index_, heading_error * 180.0 / M_PI, cmd.angular.z);
//       break;
//     }

//     // ── STATE 2: Drive straight to x,y ───────────────────────────
//     case State::DRIVE_STRAIGHT:
//     {
//       // Reached goal position
//       if (distance < xy_tolerance_) {
//         stopRobot();
//         state_ = State::ROTATE_TO_THETA;
//         RCLCPP_INFO(get_logger(),
//           "[WP%zu] ✓ Position reached (%.3fm). Rotating to %.2f°",
//           wp_index_, distance, wp.theta * 180.0 / M_PI);
//         break;
//       }

//       // Obstacle
//       if (obstacle_ahead_) {
//         stopRobot();
//         RCLCPP_WARN_THROTTLE(get_logger(), *get_clock(), 1000,
//           "[WP%zu] ⚠ Obstacle! Waiting...", wp_index_);
//         break;
//       }

//       // Very off course (> 60°) — stop and re-rotate
//       if (std::abs(heading_error) > 1.05) {
//         stopRobot();
//         state_ = State::ROTATE_TO_HEADING;
//         RCLCPP_WARN(get_logger(),
//           "[WP%zu] Off course by %.2f° — re-rotating",
//           wp_index_, heading_error * 180.0 / M_PI);
//         break;
//       }

//       // Speed ramp-down near goal
//       double speed = linear_speed_;
//       if (distance < 0.30) {
//         speed = std::max(0.05, linear_speed_ * (distance / 0.30));
//       }

//       // Drive with continuous heading correction
//       cmd.linear.x  = speed;
//       cmd.angular.z = std::clamp(2.0 * heading_error, -angular_speed_, angular_speed_);
//       cmd_vel_pub_->publish(cmd);

//       RCLCPP_INFO_THROTTLE(get_logger(), *get_clock(), 500,
//         "[WP%zu] Driving  dist=%.3fm  spd=%.2f  err=%.2f°",
//         wp_index_, distance, speed, heading_error * 180.0 / M_PI);
//       break;
//     }

//     // ── STATE 3: Rotate to final theta ────────────────────────────
//     case State::ROTATE_TO_THETA:
//     {
//       if (std::abs(yaw_error) < yaw_tolerance_) {
//         stopRobot();
//         state_ = State::WAYPOINT_DONE;
//         RCLCPP_INFO(get_logger(),
//           "[WP%zu] ✅ COMPLETE  x=%.3f y=%.3f theta=%.2f°  type=%s",
//           wp_index_, wp.x, wp.y, wp.theta * 180.0 / M_PI, wp.type.c_str());
//         break;
//       }

//       // Positive error = anticlockwise, negative = clockwise
//       cmd.linear.x  = 0.0;
//       cmd.angular.z = std::clamp(2.0 * yaw_error, -angular_speed_, angular_speed_);
//       cmd_vel_pub_->publish(cmd);

//       RCLCPP_INFO_THROTTLE(get_logger(), *get_clock(), 500,
//         "[WP%zu] Rotating to final theta  err=%.2f°  cmd.z=%.3f",
//         wp_index_, yaw_error * 180.0 / M_PI, cmd.angular.z);
//       break;
//     }

//     // ── STATE 4: Load next waypoint ───────────────────────────────
//     case State::WAYPOINT_DONE:
//     {
//       wp_index_++;
//       if (wp_index_ < waypoints_.size()) {
//         state_ = State::ROTATE_TO_HEADING;
//         RCLCPP_INFO(get_logger(), "─────────────────────────────────────────");
//         RCLCPP_INFO(get_logger(),
//           "→ Next WP[%zu/%zu]  x=%.3f  y=%.3f  theta=%.2f°  type=%s",
//           wp_index_, waypoints_.size() - 1,
//           waypoints_[wp_index_].x,
//           waypoints_[wp_index_].y,
//           waypoints_[wp_index_].theta * 180.0 / M_PI,
//           waypoints_[wp_index_].type.c_str());
//       }
//       break;
//     }

//     case State::IDLE:
//     case State::ALL_DONE:
//     default:
//       break;
//   }
// }

// }  // namespace amr_navigation

// // ── main ──────────────────────────────────────────────────────────
// int main(int argc, char ** argv)
// {
//   rclcpp::init(argc, argv);
//   auto node = std::make_shared<amr_navigation::WaypointNavigator>();
//   rclcpp::spin(node);
//   rclcpp::shutdown();
//   return 0;
// }