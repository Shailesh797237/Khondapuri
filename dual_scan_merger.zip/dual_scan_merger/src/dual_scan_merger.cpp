#include <memory>
#include <vector>
#include <algorithm>
#include <cmath>
#include <limits>

#include "rclcpp/rclcpp.hpp"
#include "sensor_msgs/msg/laser_scan.hpp"
#include "message_filters/subscriber.h"
#include "message_filters/synchronizer.h"
#include "message_filters/sync_policies/approximate_time.h"

using std::placeholders::_1;
using std::placeholders::_2;

class DualScanMerger : public rclcpp::Node
{
public:
  DualScanMerger()
  : Node("dual_scan_merger")
  {
    // Topics
    front_topic_  = this->declare_parameter<std::string>("front_topic", "/front/scan");
    back_topic_   = this->declare_parameter<std::string>("back_topic", "/back/scan");
    output_topic_ = this->declare_parameter<std::string>("output_topic", "/scan");
    output_frame_ = this->declare_parameter<std::string>("output_frame", "base_link");

    // URDF yaw offsets
    front_yaw_offset_ = 0.7854;    // +45°
    back_yaw_offset_  = -2.3562;   // -135°

    // Max scan distance
    max_allowed_range_ = this->declare_parameter<double>("max_allowed_range", 5.0);

    // Directional ignore distances (meters)
    front_ignore_ = this->declare_parameter<double>("front_ignore", 0.45);
    back_ignore_  = this->declare_parameter<double>("back_ignore", 0.35);
    left_ignore_  = this->declare_parameter<double>("left_ignore", 0.30);
    right_ignore_ = this->declare_parameter<double>("right_ignore", 0.30);

    scan_pub_ = this->create_publisher<sensor_msgs::msg::LaserScan>(output_topic_, 10);

    front_sub_.subscribe(this, front_topic_);
    back_sub_.subscribe(this, back_topic_);

    sync_ = std::make_shared<Synchronizer>(SyncPolicy(10), front_sub_, back_sub_);
    sync_->registerCallback(std::bind(&DualScanMerger::scanCallback, this, _1, _2));

    RCLCPP_INFO(this->get_logger(), "Dual Scan Merger with Directional Filtering Started");
  }

private:

  typedef message_filters::sync_policies::ApproximateTime<
      sensor_msgs::msg::LaserScan,
      sensor_msgs::msg::LaserScan> SyncPolicy;

  typedef message_filters::Synchronizer<SyncPolicy> Synchronizer;

  void scanCallback(const sensor_msgs::msg::LaserScan::ConstSharedPtr front,
                    const sensor_msgs::msg::LaserScan::ConstSharedPtr back)
  {
    if(front->ranges.empty() || back->ranges.empty())
      return;

    sensor_msgs::msg::LaserScan merged;

    merged.header.stamp = this->now();
    merged.header.frame_id = output_frame_;

    merged.angle_min = -M_PI;
    merged.angle_max =  M_PI;

    merged.angle_increment = front->angle_increment;
    merged.time_increment  = front->time_increment;
    merged.scan_time       = front->scan_time;

    merged.range_min = std::min(front->range_min, back->range_min);
    merged.range_max = max_allowed_range_;

    int total_points = static_cast<int>(
        std::ceil((merged.angle_max - merged.angle_min) / merged.angle_increment));

    // Initialize with infinity (no obstacle)
    merged.ranges.assign(total_points, std::numeric_limits<float>::infinity());

    insertScan(front, merged, front_yaw_offset_);
    insertScan(back,  merged, back_yaw_offset_);

    scan_pub_->publish(merged);
  }

  void insertScan(const sensor_msgs::msg::LaserScan::ConstSharedPtr &scan,
                  sensor_msgs::msg::LaserScan &merged,
                  double yaw_offset)
  {
    for(size_t i = 0; i < scan->ranges.size(); ++i)
    {
      double angle = scan->angle_min + i * scan->angle_increment;
      angle += yaw_offset;

      while(angle > M_PI)  angle -= 2.0 * M_PI;
      while(angle < -M_PI) angle += 2.0 * M_PI;

      int index = static_cast<int>(
          std::round((angle - merged.angle_min) / merged.angle_increment));

      if(index >= 0 && index < static_cast<int>(merged.ranges.size()))
      {
        float range = scan->ranges[i];

        if(std::isfinite(range) && range >= scan->range_min)
        {
          // Determine direction sector
          double ignore_distance = 0.0;

          if(std::abs(angle) < M_PI/4.0)                 // FRONT
            ignore_distance = front_ignore_;
          else if(std::abs(angle) > 3.0*M_PI/4.0)        // BACK
            ignore_distance = back_ignore_;
          else if(angle > 0)                             // LEFT
            ignore_distance = left_ignore_;
          else                                           // RIGHT
            ignore_distance = right_ignore_;

          // Ignore robot body area
          if(range < ignore_distance)
            continue;

          if(range > max_allowed_range_)
            range = max_allowed_range_;

          merged.ranges[index] =
              std::min(merged.ranges[index], range);
        }
      }
    }
  }

  std::string front_topic_;
  std::string back_topic_;
  std::string output_topic_;
  std::string output_frame_;

  double front_yaw_offset_;
  double back_yaw_offset_;
  double max_allowed_range_;

  double front_ignore_;
  double back_ignore_;
  double left_ignore_;
  double right_ignore_;

  rclcpp::Publisher<sensor_msgs::msg::LaserScan>::SharedPtr scan_pub_;

  message_filters::Subscriber<sensor_msgs::msg::LaserScan> front_sub_;
  message_filters::Subscriber<sensor_msgs::msg::LaserScan> back_sub_;
  std::shared_ptr<Synchronizer> sync_;
};

int main(int argc, char ** argv)
{
  rclcpp::init(argc, argv);
  rclcpp::spin(std::make_shared<DualScanMerger>());
  rclcpp::shutdown();
  return 0;
}


// #include <memory>
// #include <vector>
// #include <algorithm>
// #include <cmath>
// #include <limits>

// #include "rclcpp/rclcpp.hpp"
// #include "sensor_msgs/msg/laser_scan.hpp"
// #include "message_filters/subscriber.h"
// #include "message_filters/synchronizer.h"
// #include "message_filters/sync_policies/approximate_time.h"

// using std::placeholders::_1;
// using std::placeholders::_2;

// class DualScanMerger : public rclcpp::Node
// {
// public:
//   DualScanMerger()
//   : Node("dual_scan_merger")
//   {
//     front_topic_  = this->declare_parameter<std::string>("front_topic", "/front/scan");
//     back_topic_   = this->declare_parameter<std::string>("back_topic", "/back/scan");
//     output_topic_ = this->declare_parameter<std::string>("output_topic", "/scan");
//     output_frame_ = this->declare_parameter<std::string>("output_frame", "base_link");

//     front_yaw_offset_ = 0.7854;   // +45°
//     back_yaw_offset_  = -2.3562;  // -135°

//     max_allowed_range_ = this->declare_parameter<double>("max_allowed_range", 5.0);

//     // 🔥 Robot body ignore radius (meters)
//     robot_ignore_radius_ = this->declare_parameter<double>("robot_ignore_radius", 0.60);

//     scan_pub_ = this->create_publisher<sensor_msgs::msg::LaserScan>(output_topic_, 10);

//     front_sub_.subscribe(this, front_topic_);
//     back_sub_.subscribe(this, back_topic_);

//     sync_ = std::make_shared<Synchronizer>(SyncPolicy(10), front_sub_, back_sub_);
//     sync_->registerCallback(std::bind(&DualScanMerger::scanCallback, this, _1, _2));

//     RCLCPP_INFO(this->get_logger(), "Dual Scan Merger Started with Robot Body Filtering");
//   }

// private:

//   typedef message_filters::sync_policies::ApproximateTime<
//       sensor_msgs::msg::LaserScan,
//       sensor_msgs::msg::LaserScan> SyncPolicy;

//   typedef message_filters::Synchronizer<SyncPolicy> Synchronizer;

//   void scanCallback(const sensor_msgs::msg::LaserScan::ConstSharedPtr front,
//                     const sensor_msgs::msg::LaserScan::ConstSharedPtr back)
//   {
//     if(front->ranges.empty() || back->ranges.empty())
//       return;

//     sensor_msgs::msg::LaserScan merged;

//     merged.header.stamp = this->now();
//     merged.header.frame_id = output_frame_;

//     merged.angle_min = -M_PI;
//     merged.angle_max =  M_PI;

//     merged.angle_increment = front->angle_increment;
//     merged.time_increment  = front->time_increment;
//     merged.scan_time       = front->scan_time;

//     merged.range_min = std::min(front->range_min, back->range_min);
//     merged.range_max = max_allowed_range_;

//     int total_points = static_cast<int>(
//         std::ceil((merged.angle_max - merged.angle_min) / merged.angle_increment));

//     // Initialize as infinity (no obstacle)
//     merged.ranges.assign(total_points, std::numeric_limits<float>::infinity());

//     insertScan(front, merged, front_yaw_offset_);
//     insertScan(back,  merged, back_yaw_offset_);

//     scan_pub_->publish(merged);
//   }

//   void insertScan(const sensor_msgs::msg::LaserScan::ConstSharedPtr &scan,
//                   sensor_msgs::msg::LaserScan &merged,
//                   double yaw_offset)
//   {
//     for(size_t i = 0; i < scan->ranges.size(); ++i)
//     {
//       double angle = scan->angle_min + i * scan->angle_increment;
//       angle += yaw_offset;

//       while(angle > M_PI)  angle -= 2.0 * M_PI;
//       while(angle < -M_PI) angle += 2.0 * M_PI;

//       int index = static_cast<int>(
//           std::round((angle - merged.angle_min) / merged.angle_increment));

//       if(index >= 0 && index < static_cast<int>(merged.ranges.size()))
//       {
//         float range = scan->ranges[i];

//         if(std::isfinite(range) && range >= scan->range_min)
//         {
//           // 🔥 IGNORE ROBOT BODY AREA
//           if(range < robot_ignore_radius_)
//             continue;

//           if(range > max_allowed_range_)
//             range = max_allowed_range_;

//           merged.ranges[index] =
//               std::min(merged.ranges[index], range);
//         }
//       }
//     }
//   }

//   std::string front_topic_;
//   std::string back_topic_;
//   std::string output_topic_;
//   std::string output_frame_;

//   double front_yaw_offset_;
//   double back_yaw_offset_;
//   double max_allowed_range_;
//   double robot_ignore_radius_;

//   rclcpp::Publisher<sensor_msgs::msg::LaserScan>::SharedPtr scan_pub_;
//   message_filters::Subscriber<sensor_msgs::msg::LaserScan> front_sub_;
//   message_filters::Subscriber<sensor_msgs::msg::LaserScan> back_sub_;
//   std::shared_ptr<Synchronizer> sync_;
// };

// int main(int argc, char ** argv)
// {
//   rclcpp::init(argc, argv);
//   rclcpp::spin(std::make_shared<DualScanMerger>());
//   rclcpp::shutdown();
//   return 0;
// }













// #include <memory>
// #include <vector>
// #include <algorithm>
// #include <cmath>

// #include "rclcpp/rclcpp.hpp"
// #include "sensor_msgs/msg/laser_scan.hpp"
// #include "message_filters/subscriber.h"
// #include "message_filters/synchronizer.h"
// #include "message_filters/sync_policies/approximate_time.h"

// using std::placeholders::_1;
// using std::placeholders::_2;

// class DualScanMerger : public rclcpp::Node
// {
// public:
//   DualScanMerger()
//   : Node("dual_scan_merger")
//   {
//     // Topics
//     front_topic_  = this->declare_parameter<std::string>("front_topic", "/front/scan");
//     back_topic_   = this->declare_parameter<std::string>("back_topic", "/back/scan");
//     output_topic_ = this->declare_parameter<std::string>("output_topic", "/scan");
//     output_frame_ = this->declare_parameter<std::string>("output_frame", "base_link");

//     // 🔥 URDF yaw offsets (from your robot)
//     front_yaw_offset_ = 0.7854;   // +45°
//     back_yaw_offset_  = -2.3562;  // -135°

//     // 🔥 Max allowed range (default 30m)
//     max_allowed_range_ = this->declare_parameter<double>("max_allowed_range", 30.0);

//     scan_pub_ = this->create_publisher<sensor_msgs::msg::LaserScan>(output_topic_, 10);

//     front_sub_.subscribe(this, front_topic_);
//     back_sub_.subscribe(this, back_topic_);

//     sync_ = std::make_shared<Synchronizer>(SyncPolicy(10), front_sub_, back_sub_);
//     sync_->registerCallback(std::bind(&DualScanMerger::scanCallback, this, _1, _2));

//     RCLCPP_INFO(this->get_logger(), "Dual Scan Merger Started");
//   }

// private:

//   typedef message_filters::sync_policies::ApproximateTime<
//       sensor_msgs::msg::LaserScan,
//       sensor_msgs::msg::LaserScan> SyncPolicy;

//   typedef message_filters::Synchronizer<SyncPolicy> Synchronizer;

//   void scanCallback(const sensor_msgs::msg::LaserScan::ConstSharedPtr front,
//                     const sensor_msgs::msg::LaserScan::ConstSharedPtr back)
//   {
//     if(front->ranges.empty() || back->ranges.empty())
//       return;

//     sensor_msgs::msg::LaserScan merged;

//     merged.header.stamp = this->now();
//     merged.header.frame_id = output_frame_;

//     // Full 360°
//     merged.angle_min = -M_PI;
//     merged.angle_max =  M_PI;

//     merged.angle_increment = front->angle_increment;
//     merged.time_increment  = front->time_increment;
//     merged.scan_time       = front->scan_time;

//     merged.range_min = std::min(front->range_min, back->range_min);

//     // 🔥 Force range max to 30m (or parameter)
//     merged.range_max = max_allowed_range_;

//     int total_points = static_cast<int>(
//         std::ceil((merged.angle_max - merged.angle_min) / merged.angle_increment));

//     merged.ranges.assign(total_points, merged.range_max);

//     insertScan(front, merged, front_yaw_offset_);
//     insertScan(back,  merged, back_yaw_offset_);

//     scan_pub_->publish(merged);
//   }

//   void insertScan(const sensor_msgs::msg::LaserScan::ConstSharedPtr &scan,
//                   sensor_msgs::msg::LaserScan &merged,
//                   double yaw_offset)
//   {
//     for(size_t i = 0; i < scan->ranges.size(); ++i)
//     {
//       double angle = scan->angle_min + i * scan->angle_increment;

//       // Apply URDF yaw correction
//       angle += yaw_offset;

//       // Normalize angle to [-pi, pi]
//       while(angle > M_PI)  angle -= 2.0 * M_PI;
//       while(angle < -M_PI) angle += 2.0 * M_PI;

//       int index = static_cast<int>(
//           std::round((angle - merged.angle_min) / merged.angle_increment));

//       if(index >= 0 && index < static_cast<int>(merged.ranges.size()))
//       {
//         float range = scan->ranges[i];

//         if(std::isfinite(range) && range >= scan->range_min)
//         {
//           // 🔥 Clamp to max allowed range (30m)
//           if(range > max_allowed_range_)
//             range = max_allowed_range_;

//           merged.ranges[index] =
//               std::min(merged.ranges[index], range);
//         }
//       }
//     }
//   }

//   std::string front_topic_;
//   std::string back_topic_;
//   std::string output_topic_;
//   std::string output_frame_;

//   double front_yaw_offset_;
//   double back_yaw_offset_;
//   double max_allowed_range_;

//   rclcpp::Publisher<sensor_msgs::msg::LaserScan>::SharedPtr scan_pub_;

//   message_filters::Subscriber<sensor_msgs::msg::LaserScan> front_sub_;
//   message_filters::Subscriber<sensor_msgs::msg::LaserScan> back_sub_;
//   std::shared_ptr<Synchronizer> sync_;
// };

// int main(int argc, char ** argv)
// {
//   rclcpp::init(argc, argv);
//   rclcpp::spin(std::make_shared<DualScanMerger>());
//   rclcpp::shutdown();
//   return 0;
// }