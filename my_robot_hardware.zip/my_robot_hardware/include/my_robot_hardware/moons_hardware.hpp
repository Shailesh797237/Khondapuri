#ifndef MOONS_HARDWARE_HPP
#define MOONS_HARDWARE_HPP

#include <modbus/modbus.h>
#include <string>
#include <mutex>
#include <unistd.h>
#include <cstdint>

class MoonsMotorEnable
{
public:
  MoonsMotorEnable(const std::string& port,
                   int baudrate,
                   int left_slave,
                   int right_slave,
                   int enable_register,
                   int speed_register,
                   int encoder_register)
  : port_(port),
    baudrate_(baudrate),
    left_slave_(left_slave),
    right_slave_(right_slave),
    enable_reg_(enable_register - 40001),
    speed_reg_(speed_register - 40001),
    encoder_reg_(encoder_register - 40001),

    // ===== ADDED FOR ERROR MONITORING =====
    error_reg_(0)   // 40001 → offset 0
    // ======================================
  {}

  ~MoonsMotorEnable()
  {
    if (ctx_)
    {
      modbus_close(ctx_);
      modbus_free(ctx_);
    }
  }

  bool connect()
  {
    ctx_ = modbus_new_rtu(port_.c_str(), baudrate_, 'N', 8, 1);
    if (!ctx_) return false;

    modbus_set_response_timeout(ctx_, 1, 0);

    if (modbus_connect(ctx_) == -1)
      return false;

    return true;
  }

  bool enableMotors()  { return writeEnable(159); }
  bool enableJogMode() { return writeEnable(150); }
  bool disableMotors() { return writeEnable(0);   }

  bool setJogSpeed(int32_t left_speed, int32_t right_speed)
  {
    writeSpeed32(left_slave_, left_speed);
    //usleep(100000);
    writeSpeed32(right_slave_, right_speed);
    return true;
  }

  int32_t readEncoder(int slave)
  {
    uint16_t regs[2];

    std::lock_guard<std::mutex> lock(mutex_);
    modbus_set_slave(ctx_, slave);

    if (modbus_read_registers(ctx_, encoder_reg_, 2, regs) != 2)
      return 0;

    return (int32_t)((regs[0] << 16) | regs[1]);
  }

  // ===== ADDED FOR ERROR MONITORING =====
  uint16_t readError(int slave)
  {
    uint16_t value = 0;

    std::lock_guard<std::mutex> lock(mutex_);
    modbus_set_slave(ctx_, slave);

    if (modbus_read_registers(ctx_, error_reg_, 1, &value) != 1)
      return 0;

    return value;
  }
  // ======================================

private:
  bool writeEnable(int value)
  {
    std::lock_guard<std::mutex> lock(mutex_);

    modbus_set_slave(ctx_, left_slave_);
    modbus_write_register(ctx_, enable_reg_, value);
    usleep(100000);

    modbus_set_slave(ctx_, right_slave_);
    modbus_write_register(ctx_, enable_reg_, value);
    usleep(100000);

    return true;
  }

  bool writeSpeed32(int slave, int32_t speed)
  {
    uint16_t regs[2];
    regs[0] = (speed >> 16) & 0xFFFF;
    regs[1] = speed & 0xFFFF;

    modbus_set_slave(ctx_, slave);
    return modbus_write_registers(ctx_, speed_reg_, 2, regs) != -1;
  }

  std::string port_;
  int baudrate_;
  int left_slave_;
  int right_slave_;
  int enable_reg_;
  int speed_reg_;
  int encoder_reg_;

  // ===== ADDED FOR ERROR MONITORING =====
  int error_reg_;
  // ======================================

  modbus_t* ctx_{nullptr};
  std::mutex mutex_;
};

#endif



// #ifndef MOONS_HARDWARE_HPP
// #define MOONS_HARDWARE_HPP

// #include <modbus/modbus.h>
// #include <string>
// #include <mutex>
// #include <unistd.h>
// #include <cstdint>

// class MoonsMotorEnable
// {
// public:
//   MoonsMotorEnable(const std::string& port,
//                    int baudrate,
//                    int left_slave,
//                    int right_slave,
//                    int enable_register,
//                    int speed_register,
//                    int encoder_register)
//   : port_(port),
//     baudrate_(baudrate),
//     left_slave_(left_slave),
//     right_slave_(right_slave),
//     enable_reg_(enable_register - 40001),
//     speed_reg_(speed_register - 40001),
//     encoder_reg_(encoder_register - 40001)
//   {}

//   ~MoonsMotorEnable()
//   {
//     if (ctx_)
//     {
//       modbus_close(ctx_);
//       modbus_free(ctx_);
//     }
//   }

//   bool connect()
//   {
//     ctx_ = modbus_new_rtu(port_.c_str(), baudrate_, 'N', 8, 1);
//     if (!ctx_) return false;

//     modbus_set_response_timeout(ctx_, 1, 0);

//     if (modbus_connect(ctx_) == -1)
//       return false;

//     return true;
//   }

//   bool enableMotors()  { return writeEnable(159); }
//   bool enableJogMode() { return writeEnable(150); }
//   bool disableMotors() { return writeEnable(0);   }

//   bool setJogSpeed(int32_t left_speed, int32_t right_speed)
//   {
//     writeSpeed32(left_slave_, left_speed);
//     usleep(100000);
//     writeSpeed32(right_slave_, right_speed);
//     return true;
//   }

//   int32_t readEncoder(int slave)
//   {
//     uint16_t regs[2];

//     std::lock_guard<std::mutex> lock(mutex_);
//     modbus_set_slave(ctx_, slave);

//     if (modbus_read_registers(ctx_, encoder_reg_, 2, regs) != 2)
//       return 0;

//     return (int32_t)((regs[0] << 16) | regs[1]);
//   }

// private:
//   bool writeEnable(int value)
//   {
//     std::lock_guard<std::mutex> lock(mutex_);

//     modbus_set_slave(ctx_, left_slave_);
//     modbus_write_register(ctx_, enable_reg_, value);
//     usleep(100000);

//     modbus_set_slave(ctx_, right_slave_);
//     modbus_write_register(ctx_, enable_reg_, value);
//     usleep(100000);

//     return true;
//   }

//   bool writeSpeed32(int slave, int32_t speed)
//   {
//     uint16_t regs[2];
//     regs[0] = (speed >> 16) & 0xFFFF;
//     regs[1] = speed & 0xFFFF;

//     modbus_set_slave(ctx_, slave);
//     return modbus_write_registers(ctx_, speed_reg_, 2, regs) != -1;
//   }

//   std::string port_;
//   int baudrate_;
//   int left_slave_;
//   int right_slave_;
//   int enable_reg_;
//   int speed_reg_;
//   int encoder_reg_;

//   modbus_t* ctx_{nullptr};
//   std::mutex mutex_;
// };

// #endif
