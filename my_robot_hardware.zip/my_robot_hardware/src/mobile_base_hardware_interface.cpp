/// try this 

#include "my_robot_hardware/mobile_base_hardware.hpp"

#include "hardware_interface/types/hardware_interface_type_values.hpp"
#include "pluginlib/class_list_macros.hpp"
#include "rclcpp/rclcpp.hpp"

#include <unistd.h>
#include <cmath>
#include <algorithm>

namespace mobile_base_hardware
{

hardware_interface::CallbackReturn
MobileBaseHardwareInterface::on_init(
  const hardware_interface::HardwareInfo & info)
{
  if (hardware_interface::SystemInterface::on_init(info) !=
      hardware_interface::CallbackReturn::SUCCESS)
  {
    return hardware_interface::CallbackReturn::ERROR;
  }

  info_ = info;

  if (info_.hardware_parameters.find("pulses_per_revolution") ==
      info_.hardware_parameters.end())
  {
    RCLCPP_ERROR(
      rclcpp::get_logger("MobileBaseHardwareInterface"),
      "pulses_per_revolution parameter NOT set!");
    return hardware_interface::CallbackReturn::ERROR;
  }

  pulses_per_revolution_ =
    std::stod(info_.hardware_parameters.at("pulses_per_revolution"));

  port_      = "/dev/ttyUSB0";
  baudrate_  = 115200;
  left_slave_  = 1;
  right_slave_ = 2;
  max_rpm_ = 24000;

  left_pos_ = right_pos_ = 0.0;
  left_vel_ = right_vel_ = 0.0;
  left_cmd_ = right_cmd_ = 0.0;

  prev_left_encoder_ = 0;
  prev_right_encoder_ = 0;

  driver_ = std::make_shared<MoonsMotorEnable>(
    port_, baudrate_,
    left_slave_, right_slave_,
    40125, 40343, 40011);

  return hardware_interface::CallbackReturn::SUCCESS;
}

hardware_interface::CallbackReturn
MobileBaseHardwareInterface::on_configure(
  const rclcpp_lifecycle::State &)
{
  if (!driver_ || !driver_->connect())
    return hardware_interface::CallbackReturn::ERROR;

  return hardware_interface::CallbackReturn::SUCCESS;
}

hardware_interface::CallbackReturn
MobileBaseHardwareInterface::on_activate(
  const rclcpp_lifecycle::State &)
{
  driver_->enableMotors();
  usleep(500000);
  driver_->enableJogMode();
  usleep(200000);

  prev_left_encoder_  = driver_->readEncoder(left_slave_);
  prev_right_encoder_ = driver_->readEncoder(right_slave_);

  left_pos_ = right_pos_ = 0.0;

  return hardware_interface::CallbackReturn::SUCCESS;
}

hardware_interface::CallbackReturn
MobileBaseHardwareInterface::on_deactivate(
  const rclcpp_lifecycle::State &)
{
  driver_->disableMotors();
  return hardware_interface::CallbackReturn::SUCCESS;
}

std::vector<hardware_interface::StateInterface>
MobileBaseHardwareInterface::export_state_interfaces()
{
  std::vector<hardware_interface::StateInterface> state_interfaces;

  // state_interfaces.emplace_back(
  //   "base_left_wheel_joint",
  //   hardware_interface::HW_IF_POSITION,
  //   &left_pos_);

  // state_interfaces.emplace_back(
  //   "base_left_wheel_joint",
  //   hardware_interface::HW_IF_VELOCITY,
  //   &left_vel_);

  // state_interfaces.emplace_back(
  //   "base_right_wheel_joint",
  //   hardware_interface::HW_IF_POSITION,
  //   &right_pos_);

  // state_interfaces.emplace_back(
  //   "base_right_wheel_joint",
  //   hardware_interface::HW_IF_VELOCITY,
  //   &right_vel_);

  // state_interfaces.emplace_back(
  //   "base_left_wheel_joint",
  //   hardware_interface::HW_IF_POSITION,
  //   &left_pos_);
  state_interfaces.emplace_back(
    "leftwheel",
    hardware_interface::HW_IF_POSITION,
    &left_pos_);

  state_interfaces.emplace_back(
    "leftwheel",
    hardware_interface::HW_IF_VELOCITY,
    &left_vel_);

  state_interfaces.emplace_back(
    "rightwheel",
    hardware_interface::HW_IF_POSITION,
    &right_pos_);

  state_interfaces.emplace_back(
    "rightwheel",
    hardware_interface::HW_IF_VELOCITY,
    &right_vel_);  

  // state_interfaces.emplace_back(
  //   "rightwheel",
  //   hardware_interface::HW_IF_POSITION
  //   &right_vel_); 
  
  // state_interfaces.emplace_back(
  //   "rightwheel",
  //   hardware_interface::HW_IF_POSITION,
  //   &right_vel_);   


  return state_interfaces;
}

std::vector<hardware_interface::CommandInterface>
MobileBaseHardwareInterface::export_command_interfaces()
{
  std::vector<hardware_interface::CommandInterface> command_interfaces;

  // command_interfaces.emplace_back(
  //   "base_left_wheel_joint",
  //   hardware_interface::HW_IF_VELOCITY,
  //   &left_cmd_);

  // command_interfaces.emplace_back(
  //   "base_right_wheel_joint",
  //   hardware_interface::HW_IF_VELOCITY,
  //   &right_cmd_);

   command_interfaces.emplace_back(
    "leftwheel",
    hardware_interface::HW_IF_VELOCITY,
    &left_cmd_);

  command_interfaces.emplace_back(
    "rightwheel",
    hardware_interface::HW_IF_VELOCITY,
    &right_cmd_);  

  return command_interfaces;
}

hardware_interface::return_type
MobileBaseHardwareInterface::read(
  const rclcpp::Time &, const rclcpp::Duration & period)
{



   // ===== ADDED FOR ERROR MONITORING (REGISTER 40001) =====
  uint32_t left_error  = driver_->readError(left_slave_);
  uint32_t right_error = driver_->readError(right_slave_);

  if (left_error == 2 || right_error == 2)
  {
    RCLCPP_WARN(rclcpp::get_logger("MobileBaseHardwareInterface"),
                "Error 2 detected. Waiting for clear...");

    while (true)
    {
      left_error  = driver_->readError(left_slave_);
      right_error = driver_->readError(right_slave_);

      if (left_error == 0 && right_error == 0)
      {
        RCLCPP_INFO(rclcpp::get_logger("MobileBaseHardwareInterface"),
                    "Error cleared. Re-enabling motors.");
        usleep(1000000);
        driver_->enableMotors();
        usleep(200000);
        driver_->enableJogMode();
        usleep(10000);
        break;
      }

      // usleep(200000);
    }
  }
  // ========================================================



  int32_t left_enc  = driver_->readEncoder(left_slave_);
  int32_t right_enc = driver_->readEncoder(right_slave_);

  // 1️⃣ Compute delta
  int32_t delta_left  = left_enc  - prev_left_encoder_;
  int32_t delta_right = right_enc - prev_right_encoder_;

  // 2️⃣ Update previous values
  prev_left_encoder_  = left_enc;
  prev_right_encoder_ = right_enc;

  // 3️⃣ Convert ticks → radians
  double rad_per_pulse = 2.0 * M_PI / pulses_per_revolution_;

  double delta_left_rad  = delta_left  * rad_per_pulse;
  double delta_right_rad = delta_right * rad_per_pulse;

  // 4️⃣ Update wheel position
  left_pos_  += delta_left_rad;
  right_pos_ += delta_right_rad;

  // RCLCPP_INFO(rclcpp::get_logger("MobileBaseHardwareInterface"),
  //         "left_pos_=%.3f right_pos_=%.3f",
  //         left_pos_, right_pos_);

  // 5️⃣ Compute velocity
  double dt = period.seconds();
  if (dt > 0.0001)
  {
    left_vel_  = delta_left_rad  / dt;
    right_vel_ = delta_right_rad / dt;
  }
  else
  {
    left_vel_ = right_vel_ = 0.0;
  }

  // RCLCPP_INFO(rclcpp::get_logger("MobileBaseHardwareInterface"),
  //           "left_vel=%.3f right_vel=%.3f",
  //           left_vel_, right_vel_);


  // RCLCPP_INFO(rclcpp::get_logger("MobileBaseHardwareInterface"),
  //   "Encoders L=%d R=%d | ΔL=%d ΔR=%d | PosL=%.3f PosR=%.3f",
  //   left_enc, right_enc, delta_left, delta_right,
  //   left_pos_, right_pos_);

  return hardware_interface::return_type::OK;
}

hardware_interface::return_type
MobileBaseHardwareInterface::write(
  const rclcpp::Time &, const rclcpp::Duration &)
{
  int left_rpm  = radPerSecToRpm(left_cmd_);
  int right_rpm = radPerSecToRpm(right_cmd_);

  

  // left_rpm  = std::clamp(left_rpm,  -max_rpm_, max_rpm_);
  // right_rpm = std::clamp(right_rpm, -max_rpm_, max_rpm_);

  // if (left_rpm > max_rpm_) left_rpm = max_rpm_;
  // if (left_rpm < -max_rpm_) left_rpm = -max_rpm_;

  // if (right_rpm > max_rpm_) right_rpm = max_rpm_;
  // if (right_rpm < -max_rpm_) right_rpm = -max_rpm_;

  // Clamp to max RPM
  left_rpm  = std::clamp(left_rpm,  -max_rpm_, max_rpm_);
  right_rpm = std::clamp(right_rpm, -max_rpm_, max_rpm_);

  // ---- NEW CONVERSION ----
  double left_rps  = static_cast<double>(left_rpm) / 60.0;
  double right_rps = static_cast<double>(right_rpm) / 60.0;

  int final_left_rpm  = static_cast<int>(std::round(left_rps * 240.0));
  int final_right_rpm = static_cast<int>(std::round(right_rps * 240.0));
  // ------------------------

  driver_->setJogSpeed(final_left_rpm, final_right_rpm);

  RCLCPP_INFO(rclcpp::get_logger("MobileBaseHardwareInterface"),
            "final_left_rpm=%.3d final_right_rpm=%.3d",
            final_left_rpm, final_right_rpm);

  return hardware_interface::return_type::OK;
}

int MobileBaseHardwareInterface::radPerSecToRpm(double rad_per_sec)
{
  double motor_rad_per_sec = rad_per_sec * gear_ratio_;
  return static_cast<int>(motor_rad_per_sec * 60.0 / (2.0 * M_PI));
}

}  

PLUGINLIB_EXPORT_CLASS(
  mobile_base_hardware::MobileBaseHardwareInterface,
  hardware_interface::SystemInterface)





// #include "my_robot_hardware/mobile_base_hardware.hpp"

// #include "hardware_interface/types/hardware_interface_type_values.hpp"
// #include "pluginlib/class_list_macros.hpp"
// #include "rclcpp/rclcpp.hpp"

// #include <unistd.h>
// #include <cmath>
// #include <algorithm>

// namespace mobile_base_hardware
// {

// hardware_interface::CallbackReturn
// MobileBaseHardwareInterface::on_init(
//   const hardware_interface::HardwareInfo & info)
// {
//   if (hardware_interface::SystemInterface::on_init(info) !=
//       hardware_interface::CallbackReturn::SUCCESS)
//   {
//     return hardware_interface::CallbackReturn::ERROR;
//   }

//   info_ = info;

//   if (info_.hardware_parameters.find("pulses_per_revolution") ==
//       info_.hardware_parameters.end())
//   {
//     RCLCPP_ERROR(
//       rclcpp::get_logger("MobileBaseHardwareInterface"),
//       "pulses_per_revolution parameter NOT set!");
//     return hardware_interface::CallbackReturn::ERROR;
//   }

//   pulses_per_revolution_ =
//     std::stod(info_.hardware_parameters.at("pulses_per_revolution"));

//   port_      = "/dev/ttyUSB0";
//   baudrate_  = 9600;
//   left_slave_  = 1;
//   right_slave_ = 2;
//   max_rpm_ = 24000;

//   left_pos_ = right_pos_ = 0.0;
//   left_vel_ = right_vel_ = 0.0;
//   left_cmd_ = right_cmd_ = 0.0;

//   prev_left_encoder_ = 0;
//   prev_right_encoder_ = 0;

//   driver_ = std::make_shared<MoonsMotorEnable>(
//     port_, baudrate_,
//     left_slave_, right_slave_,
//     40125, 40343, 40011);

//   // ✅ ADDED: cmd_vel subscription
//   cmd_vel_sub_ = get_node()->create_subscription<geometry_msgs::msg::Twist>(
//     "/diff_drive_controller/cmd_vel", 10,
//     std::bind(&MobileBaseHardwareInterface::cmdVelCallback, this, std::placeholders::_1));

//   return hardware_interface::CallbackReturn::SUCCESS;
// }

// hardware_interface::CallbackReturn
// MobileBaseHardwareInterface::on_configure(
//   const rclcpp_lifecycle::State &)
// {
//   if (!driver_ || !driver_->connect())
//     return hardware_interface::CallbackReturn::ERROR;

//   return hardware_interface::CallbackReturn::SUCCESS;
// }

// hardware_interface::CallbackReturn
// MobileBaseHardwareInterface::on_activate(
//   const rclcpp_lifecycle::State &)
// {
//   driver_->enableMotors();
//   usleep(500000);
//   driver_->enableJogMode();
//   usleep(200000);

//   prev_left_encoder_  = driver_->readEncoder(left_slave_);
//   prev_right_encoder_ = driver_->readEncoder(right_slave_);

//   left_pos_ = right_pos_ = 0.0;

//   return hardware_interface::CallbackReturn::SUCCESS;
// }

// hardware_interface::CallbackReturn
// MobileBaseHardwareInterface::on_deactivate(
//   const rclcpp_lifecycle::State &)
// {
//   driver_->disableMotors();
//   return hardware_interface::CallbackReturn::SUCCESS;
// }

// std::vector<hardware_interface::StateInterface>
// MobileBaseHardwareInterface::export_state_interfaces()
// {
//   std::vector<hardware_interface::StateInterface> state_interfaces;

//   state_interfaces.emplace_back(
//     "base_left_wheel_joint",
//     hardware_interface::HW_IF_POSITION,
//     &left_pos_);

//   state_interfaces.emplace_back(
//     "base_left_wheel_joint",
//     hardware_interface::HW_IF_VELOCITY,
//     &left_vel_);

//   state_interfaces.emplace_back(
//     "base_right_wheel_joint",
//     hardware_interface::HW_IF_POSITION,
//     &right_pos_);

//   state_interfaces.emplace_back(
//     "base_right_wheel_joint",
//     hardware_interface::HW_IF_VELOCITY,
//     &right_vel_);

//   return state_interfaces;
// }

// std::vector<hardware_interface::CommandInterface>
// MobileBaseHardwareInterface::export_command_interfaces()
// {
//   std::vector<hardware_interface::CommandInterface> command_interfaces;

//   command_interfaces.emplace_back(
//     "base_left_wheel_joint",
//     hardware_interface::HW_IF_VELOCITY,
//     &left_cmd_);

//   command_interfaces.emplace_back(
//     "base_right_wheel_joint",
//     hardware_interface::HW_IF_VELOCITY,
//     &right_cmd_);

//   return command_interfaces;
// }

// // ✅ ADDED: cmd_vel callback
// void MobileBaseHardwareInterface::cmdVelCallback(
//   const geometry_msgs::msg::Twist::SharedPtr msg)
// {
//   desired_linear_ = msg->linear.x;
//   desired_angular_ = msg->angular.z;
// }

// bool MobileBaseHardwareInterface::isValidEncoder(int32_t value)
// {
//   // Example validity check
//   return (value > 0 && value < 1000000000);
// }

// int32_t MobileBaseHardwareInterface::normalizeDelta(int32_t delta)
// {
//   const int32_t MAX = 2147483647;
//   const int32_t MIN = -2147483648;

//   if (delta > MAX/2)  delta -= MAX;
//   if (delta < MIN/2)  delta += MAX;
//   return delta;
// }

// hardware_interface::return_type
// MobileBaseHardwareInterface::read(
//   const rclcpp::Time &, const rclcpp::Duration & period)
// {
//   int32_t left_enc  = driver_->readEncoder(left_slave_);
//   int32_t right_enc = driver_->readEncoder(right_slave_);

//   int32_t delta_left = 0;
//   int32_t delta_right = 0;

//   // ✅ Fix: ignore invalid encoder values
//   if (isValidEncoder(left_enc))
//   {
//     delta_left = left_enc - prev_left_encoder_;
//     prev_left_encoder_ = left_enc;
//   }

//   if (isValidEncoder(right_enc))
//   {
//     delta_right = right_enc - prev_right_encoder_;
//     prev_right_encoder_ = right_enc;
//   }

//   // ✅ Fix: handle encoder overflow
//   delta_left  = normalizeDelta(delta_left);
//   delta_right = normalizeDelta(delta_right);

//   double rad_per_pulse = 2.0 * M_PI / pulses_per_revolution_;

//   // ✅ Fix: invert right wheel sign (because encoder sign is reversed)
//   double delta_left_rad  = delta_left  * rad_per_pulse;
//   double delta_right_rad = -delta_right * rad_per_pulse;

//   left_pos_  += delta_left_rad;
//   right_pos_ += delta_right_rad;

//   double dt = period.seconds();
//   if (dt > 0.0001)
//   {
//     left_vel_  = delta_left_rad  / dt;
//     right_vel_ = delta_right_rad / dt;
//   }
//   else
//   {
//     left_vel_ = right_vel_ = 0.0;
//   }

//   RCLCPP_INFO(rclcpp::get_logger("MobileBaseHardwareInterface"),
//     "Encoders L=%d R=%d | ΔL=%d ΔR=%d | PosL=%.3f PosR=%.3f",
//     left_enc, right_enc, delta_left, delta_right,
//     left_pos_, right_pos_);

//   return hardware_interface::return_type::OK;
// }

// hardware_interface::return_type
// MobileBaseHardwareInterface::write(
//   const rclcpp::Time &, const rclcpp::Duration &)
// {
//   // ✅ ADDED: convert cmd_vel -> wheel velocity
//   double v = desired_linear_;
//   double w = desired_angular_;

//   double v_left  = v - (wheel_separation_ / 2.0) * w;
//   double v_right = v + (wheel_separation_ / 2.0) * w;

//   left_cmd_  = v_left  / wheel_radius_;
//   right_cmd_ = v_right / wheel_radius_;

//   int left_rpm  = radPerSecToRpm(left_cmd_);
//   int right_rpm = radPerSecToRpm(right_cmd_);

//   left_rpm  = std::clamp(left_rpm,  -max_rpm_, max_rpm_);
//   right_rpm = std::clamp(right_rpm, -max_rpm_, max_rpm_);

//   driver_->setJogSpeed(left_rpm, right_rpm);

//   return hardware_interface::return_type::OK;
// }

// int MobileBaseHardwareInterface::radPerSecToRpm(double rad_per_sec)
// {
//   return static_cast<int>(rad_per_sec * 60.0 / (2.0 * M_PI));
// }

// }  

// PLUGINLIB_EXPORT_CLASS(
//   mobile_base_hardware::MobileBaseHardwareInterface,
//   hardware_interface::SystemInterface)





// #include "my_robot_hardware/mobile_base_hardware.hpp"

// #include "hardware_interface/types/hardware_interface_type_values.hpp"
// #include "pluginlib/class_list_macros.hpp"
// #include "rclcpp/rclcpp.hpp"

// #include <unistd.h>
// #include <cmath>
// #include <algorithm>

// namespace mobile_base_hardware
// {

// hardware_interface::CallbackReturn
// MobileBaseHardwareInterface::on_init(
//   const hardware_interface::HardwareInfo & info)
// {
//   if (hardware_interface::SystemInterface::on_init(info) !=
//       hardware_interface::CallbackReturn::SUCCESS)
//   {
//     return hardware_interface::CallbackReturn::ERROR;
//   }

//   info_ = info;

//   if (info_.hardware_parameters.find("pulses_per_revolution") ==
//       info_.hardware_parameters.end())
//   {
//     RCLCPP_ERROR(
//       rclcpp::get_logger("MobileBaseHardwareInterface"),
//       "pulses_per_revolution parameter NOT set!");
//     return hardware_interface::CallbackReturn::ERROR;
//   }

//   pulses_per_revolution_ =
//     std::stod(info_.hardware_parameters.at("pulses_per_revolution"));

//   port_      = "/dev/ttyUSB0";
//   baudrate_  = 9600;
//   left_slave_  = 1;
//   right_slave_ = 2;
//   max_rpm_ = 24000;

//   left_pos_ = right_pos_ = 0.0;
//   left_vel_ = right_vel_ = 0.0;
//   left_cmd_ = right_cmd_ = 0.0;

//   prev_left_encoder_ = 0;
//   prev_right_encoder_ = 0;

//   driver_ = std::make_shared<MoonsMotorEnable>(
//     port_, baudrate_,
//     left_slave_, right_slave_,
//     40125, 40343, 40011);

//   return hardware_interface::CallbackReturn::SUCCESS;
// }

// hardware_interface::CallbackReturn
// MobileBaseHardwareInterface::on_configure(
//   const rclcpp_lifecycle::State &)
// {
//   if (!driver_ || !driver_->connect())
//     return hardware_interface::CallbackReturn::ERROR;

//   return hardware_interface::CallbackReturn::SUCCESS;
// }

// hardware_interface::CallbackReturn
// MobileBaseHardwareInterface::on_activate(
//   const rclcpp_lifecycle::State &)
// {
//   driver_->enableMotors();
//   usleep(500000);
//   driver_->enableJogMode();
//   usleep(200000);

//   prev_left_encoder_  = driver_->readEncoder(left_slave_);
//   prev_right_encoder_ = driver_->readEncoder(right_slave_);

//   left_pos_ = right_pos_ = 0.0;

//   return hardware_interface::CallbackReturn::SUCCESS;
// }

// hardware_interface::CallbackReturn
// MobileBaseHardwareInterface::on_deactivate(
//   const rclcpp_lifecycle::State &)
// {
//   driver_->disableMotors();
//   return hardware_interface::CallbackReturn::SUCCESS;
// }

// std::vector<hardware_interface::StateInterface>
// MobileBaseHardwareInterface::export_state_interfaces()
// {
//   std::vector<hardware_interface::StateInterface> state_interfaces;

//   state_interfaces.emplace_back(
//     "base_left_wheel_joint",
//     hardware_interface::HW_IF_POSITION,
//     &left_pos_);

//   state_interfaces.emplace_back(
//     "base_left_wheel_joint",
//     hardware_interface::HW_IF_VELOCITY,
//     &left_vel_);

//   state_interfaces.emplace_back(
//     "base_right_wheel_joint",
//     hardware_interface::HW_IF_POSITION,
//     &right_pos_);

//   state_interfaces.emplace_back(
//     "base_right_wheel_joint",
//     hardware_interface::HW_IF_VELOCITY,
//     &right_vel_);

//   return state_interfaces;
// }

// std::vector<hardware_interface::CommandInterface>
// MobileBaseHardwareInterface::export_command_interfaces()
// {
//   std::vector<hardware_interface::CommandInterface> command_interfaces;

//   command_interfaces.emplace_back(
//     "base_left_wheel_joint",
//     hardware_interface::HW_IF_VELOCITY,
//     &left_cmd_);

//   command_interfaces.emplace_back(
//     "base_right_wheel_joint",
//     hardware_interface::HW_IF_VELOCITY,
//     &right_cmd_);

//   return command_interfaces;
// }

// hardware_interface::return_type
// MobileBaseHardwareInterface::read(
//   const rclcpp::Time &, const rclcpp::Duration & period)
// {
//   int32_t left_enc  = driver_->readEncoder(left_slave_);
//   int32_t right_enc = driver_->readEncoder(right_slave_);

//   int32_t delta_left  = left_enc  - prev_left_encoder_;
//   int32_t delta_right = right_enc - prev_right_encoder_;

//   prev_left_encoder_  = left_enc;
//   prev_right_encoder_ = right_enc;

//   double rad_per_pulse = 2.0 * M_PI / pulses_per_revolution_;

//   double delta_left_rad  = delta_left  * rad_per_pulse;
//   double delta_right_rad = delta_right * rad_per_pulse;

//   left_pos_  += delta_left_rad;
//   right_pos_ += delta_right_rad;

//   double dt = period.seconds();
//   if (dt > 0.0001)
//   {
//     left_vel_  = delta_left_rad  / dt;
//     right_vel_ = delta_right_rad / dt;
//   }
//   else
//   {
//     left_vel_ = right_vel_ = 0.0;
//   }

//   auto logger = rclcpp::get_logger("MobileBaseHardwareInterface");
//   RCLCPP_INFO(logger,
//     "Encoders: left=%d right=%d | delta: left=%d right=%d | vel: left=%.5f right=%.5f",
//     left_enc, right_enc, delta_left, delta_right, left_vel_, right_vel_);

//   return hardware_interface::return_type::OK;
// }

// hardware_interface::return_type
// MobileBaseHardwareInterface::write(
//   const rclcpp::Time &, const rclcpp::Duration &)
// {
//   int left_rpm  = radPerSecToRpm(left_cmd_);
//   int right_rpm = radPerSecToRpm(right_cmd_);

//   left_rpm  = std::clamp(left_rpm,  -max_rpm_, max_rpm_);
//   right_rpm = std::clamp(right_rpm, -max_rpm_, max_rpm_);

//   driver_->setJogSpeed(left_rpm, right_rpm);

//   return hardware_interface::return_type::OK;
// }

// int MobileBaseHardwareInterface::radPerSecToRpm(double rad_per_sec)
// {
//   return static_cast<int>(rad_per_sec * 60.0 / (2.0 * M_PI));
// }

// }  

// PLUGINLIB_EXPORT_CLASS(
//   mobile_base_hardware::MobileBaseHardwareInterface,
//   hardware_interface::SystemInterface)



// #include "my_robot_hardware/mobile_base_hardware.hpp"

// #include "hardware_interface/types/hardware_interface_type_values.hpp"
// #include "pluginlib/class_list_macros.hpp"
// #include "rclcpp/rclcpp.hpp"

// #include <unistd.h>
// #include <cmath>

// namespace mobile_base_hardware
// {

// hardware_interface::CallbackReturn
// MobileBaseHardwareInterface::on_init(
//   const hardware_interface::HardwareInfo & info)
// {
//   if (hardware_interface::SystemInterface::on_init(info) !=
//       hardware_interface::CallbackReturn::SUCCESS)
//   {
//     return hardware_interface::CallbackReturn::ERROR;
//   }

//   info_ = info;

//   port_        = "/dev/ttyUSB0";
//   baudrate     = 9600;
//   left_slave   = 1;
//   right_slave  = 2;

//   max_rpm_     = 24000;

//   left_pos_  = 0.0;
//   right_pos_ = 0.0;
//   left_vel_  = 0.0;
//   right_vel_ = 0.0;
//   left_cmd_  = 0.0;
//   right_cmd_ = 0.0;

//   prev_left_encoder_  = 0;
//   prev_right_encoder_ = 0;

//   driver_ = std::make_shared<MoonsMotorEnable>(
//     port_,
//     baudrate,
//     left_slave,
//     right_slave,
//     40125,
//     40343,
//     40011
//   );

//   return hardware_interface::CallbackReturn::SUCCESS;
// }

// hardware_interface::CallbackReturn
// MobileBaseHardwareInterface::on_configure(
//   const rclcpp_lifecycle::State &)
// {
//   auto logger = rclcpp::get_logger("MobileBaseHardwareInterface");

//   if (!driver_ || !driver_->connect())
//   {
//     RCLCPP_ERROR(logger, "Failed to connect to motor driver");
//     return hardware_interface::CallbackReturn::ERROR;
//   }

//   return hardware_interface::CallbackReturn::SUCCESS;
// }

// hardware_interface::CallbackReturn
// MobileBaseHardwareInterface::on_activate(
//   const rclcpp_lifecycle::State &)
// {
//   if (!driver_) {
//     return hardware_interface::CallbackReturn::ERROR;
//   }

//   driver_->enableMotors();
//   usleep(500000);
//   driver_->enableJogMode();
//   usleep(200000);

//   // 🔥 IMPORTANT: Reset encoder baseline
//   prev_left_encoder_  = driver_->readEncoder(left_slave);
//   prev_right_encoder_ = driver_->readEncoder(right_slave);

//   left_pos_  = 0.0;
//   right_pos_ = 0.0;

//   return hardware_interface::CallbackReturn::SUCCESS;
// }

// hardware_interface::CallbackReturn
// MobileBaseHardwareInterface::on_deactivate(
//   const rclcpp_lifecycle::State &)
// {
//   if (driver_) {
//     driver_->disableMotors();
//   }

//   return hardware_interface::CallbackReturn::SUCCESS;
// }

// std::vector<hardware_interface::StateInterface>
// MobileBaseHardwareInterface::export_state_interfaces()
// {
//   std::vector<hardware_interface::StateInterface> state_interfaces;

//   state_interfaces.emplace_back(
//     "base_left_wheel_joint",
//     hardware_interface::HW_IF_POSITION,
//     &left_pos_);

//   state_interfaces.emplace_back(
//     "base_left_wheel_joint",
//     hardware_interface::HW_IF_VELOCITY,
//     &left_vel_);

//   state_interfaces.emplace_back(
//     "base_right_wheel_joint",
//     hardware_interface::HW_IF_POSITION,
//     &right_pos_);

//   state_interfaces.emplace_back(
//     "base_right_wheel_joint",
//     hardware_interface::HW_IF_VELOCITY,
//     &right_vel_);

//   return state_interfaces;
// }

// std::vector<hardware_interface::CommandInterface>
// MobileBaseHardwareInterface::export_command_interfaces()
// {
//   std::vector<hardware_interface::CommandInterface> command_interfaces;

//   command_interfaces.emplace_back(
//     "base_left_wheel_joint",
//     hardware_interface::HW_IF_VELOCITY,
//     &left_cmd_);

//   command_interfaces.emplace_back(
//     "base_right_wheel_joint",
//     hardware_interface::HW_IF_VELOCITY,
//     &right_cmd_);

//   return command_interfaces;
// }

// hardware_interface::return_type
// MobileBaseHardwareInterface::read(
//   const rclcpp::Time &, const rclcpp::Duration & period)
// {
//   if (!driver_) {
//     return hardware_interface::return_type::ERROR;
//   }

//   int32_t left_enc  = driver_->readEncoder(left_slave);
//   int32_t right_enc = driver_->readEncoder(right_slave);

//   int32_t delta_left  = left_enc  - prev_left_encoder_;
//   int32_t delta_right = right_enc - prev_right_encoder_;

//   // Mirror correction
//   delta_right = -delta_right;

//   // 🔥 Remove 1–2 pulse noise
//   if (std::abs(delta_left) < 2)  delta_left = 0;
//   if (std::abs(delta_right) < 2) delta_right = 0;

//   prev_left_encoder_  = left_enc;
//   prev_right_encoder_ = right_enc;

//   constexpr double RAD_PER_PULSE = 2.0 * M_PI / 100000.0;

//   double delta_left_rad  = delta_left  * RAD_PER_PULSE;
//   double delta_right_rad = delta_right * RAD_PER_PULSE;

//   left_pos_  += delta_left_rad;
//   right_pos_ += delta_right_rad;

//   double dt = period.seconds();

//   if (dt > 0.0001)
//   {
//     left_vel_  = delta_left_rad  / dt;
//     right_vel_ = delta_right_rad / dt;
//   }
//   else
//   {
//     left_vel_  = 0.0;
//     right_vel_ = 0.0;
//   }

//   auto logger = rclcpp::get_logger("MobileBaseHardwareInterface");
//   RCLCPP_INFO(logger,
//     "Encoders: left=%d right=%d | delta: left=%d right=%d | vel: left=%.5f right=%.5f",
//     left_enc, right_enc, delta_left, delta_right, left_vel_, right_vel_);

//   return hardware_interface::return_type::OK;
// }

// hardware_interface::return_type
// MobileBaseHardwareInterface::write(
//   const rclcpp::Time &, const rclcpp::Duration &)
// {
//   if (!driver_) {
//     return hardware_interface::return_type::ERROR;
//   }

//   double right_cmd_inverted = -right_cmd_;

//   int left_rpm  = radPerSecToRpm(left_cmd_);
//   int right_rpm = radPerSecToRpm(right_cmd_inverted);

//   if (left_rpm > max_rpm_) left_rpm = max_rpm_;
//   if (left_rpm < -max_rpm_) left_rpm = -max_rpm_;

//   if (right_rpm > max_rpm_) right_rpm = max_rpm_;
//   if (right_rpm < -max_rpm_) right_rpm = -max_rpm_;

//   driver_->setJogSpeed(left_rpm, right_rpm);

//   return hardware_interface::return_type::OK;
// }

// double MobileBaseHardwareInterface::rpmToRadPerSec(int32_t rpm)
// {
//   return static_cast<double>(rpm) * 2.0 * M_PI / 60.0;
// }

// int MobileBaseHardwareInterface::radPerSecToRpm(double rad_per_sec)
// {
//   return static_cast<int>(rad_per_sec * 60.0 / (2.0 * M_PI));
// }

// }  // namespace mobile_base_hardware

// PLUGINLIB_EXPORT_CLASS(
//   mobile_base_hardware::MobileBaseHardwareInterface,
//   hardware_interface::SystemInterface
// )


